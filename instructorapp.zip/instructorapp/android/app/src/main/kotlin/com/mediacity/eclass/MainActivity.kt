package com.lolits.eclass

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
