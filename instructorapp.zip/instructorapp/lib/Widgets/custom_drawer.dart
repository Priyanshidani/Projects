import 'package:cached_network_image/cached_network_image.dart';
import 'package:eclass/Screens/announcement.dart';
import 'package:eclass/Screens/answer.dart';
import 'package:eclass/Screens/assignment.dart';
import 'package:eclass/Screens/bigblue_list_meeting.dart';
import 'package:eclass/Screens/bottom_navigation_screen.dart';
import 'package:eclass/Screens/completed_payment.dart';
import 'package:eclass/Screens/courses_language.dart';
import 'package:eclass/Screens/courses_screen.dart';
import 'package:eclass/Screens/featured_course.dart';
import 'package:eclass/Screens/google_all_meetings.dart';
import 'package:eclass/Screens/google_meet_dashboard.dart';
import 'package:eclass/Screens/google_meet_setting.dart';
import 'package:eclass/Screens/involved_in_courses.dart';
import 'package:eclass/Screens/involvement_request.dart';
import 'package:eclass/Screens/jitsi_meeting.dart';
import 'package:eclass/Screens/payout_setting.dart';
import 'package:eclass/Screens/pending_payout.dart';
import 'package:eclass/Screens/question.dart';
import 'package:eclass/Screens/rejected_courses.dart';
import 'package:eclass/Screens/request_to_involve.dart';
import 'package:eclass/Screens/user_enrolled.dart';
import 'package:eclass/Screens/vacation_enable.dart';
import 'package:eclass/Screens/zoom_dashboard.dart';
import 'package:eclass/Screens/zoom_setting.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import '../common/apidata.dart';
import '../provider/user_profile.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CustomDrawer extends StatefulWidget {
  @override
  _CustomDrawerState createState() => _CustomDrawerState();
}

class _CustomDrawerState extends State<CustomDrawer> {
  Widget drawerHeader(UserProfile user) {
    return DrawerHeader(
      child: Container(
        padding: EdgeInsets.all(12.0),
        height: 150,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              CircleAvatar(
                radius: 35.0,
                backgroundColor: Colors.white,
                backgroundImage: user.profileInstance.userImg == null
                    ? AssetImage("assets/placeholder/avatar.png")
                    : CachedNetworkImageProvider(
                    APIData.userImage + "${user.profileInstance.userImg}"),
              ),
              Text(
                user.profileInstance.fname + user.profileInstance.lname,
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w700),
              ),
              Text(
                user.profileInstance.email,
                style: TextStyle(color: Colors.white, fontSize: 15),
              )
            ],
          ),
        ),
      ),
      decoration: BoxDecoration(
        gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF6E1A52),
              Color(0xFFF44A4A),
            ]),
        boxShadow: [
          BoxShadow(
            color: Color(0x1c2464).withOpacity(0.30),
            blurRadius: 15.0,
            offset: Offset(0.0, 20.5),
            spreadRadius: -15.0,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    UserProfile user = Provider.of<UserProfile>(context);
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          drawerHeader(user),
          ListTile(
            leading: Icon(Icons.dashboard_rounded),
            title: Text(
              'Dashboard',
              style: TextStyle(fontSize: 16.0),
            ),
            onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context) => MyBottomNavigationBar(pageInd: 0,)));
            },
          ),
          ListTile(
            leading: Icon(Icons.perm_identity),
            title: Text(
              'Profile',
              style: TextStyle(fontSize: 16.0),
            ),
            onTap: () {
              Navigator.pop(context);
              // Navigator.pushNamed(context, "/SettingScreen");
              Navigator.push(context, MaterialPageRoute(builder: (context) => MyBottomNavigationBar(pageInd: 4,)));
            },
          ),
          ExpansionTile(
            leading: Icon(Icons.menu_book_rounded),
            title: Text(
              'Courses',
              style: TextStyle(fontSize: 16.0),
            ),
            children: <Widget>[
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  InkWell(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => MyBottomNavigationBar(pageInd: 2,)));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "Categories",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),
                  SizedBox(
                    height:15,
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => MyBottomNavigationBar(pageInd: 1,)));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "Courses",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),
                  SizedBox(
                    height:15,
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  RejectedCourses()));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "Rejected Courses",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),
                  SizedBox(
                    height:15,
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  CoursesLanguage()));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "Courses Language",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),
                  SizedBox(
                    height:15,
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  Assignment()));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "Assignment",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),

                ],
              ),
            ],
          ),

          ExpansionTile(
            leading: Icon(Icons.supervised_user_circle_outlined),
            title: Text(
              'Multiple Instructor',
              style: TextStyle(fontSize: 16.0),
            ),
            children: <Widget>[
              Column(
                children: [
                  InkWell(
                    onTap: (){
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  RequestToInvolve()));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "Request To Involve",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),
                  SizedBox(
                    height:15,
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  InvolvementRequest()));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "Involvement Request",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),
                  SizedBox(
                    height:15,
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => InvolvedInCourses()));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "Involved In Courses",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),

                ],
              ),
            ],
          ),

          ListTile(
            leading: Icon(Icons.verified_user_rounded),
            title: Text(
              'User Enrolled',
              style: TextStyle(fontSize: 16.0),
            ),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          UserEnrolled()));
            },
          ),
          ExpansionTile(
            leading: Icon(Icons.question_answer_rounded),
            title: Text(
              'Question/Answer',
              style: TextStyle(fontSize: 16.0),
            ),
            children: <Widget>[
              Column(
                children: [
                  InkWell(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => Question()));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "Question",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),

                  SizedBox(
                    height:15,
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => Answer()));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:30,
                        ),
                        Text(
                            "Answer",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),
                  //13:05
                ],
              ),
            ],
          ),
          ListTile(
            leading: Icon(Icons.announcement_rounded),
            title: Text(
              'Announcement',
              style: TextStyle(fontSize: 16.0),
            ),
            onTap: (){
              Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              Announcement()));
            },
          ),
          ListTile(
            leading: Icon(Icons.message_rounded),
            title: Text(
              'Blog',
              style: TextStyle(fontSize: 16.0),
            ),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, "/blogList");
            },
          ),
          ListTile(
            leading: Icon(Icons.book_outlined),
            title: Text(
              'Featured Courses',
              style: TextStyle(fontSize: 16.0),
            ),
            onTap:(){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => FeaturedCourses()));
                          },
          ),
          ExpansionTile(
            leading: Icon(Icons.video_call),
            title: Text(
              'Zoom Live Meetings',
              style: TextStyle(fontSize: 16.0),
            ),
            children: <Widget>[
              Column(
                children: [
                  InkWell(
                    onTap: (){
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  ZoomSetting()));
                      // Navigator.push(
                      //     context,
                      //     MaterialPageRoute(
                      //         builder: (context) =>
                      //             QAScreen(widget.courseDetails)));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "Zoom Settings",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),
                  SizedBox(
                    height:15,
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  ZoomDashboard()));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "Zoom Dashboard",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
          ExpansionTile(
            leading: Icon(Icons.person),
            title: Text(
              'Big Blue Meetings',
              style: TextStyle(fontSize: 16.0),
            ),
            children: <Widget>[
              Column(
                children: [
                  InkWell(
                    onTap: (){
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  BigblueListMeeting()));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "List Meetings",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),

                ],
              ),
            ],
          ),
          ExpansionTile(
            leading: Icon(Icons.meeting_room),
            title: Text(
              'Google Meet Meetings',
              style: TextStyle(fontSize: 16.0),
            ),
            children: <Widget>[
              Column(
                children: [
                  InkWell(
                    onTap: (){
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  GoogleMeetSetting()));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "Meet Settings",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),
                  SizedBox(
                    height:15,
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  GoogleMeetDashboard()));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "Meet Dashboard",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),
                  SizedBox(
                    height:15,
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  GoogleAllMeetings()));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "All Meetings",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),

                ],
              ),
            ],
          ),
          ExpansionTile(
            leading: Icon(Icons.donut_small_outlined),
            title: Text(
              'Jitsi Meetings',
              style: TextStyle(fontSize: 16.0),
            ),
            children: <Widget>[
              Column(
                children: [
                  InkWell(
                    onTap: (){
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  JitsiDashboard()));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "Dashboard",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),

                ],
              ),
            ],
          ),
          ExpansionTile(
            leading: Icon(Icons.money_rounded),
            title: Text(
              'My Revenue',
              style: TextStyle(fontSize: 16.0),
            ),
            children: <Widget>[
              Column(
                children: [
                  InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  PendingPayout()));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "Pending Payout",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),
                  SizedBox(
                    height:15,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  CompletedPayout()));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(width:60),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width:20,
                        ),
                        Text(
                            "Completed Payment",
                            style: TextStyle(
                                fontSize: 15)),
                      ],
                    ),
                  ),

                ],
              ),
            ],
          ),

          ListTile(
            leading: Icon(Icons.payments_rounded),
            title: Text(
              'Payout Settings',
              style: TextStyle(fontSize: 16.0),
            ),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          PayoutSetting()));
            },
          ),
          ListTile(
            leading: Icon(Icons.event_available_rounded),
            title: Text(
              'Vacation Enable',
              style: TextStyle(fontSize: 16.0),
            ),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          VacationEnable()));
            },
          ),
          ListTile(
            leading: Icon(Icons.logout),
            title: Text(
              'Logout',
              style: TextStyle(fontSize: 16.0),
            ),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, "/blogList");
            },
          ),
        ],
      ),
    );
  }
}
