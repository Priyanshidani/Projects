import 'dart:convert';
import 'package:eclass/common/apidata.dart';
import 'package:eclass/model/course_include_model.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class CourseIncludeProvider extends ChangeNotifier {
  CourseIncludeModel courseIncludeModel;
  Future<void> getCourseIncludeData() async {
    String api = APIData.courseInclude + APIData.secretKey;
    http.Response response = await http.get(Uri.parse(api));
    if(response.statusCode == 200){
      courseIncludeModel = CourseIncludeModel.fromJson(await jsonDecode(response.body));
      print("Course Include Response : ${response.body}");
    } else {
      print("Can't get Course Include data! \n Status Code ${response.statusCode}");
    }
  }
}