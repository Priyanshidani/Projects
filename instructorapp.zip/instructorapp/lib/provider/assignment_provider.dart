import 'dart:convert';
import 'package:eclass/common/apidata.dart';
import 'package:eclass/common/global.dart';
import 'package:eclass/model/assignment_model.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class AssignmentProvider extends ChangeNotifier {
  AssignmentModel assignmentModel;
  Future<void> getAssignmentData() async {
    String api = APIData.assignment + APIData.secretKey;
    http.Response response = await http.get(Uri.parse(api), headers: {
      "Accept": "application/json",
      "Authorization": "Bearer $authToken",
    });
    if(response.statusCode == 200){
      assignmentModel = AssignmentModel.fromJson(await jsonDecode(response.body));
      print("Assignment Response : ${response.body}");
    } else {
      print("Can't get Assignment data! \n Status Code ${response.statusCode}");
    }
  }
}