import 'dart:convert';
import 'package:eclass/common/apidata.dart';
import 'package:eclass/common/global.dart';
import 'package:eclass/model/course_model.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class CourseProvider extends ChangeNotifier {
  CourseModel courseModel;
  Future<void> getCourseData() async {
    print("getCourseData-1");
    String api = APIData.course + APIData.secretKey;
    http.Response response = await http.get(Uri.parse(api), headers: {
      "Accept": "application/json",
      "Authorization": "Bearer $authToken",
    });
    print("getCourseData-2");
    if(response.statusCode == 200){
      print("Course Response : ${response.statusCode}");
      try {
        courseModel = CourseModel.fromJson(await jsonDecode(response.body));
      } catch(e) {
        print("Exception : $e");
      }
      print("Course Response : ${response.body}");
    } else {
      print("Can't get Course data! \n Status Code ${response.statusCode}");
    }
  }
}