// import 'dart:convert';
// import 'package:eclass/Screens/question.dart';
// import 'package:flutter/foundation.dart';
// import 'package:http/http.dart' as http;
//
// class QuestionProvider extends ChangeNotifier {
//   Question question;
//   Future<void> getQuestionData() async {
//     http.Response response = await http.get(
//         Uri.parse("https://jsonplaceholder.typicode.com/albums"));
//     if (response.statusCode == 200) {
//       question = Question.fromJson(await jsonDecode(response.body));
//       print("Question Response : ${response.body}");
//     } else {
//       print("Can't get Question data! \n Status Code ${response.statusCode}");
//     }
//   }
//   }

