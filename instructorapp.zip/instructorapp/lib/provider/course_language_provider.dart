import 'dart:convert';
import 'package:eclass/common/apidata.dart';
import 'package:flutter/foundation.dart';
import 'package:eclass/model/course_language_model.dart';
import 'package:http/http.dart' as http;

class CourseLanguageProvider extends ChangeNotifier {
  CourseLanguageModel courseLanguageModel;
  Future<void> getCourseLanguageData() async {
    String api = APIData.courseLanguage + APIData.secretKey;
    http.Response response = await http.get(Uri.parse(api));
    if(response.statusCode == 200){
      courseLanguageModel = CourseLanguageModel.fromJson(await jsonDecode(response.body));
      print("Course Language Response : ${response.body}");
    } else {
      print("Can't get Course Language data! \n Status Code ${response.statusCode}");
    }
  }
}