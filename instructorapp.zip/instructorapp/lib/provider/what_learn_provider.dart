import 'dart:convert';
import 'package:eclass/common/apidata.dart';
import 'package:eclass/model/what_learn_model.dart';
// import 'package:flutter/foundation.dart';
// import 'package:http/http.dart' as http;
//
// class WhatLearnProvider extends ChangeNotifier {
//   WhatLearnModel whatLearnModel;
//   Future<void> getWhatLearnData() async {
//     String api = APIData.test + APIData.secretKey;
//     http.Response response = await http.get(Uri.parse(api));
//     if(response.statusCode == 200){
//       whatLearnModel = WhatLearnModel.fromJson(await jsonDecode(response.body));
//       print("What Learn Response : ${response.body}");
//     } else {
//       print("Can't get What Learn data! \n Status Code ${response.statusCode}");
//     }
//   }
// }