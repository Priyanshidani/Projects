import 'dart:convert';
import 'package:eclass/common/apidata.dart';
import 'package:eclass/common/global.dart';
import 'package:eclass/model/dashboard_model.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class DashboardProvider extends ChangeNotifier {
  DashboardModel dashboardModel;
  Future<void> getDashboardData() async {
    String api = APIData.dashboard + APIData.secretKey;
    http.Response response = await http.get(Uri.parse(api), headers: {
      "Accept": "application/json",
      "Authorization": "Bearer $authToken",
    });
    if(response.statusCode == 200){
      dashboardModel = DashboardModel.fromJson(await jsonDecode(response.body));
      print("Dashboard Response : ${response.body}");
    } else {
      print("Can't get Dashboard data! \n Status Code ${response.statusCode}");
    }
  }
}