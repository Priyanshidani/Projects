import 'dart:convert';
import 'package:eclass/common/apidata.dart';
import 'package:eclass/common/global.dart';
import 'package:eclass/model/order_model.dart';
import 'package:eclass/model/refund_order_model.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class RefundOrderProvider extends ChangeNotifier {
  RefundOrderModel refundOrderModel;
  Future<void> getRefundOrderData() async {
    String api = APIData.refundOrder + APIData.secretKey;
    http.Response response = await http.get(Uri.parse(api), headers: {
      "Accept": "application/json",
      "Authorization": "Bearer $authToken",
    });
    if(response.statusCode == 200){
      refundOrderModel = RefundOrderModel.fromJson(await jsonDecode(response.body));
      print("Refund Order Response : ${response.body}");
    } else {
      print("Can't get Order data! \n Status Code ${response.statusCode}");
    }
  }
}