import 'dart:convert';
import 'package:eclass/model/person.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class PersonProvider extends ChangeNotifier {
  Person person;
  Future<void> getPersonData() async {
    http.Response response = await http.get(Uri.parse("https://jsonplaceholder.typicode.com/albums/1"));
    if(response.statusCode == 200){
      person = Person.fromJson(await jsonDecode(response.body));
      print("Person Response : ${response.body}");
    } else {
      print("Can't get Person data! \n Status Code ${response.statusCode}");
    }
  }
}