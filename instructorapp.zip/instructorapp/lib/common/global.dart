import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

final storage = FlutterSecureStorage();
var authToken;
Color spcl = Color(0xff655586);
var currency;
var langCode;
