import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../common/theme.dart' as T;

class ViewUserEnrolled extends StatefulWidget {
  const ViewUserEnrolled({Key key}) : super(key: key);

  @override
  _ViewUserEnrolledState createState() => _ViewUserEnrolledState();
}

class _ViewUserEnrolledState extends State<ViewUserEnrolled> {
  @override
  Widget build(BuildContext context) {
    List<String> list = List.generate(10, (index) => "Text $index");
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Invoice",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed:(){
            Navigator.pop(context);
          },
        ),
      ),
      body:SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          child: ListView.builder(
            padding: EdgeInsets.only(bottom: 130.0),
            itemCount: 1,
            itemBuilder: (BuildContext context , int idx)=>
                Column(
                  children: <Widget>[
                    SizedBox(
                      height: 20,
                    ),

                    Container(
                      alignment: Alignment.bottomLeft,
                      margin: EdgeInsets.fromLTRB(20, 10, 20, 15),

                      padding: EdgeInsets.all(6.0),
                      height: 1132,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                              color: Color(0x1c2464).withOpacity(0.30),
                              blurRadius: 25.0,
                              offset: Offset(0.0, 20.0),
                              spreadRadius: -15.0)
                        ],
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [

                          ListTile
                            (
                            leading: SizedBox(
                              height: 100.0,
                              width: 100.0, // fixed width and height
                              child: Image.asset('assets/images/logo.png'),
                            ),
                            horizontalTitleGap: 120,
                            title: Text(
                              'Invoice',
                              style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 15.0,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold
                              ),
                            ),
                            subtitle: Text('Date: 18th August 2021',
                              style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 12.0,
                                  fontWeight: FontWeight.normal
                              ),),
                          ),
                          Divider(),
                          ListTile(
                            title: Text(
                              'From:',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                color: Colors.black,
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ),
                          ListTile(
                            isThreeLine: true,
                            title: Text(
                              'Admin:',
                              style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 15.0,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold
                              ),
                            ),
                            subtitle: Text('Address: Company 12345 South Main Street Anywhere Rajasthan,INDIA\n +917777777777\nadmin@mediacity.co.in',
                              style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 12.0,
                                  fontWeight: FontWeight.normal
                              ),),
                          ),
                          Divider(),
                          ListTile(
                            title: Text(
                              'To:',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                color: Colors.black,
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ),
                          ListTile(
                            isThreeLine: true,
                            title: Text(
                              'Instructor Example:',
                              style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 15.0,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold
                              ),
                            ),
                            subtitle: Text('Address: Company 12345 South Main Street Anywhere Alabama, UNITED STATES \n +9123456789\n instructor@mediacity.co.in',
                              style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 12.0,
                                  fontWeight: FontWeight.normal
                              ),),
                          ),
                          Divider(),

                          ListTile(
                            title: Text(
                              'Order ID:',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          ListTile(
                            title: Text(
                              'Transaction ID:',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          ListTile(
                            title: Row(
                              children: [
                                Text(
                                  'Payment Method:',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  'Admin Enroll',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 12.0,
                                    color: Colors.black,
                                    fontWeight: FontWeight.normal,
                                  ),
                                ),
                              ],
                            ),
                          ),

                          ListTile(
                            title: Row(
                              children: [
                                Text(
                                  'Currency: Payment Status: ',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  'Received',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 12.0,
                                    color: Colors.black,
                                    fontWeight: FontWeight.normal,
                                  ),
                                ),
                              ],
                            ),
                          ),

                          ListTile(
                            title: Row(
                              children: [
                                Text(
                                  'Enroll On: ',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  '18th August 2021',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 12.0,
                                    color: Colors.black,
                                    fontWeight: FontWeight.normal,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Divider(),
                          ListTile(
                            leading: CircleAvatar(
                              radius: 24.0,
                              // child: ClipRRect(
                              //   child: Image.asset('assets/images/logo.png'),
                              //   borderRadius: BorderRadius.circular(50.0),
                              // ),
                            ),
                            title: Column(
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      'Courses:  ',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      'Coding ',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 12.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.normal,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height:5),

                                Row(
                                  children: [
                                    Text(
                                      'Instructor:',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),

                                    Text(
                                      'The Modern JavaScript -\n The Complete Guide',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 12.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.normal,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height:5),
                                Row(
                                  children: [
                                    Text(
                                      'Currency:',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      '--',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.normal,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height:5),
                                Row(
                                  children: [
                                    Text(
                                      'Total:',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      '--',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.normal,
                                      ),
                                    ),
                                  ],
                                ),

                              ],
                            ),
                          ),
                          SizedBox(height:10),
                          ListTile(
                            leading: CircleAvatar(
                              radius: 24.0,
                              // child: ClipRRect(
                              //   child: Image.asset('assets/images/logo.png'),
                              //   borderRadius: BorderRadius.circular(50.0),
                              // ),
                            ),
                            title: Column(
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      'Courses:  ',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      'Coding ',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 12.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.normal,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height:5),

                                Row(
                                  children: [
                                    Text(
                                      'Instructor:',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),

                                    Text(
                                      'Learn C++ Programming',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 12.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.normal,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height:5),
                                Row(
                                  children: [
                                    Text(
                                      'Currency:',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      '--',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.normal,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height:5),

                                Row(
                                  children: [
                                    Text(
                                      'Total:',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      '--',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.normal,
                                      ),
                                    ),
                                  ],
                                ),

                              ],
                            ),
                          ),
                          SizedBox(height:10),
                          ListTile(
                            leading: CircleAvatar(
                              radius: 24.0,
                              // child: ClipRRect(
                              //   child: Image.asset('assets/images/logo.png'),
                              //   borderRadius: BorderRadius.circular(50.0),
                              // ),
                            ),
                            title: Column(
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      'Courses:  ',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      'Coding ',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 12.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.normal,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height:5),

                                Row(
                                  children: [
                                    Text(
                                      'Instructor:',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),

                                    Text(
                                      'The Complete Oracle \n SQL ',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 12.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.normal,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height:5),
                                Row(
                                  children: [
                                    Text(
                                      'Currency:',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      '--',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.normal,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height:5),
                                Row(
                                  children: [
                                    Text(
                                      'Total:',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      '--',
                                      style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.normal,
                                      ),
                                    ),
                                  ],
                                ),

                              ],
                            ),
                          ),

                        ],
                      ),
                    ),
                  ],
                ),
          ),
        ),
      ),
    );
  }
}