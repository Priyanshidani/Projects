import 'package:eclass/Widgets/appbar.dart';
import 'package:flutter/material.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import '../common/theme.dart' as T;
import 'package:provider/provider.dart';


class EditQuestion extends StatefulWidget {
  const EditQuestion({Key key}) : super(key: key);

  @override
  _EditQuestionState createState() => _EditQuestionState();
}

class _EditQuestionState extends State<EditQuestion> {
  @override
  Widget build(BuildContext context) {
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Edit Question",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed:(){
            Navigator.pop(context);
          },
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          padding: EdgeInsets.all(20),
          //color: Colors.blue,
          height: 500,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('User:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Admin',
                    hintText: ''
                ),
              ),
              SizedBox(height: 5,),
              Text('Question:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Admin',
                    hintText: ''
                ),
              ),
              SizedBox(height: 5,),
              Text('Status:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              toggle1(),
            ],
          ),
        ),
      ),
    );
  }
}

class toggle1 extends StatefulWidget {
  const toggle1({Key key}) : super(key: key);

  @override
  _toggle1State createState() => _toggle1State();
}

class _toggle1State extends State<toggle1> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Enable",
            textOff: "Disable",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.check,
            iconOff: Icons.not_interested_rounded,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
        SizedBox(height: 20,),
        Row(
          children: [
            RaisedButton(
              color: Colors.red,
              // color: mode.easternBlueColor,
              child: Text("Reset", style: TextStyle(color: Colors.white),),
              onPressed: () {
                // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
              },
            ),
            SizedBox(width: 50,),
            RaisedButton(
              color: Colors.red,
              // color: mode.easternBlueColor,
              child: Text("Create", style: TextStyle(color: Colors.white),),
              onPressed: () {
                // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
              },
            ),
          ],
        )
      ],
    );
  }
}