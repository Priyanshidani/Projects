import 'package:eclass/Widgets/appbar.dart';
import 'package:flutter/material.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:eclass/common/theme.dart' as T;
import 'package:provider/provider.dart';

class AddQuizTab extends StatelessWidget {



  @override
  Widget build(BuildContext context) {

    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Add Question",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          padding: EdgeInsets.all(20),
          //color: Colors.blue,
          height: 500,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Quiz Topic:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: 'Topic'
                ),
              ),
              SizedBox(height: 5,),
              Text('Quiz Description:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: 'Description'
                ),
              ),
              SizedBox(height: 5,),
              Text('Per Question Marks:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: 'Marks'
                ),
              ),
              SizedBox(height: 5,),
              Text('Quiz Timer:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: 'Time'
                ),
              ),
              SizedBox(height: 5,),
              Text('Days:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: '20'
                ),
              ),
              SizedBox(height: 5,),
              Text('Status:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              toggle(),
              Text('Quiz Reattempt:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              toggle(),
              Text('Quiz Type:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              toggle(),
              SizedBox(height: 10,),
              Row(
                children: [
                  RaisedButton(
                    color: Colors.red,
                    // color: mode.easternBlueColor,
                    child: Text("Reset", style: TextStyle(color: Colors.white),),
                    onPressed: () {
                      // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
                    },
                  ),
                  SizedBox(width: 40,),
                  RaisedButton(
                    color: Colors.red,
                    // color: mode.easternBlueColor,
                    child: Text("Update", style: TextStyle(color: Colors.white),),
                    onPressed: () {
                      // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class toggle extends StatefulWidget {
  const toggle({Key key}) : super(key: key);

  @override
  _toggleState createState() => _toggleState();
}

class _toggleState extends State<toggle> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "",
            textOff: "",
            colorOn: Colors.red,
            colorOff: Colors.green,
            iconOn: Icons.not_interested,
            iconOff: Icons.check,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
        SizedBox(height: 20,),
        Row(
          children: [
            RaisedButton(
              color: Colors.red,
              // color: mode.easternBlueColor,
              child: Text("Reset", style: TextStyle(color: Colors.white),),
              onPressed: () {
                // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
              },
            ),
            SizedBox(width: 40,),
            RaisedButton(
              color: Colors.red,
              // color: mode.easternBlueColor,
              child: Text("Create", style: TextStyle(color: Colors.white),),
              onPressed: () {
                // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
              },
            ),
          ],
        ),
      ],
    );
  }
}

class drop extends StatefulWidget {
  const drop({Key key}) : super(key: key);

  @override
  _dropState createState() => _dropState();
}

class _dropState extends State<drop> {
  String valueChoose;
  List listItem=[
    "Select an Option","Instructor",
  ];
  @override
  Widget build(BuildContext context) {
    return DropdownButton(
      hint: Text('Select an Option'),
      dropdownColor: Colors.white,
      icon: Icon(Icons.arrow_drop_down,color: Colors.red,),
      iconSize: 30,
      isExpanded: true,
      //underline: SizedBox(),
      // style: TextStyle(color: Colors.black,fontSize: 22),
      value: valueChoose,
      onChanged: (newValue){
        setState(() {
          valueChoose=newValue;
        });
      },
      items: listItem.map((valueItem){
        return DropdownMenuItem(
          value: valueItem,
          child: Text(valueItem),
        );
      }).toList(),
    );
  }
}
