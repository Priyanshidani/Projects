import 'dart:io';
import 'package:country_code_picker/country_code_picker.dart';
import 'package:country_list_pick/country_list_pick.dart';
import 'package:custom_switch/custom_switch.dart';
import 'package:eclass/Screens/add_category.dart';
import 'package:eclass/Screens/courses_screen.dart';
import 'package:eclass/Screens/zoom_dashboard.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:dio/dio.dart';
import '../common/theme.dart' as T;
import 'package:provider/provider.dart';



class AddGoogleMeetMeeting extends StatefulWidget {
  const AddGoogleMeetMeeting({Key key}) : super(key: key);

  @override
  _AddGoogleMeetMeetingState createState() => _AddGoogleMeetMeetingState();
}

class _AddGoogleMeetMeetingState extends State<AddGoogleMeetMeeting> {

  bool CheckBoxValue = false;
  bool checkboxvalue1 = false;
  bool checkboxvalue2 = false;
  bool checkboxvalue3 = false;
  bool checkboxvalue4 = false;
  final picker = ImagePicker();
  Color newColor;
  String valueChoose;
  List listItem=[
    "Select an Option","Design","Development","Music","Photography","Game"
  ];
  String valueChoose1;
  List listItem1=[
    "Select an Option"
  ];
  String valueChoose2;
  List listItem2=[
    "Select an Option"
  ];
  String valueChoose3;
  List listItem3=[
    "Select an Option"
  ];
  String valueChoose4;
  List listItem4=[
    "Select an Option","English","Hindi","French","Spanish"
  ];
  String valueChoose5;
  List listItem5=[
    "Select an Option","Test","Refund Policy"
  ];
  String valueChoose6;
  List listItem6=[
    "Select an Option","Trending","Onsale","Bestseller","Beginner","Intermediate","Expert"
  ];
  String valueChoose7;
  List listItem7=[
    "Free","Paid"
  ];



  @override
  Widget build(BuildContext context) {
    Dio dio = new Dio();

    // String pathName = "";
    final picker = ImagePicker();

    String extractName(String path) {
      int i;
      for (i = path.length - 1; i >= 0; i--) {
        if (path[i] == "/") break;
      }
      return path.substring(i + 1);
    }

    Future getImageCamera() async {
      final pickedFile = await picker.getImage(source: ImageSource.camera);

      setState(() {
        if (pickedFile != null) {
          // imgCtl.text = extractName(_image.path);
          // _imgsel = true;
        } else {}
      });
    }

    Future getImageGallery() async {
      final pickedFile = await picker.getImage(source: ImageSource.gallery);

      setState(() {
        if (pickedFile != null) {
        } else {}
      });
    }

    void _showPicker(context) {
      showModalBottomSheet(
          context: context,
          builder: (BuildContext bc) {
            return SafeArea(
              child: Container(
                child: new Wrap(
                  children: <Widget>[
                    new ListTile(
                        leading: new Icon(Icons.photo_library),
                        title: new Text('Photo Library'),
                        onTap: () async {
                          await getImageGallery();
                          Navigator.of(context).pop();
                        }),
                    new ListTile(
                      leading: new Icon(Icons.photo_camera),
                      title: new Text('Camera'),
                      onTap: () async {
                        await getImageCamera();
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),
              ),
            );
          });
    }
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Add Google Meet Meeting",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          padding: EdgeInsets.all(20),
          //color: Colors.blue,
          height: 900,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              //Text('Add Courses',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
              Text('Preview Image:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              ListTile(
                leading: Icon(Icons.upload_rounded),
                // leading: CircleAvatar(
                //   backgroundImage: NetworkImage(imageUrl),
                // ),
                title: Text('Upload Video',style: TextStyle(
                  fontFamily: 'SF Pro',
                  fontSize: 15.0,
                ),),

                // contentPadding: EdgeInsets.symmetric(horizontal: 0.0),
                onTap: (){
                  _showPicker(context);
                },
              ),
              Text('Link By Course:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              CustomSwitch(),
              SizedBox(height: 5,),
              Text('Meeting Topic:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Test',
                    hintText: ''
                ),
              ),
              SizedBox(height: 5,),
              datepicker(),
              SizedBox(height: 5,),
              end(),
              SizedBox(height: 5,),
              Text('Duration:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: ''
                ),
              ),
              SizedBox(height: 5,),
              Text('Meeting Agenda:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: ''
                ),
              ),
              SizedBox(height: 5,),
              Text('Time Zone:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              Country(),
              SizedBox(height: 20,),
              Row(
                children: [
                  RaisedButton(
                    color: Colors.red,
                    // color: mode.easternBlueColor,
                    child: Text("Reset", style: TextStyle(color: Colors.white),),
                    onPressed: () {
                      // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
                    },
                  ),
                  SizedBox(width: 50,),
                  RaisedButton(
                    color: Colors.red,
                    // color: mode.easternBlueColor,
                    child: Text("Create Meeting", style: TextStyle(color: Colors.white),),
                    onPressed: () {
                      // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}







class CustomSwitch extends StatefulWidget {
  const CustomSwitch({Key key}) : super(key: key);

  @override
  _CustomSwitchState createState() => _CustomSwitchState();
}

class _CustomSwitchState extends State<CustomSwitch> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "",
            textOff: "",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.insert_link,
            iconOff: Icons.link_off,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],

    );
  }
}

class Status extends StatefulWidget {
  const Status({Key key}) : super(key: key);

  @override
  _StatusState createState() => _StatusState();
}

class _StatusState extends State<Status> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Deactive",
            textOff: "Active",
            colorOn: Colors.red,
            colorOff: Colors.green,
            iconOn: Icons.blur_off_rounded,
            iconOff: Icons.blur_on_rounded,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],

    );
  }
}

class Duration extends StatefulWidget {
  const Duration({Key key}) : super(key: key);

  @override
  _DurationState createState() => _DurationState();
}

class _DurationState extends State<Duration> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Days",
            textOff: "Month",
            colorOn: Colors.red,
            colorOff: Colors.green,
            iconOn: Icons.calendar_view_day_sharp,
            iconOff: Icons.calendar_view_month,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],

    );
  }
}

class Assign extends StatefulWidget {
  const Assign({Key key}) : super(key: key);

  @override
  _AssignState createState() => _AssignState();
}

class _AssignState extends State<Assign> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Yes",
            textOff: "No",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.check,
            iconOff: Icons.not_interested,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],
    );
  }
}

class Drip extends StatefulWidget {
  const Drip({Key key}) : super(key: key);

  @override
  _DripState createState() => _DripState();
}

class _DripState extends State<Drip> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Disable",
            textOff: "Enable",
            colorOn: Colors.red,
            colorOff: Colors.green,
            iconOn: Icons.not_interested,
            iconOff: Icons.check,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],
    );
  }
}

class datepicker extends StatefulWidget {
  const datepicker({Key key}) : super(key: key);

  @override
  _datepickerState createState() => _datepickerState();
}

class _datepickerState extends State<datepicker> {
  String _dateofbirth = "";
  bool _datesel = false;
  TextEditingController dobCtrl = new TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 90,
      child: TextFormField(
        controller: dobCtrl,
        validator: (value) {
          if (value == "")
            return "Please choose a valid dob!";
          else
            return null;
        },
        readOnly: true,
        style: TextStyle(
          //color: txtColor,
            fontSize: 17,
            fontWeight: _datesel ? FontWeight.normal : FontWeight.w600),
        decoration: InputDecoration(
          // focusedBorder: foborder(borderClr),
          // enabledBorder: enborder(borderClr),
            labelText: "Meeting Start Time",hintStyle: (TextStyle(fontWeight: FontWeight.bold)),
            //  labelStyle: _labelStyle,
            suffixIcon: IconButton(
                icon: Icon(
                  Icons.calendar_today,
                  color: Colors.grey,
                ),
                onPressed: () async {
                  DateTime date = DateTime(1900);
                  FocusScope.of(context).requestFocus(new FocusNode());

                  date = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(1900),
                      lastDate: DateTime(2100));
                  setState(() {
                    _datesel = true;
                    _dateofbirth = date.toIso8601String();
                  });
                  dobCtrl.text = "${date.day}/${date.month}/${date.year}";
                })),
      ),
    );
  }
}

class end extends StatefulWidget {
  const end({Key key}) : super(key: key);

  @override
  _endState createState() => _endState();
}

class _endState extends State<end> {
  String _dateofbirth = "";
  bool _datesel = false;
  TextEditingController dobCtrl = new TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 90,
      child: TextFormField(
        controller: dobCtrl,
        validator: (value) {
          if (value == "")
            return "Please choose a valid dob!";
          else
            return null;
        },
        readOnly: true,
        style: TextStyle(
          //color: txtColor,
            fontSize: 17,
            fontWeight: _datesel ? FontWeight.normal : FontWeight.w600),
        decoration: InputDecoration(
          // focusedBorder: foborder(borderClr),
          // enabledBorder: enborder(borderClr),
            labelText: "Meeting End Time",hintStyle: (TextStyle(fontWeight: FontWeight.bold)),
            //  labelStyle: _labelStyle,
            suffixIcon: IconButton(
                icon: Icon(
                  Icons.calendar_today,
                  color: Colors.grey,
                ),
                onPressed: () async {
                  DateTime date = DateTime(1900);
                  FocusScope.of(context).requestFocus(new FocusNode());

                  date = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(1900),
                      lastDate: DateTime(2100));
                  setState(() {
                    _datesel = true;
                    _dateofbirth = date.toIso8601String();
                  });
                  dobCtrl.text = "${date.day}/${date.month}/${date.year}";
                })),
      ),
    );
  }
}

class Country extends StatefulWidget {
  const Country({Key key}) : super(key: key);

  @override
  _CountryState createState() => _CountryState();
}

class _CountryState extends State<Country> {
  String title='Country Code Picker';
  @override
  Widget build(BuildContext context) {
    return CountryCodePicker(
      initialSelection: 'IN',
      showCountryOnly: true,
      showOnlyCountryWhenClosed: true,

    );
  }
}