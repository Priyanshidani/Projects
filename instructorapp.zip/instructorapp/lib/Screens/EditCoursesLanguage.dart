import 'package:dio/dio.dart';
import 'package:eclass/common/apidata.dart';
import 'package:eclass/provider/course_language_provider.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:provider/provider.dart';
import '../common/theme.dart' as T;

class EditCoursesLanguage extends StatefulWidget {

  EditCoursesLanguage(this.id);

  int id;

  @override
  _EditCoursesLanguageState createState() => _EditCoursesLanguageState();
}

class _EditCoursesLanguageState extends State<EditCoursesLanguage> {
  Future<void> _updateData() async {
    Dio dio = new Dio();

    String url = APIData.courseLanguage + APIData.secretKey;

    var _body;
    _body = FormData.fromMap({

      "name": _name.text,
      "status": status,
    });

    Response response;
    try {
      response = await dio.post(
        url,
        data: _body,
        // options: Options(
        //   method: 'POST',
        //   // headers: {
        //   //   HttpHeaders.authorizationHeader: "Bearer " + authToken,
        //   // },
        // ),
      );
      print("Response Code: " + "${response.statusCode}");

      if (response.statusCode == 200 || response.statusCode == 201) {
        Fluttertoast.showToast(
            msg: "Course Language Updated Successfully!",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            backgroundColor: Colors.blue,
            textColor: Colors.white,
            fontSize: 16.0);
        await Future.delayed(Duration(seconds: 3));
        Navigator.pop(context);
        // Navigator.pushReplacement(
        //     context,
        //     MaterialPageRoute(
        //         builder: (context) => CourseLanguageLoadingScreen()));
      } else {
        Fluttertoast.showToast(
            msg: "Failed!",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        await Future.delayed(Duration(seconds: 3));
      }
    } catch (e) {
      print('Exception : $e');
      Fluttertoast.showToast(
          msg: "Failed!!",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
      await Future.delayed(Duration(seconds: 3));
    }
    // print(
    //     'Course Language : ${courseLanguage.text}, \nStatus : $status');
  }
  CourseLanguageProvider courseLanguageProvider;
  TextEditingController _name = TextEditingController();
  String status;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    courseLanguageProvider = Provider.of<CourseLanguageProvider>(context, listen: false);
    for(int i = 0; i < courseLanguageProvider.courseLanguageModel.language.length; i++) {
      if(courseLanguageProvider.courseLanguageModel.language[i].id == widget.id) {
        _name.text = courseLanguageProvider.courseLanguageModel.language[i].name.en;
        status = courseLanguageProvider.courseLanguageModel.language[i].status;
        break;
      }
    }
  }
  final _formKey = GlobalKey<FormState>();
  bool isSubmitting = false;
  @override
  Widget build(BuildContext context) {
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Edit Language",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed:(){
           Navigator.pop(context);
          },
        ),
      ),
      body: SafeArea(
        child: LoadingOverlay(
        isLoading: isSubmitting,
        progressIndicator: CircularProgressIndicator(
          color: Colors.red,
        ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              padding: EdgeInsets.all(20),
              //color: Colors.blue,
              height: 500,
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Name:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    TextFormField(
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'Please enter Language.';
                        }
                        return null;
                      },
                      controller: _name,
                      decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: "Language",
                          hintText: ''
                      ),
                    ),
                    SizedBox(height: 5,),
                    Text('Status:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    SizedBox(
                      height: 40,
                      width: 120,
                      child: LiteRollingSwitch(
                        value: status == "1" ? true : false,
                        textOn: "Disable",
                        textOff: "Enable",
                        colorOn: Colors.red,
                        colorOff: Colors.green,
                        iconOn: Icons.not_interested,
                        iconOff: Icons.check,
                        textSize: 15.0,
                        onChanged: (bool value){
                          status = value ? "1" : "0";
                        },
                      ),
                    ),
                    SizedBox(height: 20,),
                    Row(
                      children: [
                        RaisedButton(
                          color: Colors.red,
                          // color: mode.easternBlueColor,
                          child: Text("Reset", style: TextStyle(color: Colors.white),),
                          onPressed: () {
                            _name.text = "";
                            status = "0";
                            setState(() {

                            });
                          },
                        ),
                        SizedBox(width: 50,),
                        RaisedButton(
                          color: Colors.red,
                          // color: mode.easternBlueColor,
                          child: Text("Update", style: TextStyle(color: Colors.white),),
                          onPressed: () {
                            if (_formKey.currentState.validate()) {
                              _formKey.currentState.save();
                              isSubmitting = true;
                              _updateData();
                              setState(() {});
                            }
                          },
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
