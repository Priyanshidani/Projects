import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../common/theme.dart' as T;

class ViewFeaturedCourses extends StatefulWidget {
  const ViewFeaturedCourses({Key key}) : super(key: key);

  @override
  _ViewFeaturedCoursesState createState() => _ViewFeaturedCoursesState();
}

class _ViewFeaturedCoursesState extends State<ViewFeaturedCourses> {
  @override
  Widget build(BuildContext context) {

    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("View Feature Course ",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed:(){
            Navigator.pop(context);
          },
        ),
        // actions: <Widget>[
        //   IconButton(
        //     icon: Icon(Icons.search,color: Colors.black,),
        //     onPressed: () {
        //       showSearch(context: context, delegate: Search(list));
        //     },
        //   ),
        // ],
      ),
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          child: ListView.builder(
            padding: EdgeInsets.only(bottom: 100.0),
            itemCount: 1,
            itemBuilder: (BuildContext context , int idx)=>
                Column(
                  children: <Widget>[
                    SizedBox(
                      height: 20,
                    ),

                    Container(
                      alignment: Alignment.bottomLeft,
                      margin: EdgeInsets.fromLTRB(20, 10, 20, 15),

                      padding: EdgeInsets.all(6.0),
                      height: 621,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                              color: Color(0x1c2464).withOpacity(0.30),
                              blurRadius: 25.0,
                              offset: Offset(0.0, 20.0),
                              spreadRadius: -15.0)
                        ],
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Container(
                            height: 100.0,
                            width: 120.0,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: AssetImage(
                                    'assets/images/logo.png'),

                              ),
                            ),
                          ),
                          ListTile(
                            leading: Icon(Icons.menu_book_sharp,color: mode.easternBlueColor,),
                            title: Text(
                              'Courses',
                              style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 15.0,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold
                              ),
                            ),
                            subtitle: Text('Internationally Accredited Diploma In Yoga Training',
                              style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.normal
                              ),),
                          ),
                          ListTile(
                              leading: Icon(Icons.person,color: mode.easternBlueColor,),
                              title: Text('User',style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.bold
                              ),),
                              subtitle: Text('Instructor',style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                fontWeight: FontWeight.normal,
                              ),)
                          ),
                          ListTile(
                            leading: Icon(Icons.domain_verification_sharp,color: mode.easternBlueColor,),
                            title: Text(
                              'Transaction ID',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,

                              ),
                            ),
                            subtitle: Text(
                              'PAYID -L2NMPLAWE234567UI',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ),
                          ListTile(
                            leading: Icon(Icons.money_sharp,color: mode.easternBlueColor,),
                            title: Text(
                              'Payment Method',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,

                              ),
                            ),
                            subtitle: Text(
                              'Paypal',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ),
                          ListTile(
                            leading: Icon(Icons.attach_money_outlined,color: mode.easternBlueColor,),
                            title: Text(
                              'Total Amount',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,

                              ),
                            ),
                            subtitle: Text(
                              'Rs- 100',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                color:Colors.green,
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ),
                          ListTile(
                            leading: Icon(Icons.attach_money_outlined,color: mode.easternBlueColor,),
                            title: Text(
                              'Total Amount',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,

                              ),
                            ),
                            subtitle: Text(
                              'Rs- 100',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                color:Colors.green,
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ),
                          ListTile(
                            leading: Icon(Icons.attach_money_outlined,color: mode.easternBlueColor,),
                            title: Text(
                              'Currency',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,

                              ),
                            ),
                            subtitle: Text(
                              'INR',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                color:Colors.green,
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ),

                        ],
                      ),
                    ),
                  ],
                ),
          ),
        ),
      ),
    );
  }
}