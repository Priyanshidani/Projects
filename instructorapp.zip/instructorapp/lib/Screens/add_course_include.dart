
import 'package:eclass/common/apidata.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_iconpicker/Models/IconPack.dart';
import 'package:flutter_iconpicker/flutter_iconpicker.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:dio/dio.dart';
import 'package:image_picker/image_picker.dart';
import 'package:loading_overlay/loading_overlay.dart';
import '../common/theme.dart' as T;
import 'package:provider/provider.dart';


class AddCourseInclude extends StatefulWidget {
  const AddCourseInclude({Key key}) : super(key: key);

  @override
  _AddCourseIncludeState createState() => _AddCourseIncludeState();
}

class _AddCourseIncludeState extends State<AddCourseInclude> {

  Future<void> _addData() async {
    Dio dio = new Dio();

    String url = APIData.courseInclude + APIData.secretKey;
    String status;
    var _body;
    _body = FormData.fromMap({

      "courses": courseInclude.text,
      "icon": courseInclude.text,
      "detail" : courseInclude.text,
      "status": status,
    });

    Response response;
    try {
      response = await dio.post(
        url,
        data: _body,
        // options: Options(
        //   method: 'POST',
        //   // headers: {
        //   //   HttpHeaders.authorizationHeader: "Bearer " + authToken,
        //   // },
        // ),
      );
      print("Response Code: " + "${response.statusCode}");

      if (response.statusCode == 200 || response.statusCode == 201) {
        Fluttertoast.showToast(
            msg: "Course Language Submitted Successfully!",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            backgroundColor: Colors.blue,
            textColor: Colors.white,
            fontSize: 16.0);
        await Future.delayed(Duration(seconds: 3));
        // Navigator.pushReplacement(
        //     context,
        //     MaterialPageRoute(
        //         builder: (context) => CourseLanguageLoadingScreen()));
      } else {
        Fluttertoast.showToast(
            msg: "Failed!",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        await Future.delayed(Duration(seconds: 3));
      }
    } catch (e) {
      print('Exception : $e');
      Fluttertoast.showToast(
          msg: "Failed!!",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
     await Future.delayed(Duration(seconds: 3));
    }
    // print(
    //     'Course Language : ${courseLanguage.text}, \nStatus : $status');
  }

  bool isSubmitting = false;

  final _formKey = GlobalKey<FormState>();
  TextEditingController courseInclude = TextEditingController();


  String status = '0';

  final picker = ImagePicker();
  Color newColor;
  String valueChoose;
  List listItem=[
    "Select an Option","Design","Development","Music","Photography","Game"
  ];
  String valueChoose1;
  List listItem1=[
    "Select an Option"
  ];
  String valueChoose2;
  List listItem2=[
    "Select an Option"
  ];
  String valueChoose3;
  List listItem3=[
    "Select an Option"
  ];
  String valueChoose4;
  List listItem4=[
    "Select an Option","English","Hindi","French","Spanish"
  ];
  String valueChoose5;
  List listItem5=[
    "Select an Option","Test","Refund Policy"
  ];
  String valueChoose6;
  List listItem6=[
    "Select an Option","Trending","Onsale","Bestseller","Beginner","Intermediate","Expert"
  ];
  String valueChoose7;
  List listItem7=[
    "Free","Paid"
  ];



  @override
  Widget build(BuildContext context) {
    Dio dio = new Dio();

    // String pathName = "";
    final picker = ImagePicker();

    String extractName(String path) {
      int i;
      for (i = path.length - 1; i >= 0; i--) {
        if (path[i] == "/") break;
      }
      return path.substring(i + 1);
    }

    Future getImageCamera() async {
      final pickedFile = await picker.getImage(source: ImageSource.camera);

      setState(() {
        if (pickedFile != null) {
          // imgCtl.text = extractName(_image.path);
          // _imgsel = true;
        } else {}
      });
    }

    Future getImageGallery() async {
      final pickedFile = await picker.getImage(source: ImageSource.gallery);

      setState(() {
        if (pickedFile != null) {
        } else {}
      });
    }

    void _showPicker(context) {
      showModalBottomSheet(
          context: context,
          builder: (BuildContext bc) {
            return SafeArea(
              child: Container(
                child: new Wrap(
                  children: <Widget>[
                    new ListTile(
                        leading: new Icon(Icons.photo_library),
                        title: new Text('Photo Library'),
                        onTap: () async {
                          await getImageGallery();
                          Navigator.of(context).pop();
                        }),
                    new ListTile(
                      leading: new Icon(Icons.photo_camera),
                      title: new Text('Camera'),
                      onTap: () async {
                        await getImageCamera();
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),
              ),
            );
          });
    }
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Add Course Include",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed:(){
            Navigator.pop(context);
          },
        ),
      ),
      body:  SafeArea(
        child: LoadingOverlay(
          isLoading: isSubmitting,
          progressIndicator: CircularProgressIndicator(
            color: Colors.red,
          ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              padding: EdgeInsets.all(20),
              //color: Colors.blue,
              height: 800,
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Icon',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    IconPick(),
                    SizedBox(height: 5,),
                    Text('Details:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    TextFormField(
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'Please enter Details';
                        }
                        return null;
                      },
                      controller: courseInclude,
                      decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'Enter Detail',
                          hintText: 'Detail'
                      ),
                    ),
                    SizedBox(height: 5,),
                    Text('Status:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    SizedBox(
                      height: 40,
                      width: 120,
                      child: LiteRollingSwitch(
                        value: status == "1" ? true : false,
                        textOn: "Active",
                        textOff: "Deactive",
                        colorOn: Colors.green,
                        colorOff: Colors.red,
                        iconOn: Icons.check,
                        iconOff: Icons.not_interested_rounded,
                        textSize: 15.0,
                        onChanged: (bool value){
                          status = value ? "1" : "0";
                        },
                      ),
                    ),
                    SizedBox(height: 10,),
                    Row(
                      children: [
                        RaisedButton(
                          onPressed: () {
                            courseInclude.text = "";
                            status = "0";
                            setState(() {

                            });
                          },
                          color: Colors.red,
                          child: Text(
                            "Reset",
                            style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),
                          ),
                        ),
                        SizedBox(width: 50,),
                        RaisedButton(
                          onPressed: () {
                            if (_formKey.currentState.validate()) {
                              _formKey.currentState.save();
                              isSubmitting = true;
                              _addData();
                              setState(() {});
                            }
                          },
                          color: Colors.red,
                          child: Text(
                            "Create",
                            style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class IconPick extends StatefulWidget {
  const IconPick({Key key}) : super(key: key);

  @override
  _IconPickState createState() => _IconPickState();
}

class _IconPickState extends State<IconPick> {
  Icon _icon;
  _iconutil() async
  {
    IconData icon = await FlutterIconPicker.showIconPicker(context,iconPackMode: IconPack.fontAwesomeIcons),
        _icon = Icon(icon) as IconData;
    setState(() {

    });
    debugPrint('selected icon $icon');
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      width: 50,
      child: SafeArea(
        child: Scaffold(
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                RaisedButton(
                  onPressed:() => _iconutil(),
                  child: Text('pick'),
                ),
                SizedBox(height: 10,),
                // AnimatedSwitcher(
                //   duration: Duration()
                // ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
