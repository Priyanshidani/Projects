import 'package:eclass/Widgets/appbar.dart';
import 'package:flutter/material.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';

class ZoomSetting extends StatefulWidget {
  const ZoomSetting({Key key}) : super(key: key);

  @override
  _ZoomSettingState createState() => _ZoomSettingState();
}

class _ZoomSettingState extends State<ZoomSetting> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar(context, "Zoom Settings",

      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          padding: EdgeInsets.all(20),
          //color: Colors.blue,
          height: 500,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Zoom Email:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: '...........'
                ),
              ),
              SizedBox(height: 5,),
              Text('Zoom JWT Token:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: 'eyJhbGciOiJIUzI1NiJ9.eyJhd'
                ),
              ),
              SizedBox(height: 15,),
              Row(
                children: [
                  RaisedButton(
                    color: Colors.red,
                    // color: mode.easternBlueColor,
                    child: Text("Reset", style: TextStyle(color: Colors.white),),
                    onPressed: () {
                      // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
                    },
                  ),
                  SizedBox(width: 125),
                  RaisedButton(
                    color: Colors.red,
                    // color: mode.easternBlueColor,
                    child: Text("Create", style: TextStyle(color: Colors.white),),
                    onPressed: () {
                      // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class toggle1 extends StatefulWidget {
  const toggle1({Key key}) : super(key: key);

  @override
  _toggle1State createState() => _toggle1State();
}

class _toggle1State extends State<toggle1> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // SizedBox(
        //   height: 40,
        //   width: 120,
        //   child: LiteRollingSwitch(
        //     value: true,
        //     textOn: "Disable",
        //     textOff: "Enable",
        //     colorOn: Colors.red,
        //     colorOff: Colors.green,
        //     iconOn: Icons.not_interested,
        //     iconOff: Icons.check,
        //     textSize: 15.0,
        //     onChanged: (bool position){},
        //   ),
        // ),
        // SizedBox(height: 20,),
        Row(
          children: [
            RaisedButton(
              color: Colors.red,
              // color: mode.easternBlueColor,
              child: Text("Reset", style: TextStyle(color: Colors.white),),
              onPressed: () {
                // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
              },
            ),
            SizedBox(width: 50,),
            RaisedButton(
              color: Colors.red,
              // color: mode.easternBlueColor,
              child: Text("Create", style: TextStyle(color: Colors.white),),
              onPressed: () {
                // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
              },
            ),
          ],
        ),
      ],
    );
  }
}