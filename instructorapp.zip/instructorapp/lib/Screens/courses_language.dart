import 'package:dio/dio.dart';
import 'package:eclass/Screens/EditCoursesLanguage.dart';
import 'package:eclass/Screens/add_course_language.dart';
import 'package:eclass/Screens/search_result_screen.dart';
import 'package:eclass/common/apidata.dart';
import 'package:eclass/model/course_language_model.dart';
import 'package:eclass/provider/course_language_provider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:provider/provider.dart';
import '../common/theme.dart' as T;

class CoursesLanguage extends StatefulWidget {
  const CoursesLanguage({Key key}) : super(key: key);

  @override
  _CoursesLanguageState createState() => _CoursesLanguageState();
}

class _CoursesLanguageState extends State<CoursesLanguage> {

  // CourseLanguageProvider courseLanguageProvider = CourseLanguageProvider();

  // Future<void> loadData(BuildContext context) async {
  //   courseLanguageProvider =
  //       Provider.of<CourseLanguageProvider>(context, listen: false);
  //   await courseLanguageProvider.getCourseLanguageData();
  //   setState(() {
  //     isLoading = false;
  //   });
  // }

  Future<CourseLanguageModel> loadData(BuildContext context) async {
    CourseLanguageProvider courseLanguageProvider =
        Provider.of<CourseLanguageProvider>(context, listen: false);
    await courseLanguageProvider.getCourseLanguageData();
    return courseLanguageProvider.courseLanguageModel;
  }

  reloadScreen() {
    setState(() {
    });
  }

  // bool isLoading = true;
  String valueChoose;
  bool isPopupVisible = false;

  @override
  Widget build(BuildContext context) {
    List<String> list = List.generate(10, (index) => "Text $index");
    T.Theme mode = Provider.of<T.Theme>(context);
    // return Scaffold(
    //   backgroundColor: mode.bgcolor,
    //   appBar: AppBar(
    //     backgroundColor: mode.bgcolor,
    //     title: Text("Courses Language", style: TextStyle(color: Colors.black),),
    //     centerTitle: true,
    //     leading: IconButton(
    //       icon: Icon(Icons.arrow_back, color: Colors.black,),
    //       onPressed: () {
    //         Navigator.pop(context);
    //       },
    //     ),
    //     actions: <Widget>[
    //       IconButton(
    //         icon: Icon(Icons.search, color: Colors.black,),
    //         onPressed: () {
    //           showSearch(context: context, delegate: Search(list));
    //         },
    //       ),
    //     ],
    //   ),
    //   body: LoadingOverlay(
    //     isLoading: isLoading,
    //     progressIndicator: CircularProgressIndicator(
    //       color: Colors.red,
    //     ),
    //     child: Stack(
    //       children: [
    //         SingleChildScrollView(
    //           child: Container(
    //             height: MediaQuery
    //                 .of(context)
    //                 .size
    //                 .height,
    //             child: ListView.builder(
    //               padding: EdgeInsets.only(bottom: 250.0),
    //               itemCount: courseLanguageProvider.courseLanguageModel.language != null ? courseLanguageProvider.courseLanguageModel.language
    //                   .length :0,
    //               itemBuilder: (BuildContext context, int idx) =>
    //                   Column(
    //                     children: <Widget>[
    //                       SizedBox(
    //                         height: 20,
    //                       ),
    //                       Container(
    //                         alignment: Alignment.bottomLeft,
    //                         margin: EdgeInsets.fromLTRB(20, 10, 20, 2),
    //
    //                         padding: EdgeInsets.all(6.0),
    //                         height: 205,
    //                         decoration: BoxDecoration(
    //                           color: Colors.white,
    //                           boxShadow: [
    //                             BoxShadow(
    //                                 color: Color(0x1c2464).withOpacity(0.30),
    //                                 blurRadius: 25.0,
    //                                 offset: Offset(0.0, 20.0),
    //                                 spreadRadius: -15.0)
    //                           ],
    //                           borderRadius: BorderRadius.circular(10.0),
    //                         ),
    //                         child: Column(
    //                           crossAxisAlignment: CrossAxisAlignment.stretch,
    //                           children: [
    //                             ListTile(
    //                                 leading: Icon(Icons.language_rounded,
    //                                   color: mode.easternBlueColor,),
    //                                 title: Text('Language ', style: TextStyle(
    //                                   fontFamily: 'SF Pro',
    //                                   fontSize: 15.0,
    //                                   fontWeight: FontWeight.bold,
    //                                 ),),
    //                                 subtitle: Text(
    //                                   courseLanguageProvider.courseLanguageModel
    //                                       .language[idx].name.en,
    //                                   style: TextStyle(
    //                                     fontFamily: 'SF Pro',
    //                                     fontSize: 15.0,
    //                                     fontWeight: FontWeight.normal,
    //                                   ),)
    //                             ),
    //
    //
    //                             Padding(
    //                               padding: const EdgeInsets.all(15.0),
    //                               child: Row(
    //                                 mainAxisAlignment: MainAxisAlignment.start,
    //                                 crossAxisAlignment: CrossAxisAlignment
    //                                     .start,
    //                                 children: <Widget>[
    //
    //                                   Text("Status", style: TextStyle(
    //                                     fontSize: 15,
    //                                     fontWeight: FontWeight.bold,
    //                                   ),
    //                                   ),
    //                                   SizedBox(width: 20,),
    //
    //                                   SizedBox(
    //                                     height: 40,
    //                                     width: 120,
    //                                     child: LiteRollingSwitch(
    //                                       value: courseLanguageProvider
    //                                           .courseLanguageModel.language[idx]
    //                                           .status == "1" ? true : false,
    //                                       textOn: 'Active',
    //                                       textOff: 'Deactive',
    //                                       colorOn: Colors.green,
    //                                       colorOff: Colors.red,
    //                                       iconOn: Icons.check,
    //                                       iconOff: Icons.power_settings_new,
    //                                       onChanged: (bool state) {
    //                                         print('turned ${(state)
    //                                             ? 'Active'
    //                                             : 'Deactive'}');
    //                                       },
    //                                     ),
    //                                   )
    //                                 ],
    //                               ),
    //                             ),
    //
    //
    //                             Row(
    //                               mainAxisAlignment: MainAxisAlignment.end,
    //                               children: [
    //                                 IconButton(onPressed: () {
    //                                   setState(() {
    //                                     Navigator.push(
    //                                         context,
    //                                         MaterialPageRoute(
    //                                             builder: (context) =>
    //                                                 EditCoursesLanguage(
    //                                                     courseLanguageProvider
    //                                                         .courseLanguageModel
    //                                                         .language[idx]
    //                                                         .id)));
    //                                   });
    //                                 },
    //                                   icon: Icon(Icons.edit_location_outlined,
    //                                       color: mode.easternBlueColor),),
    //                                 SizedBox(width: 15),
    //                                 IconButton(
    //                                   onPressed: () {
    //                                     showDialog(
    //                                         context: context,
    //                                         builder: (
    //                                             BuildContext dialogContext) {
    //                                           return AlertDialog(
    //                                             title: Text(
    //                                               "Are you sure?",
    //                                               style: TextStyle(
    //                                                   color: Colors.red),
    //                                             ),
    //                                             content: Text(
    //                                                 "Do you want to delete this Language?"),
    //                                             actions: [
    //                                               // ignore: deprecated_member_use
    //                                               FlatButton(
    //                                                 child: Text("Yes"),
    //                                                 onPressed: () {
    //                                                   // Delete Code
    //                                                   _deleteData(context, courseLanguageProvider.courseLanguageModel
    //                                                       .language[idx].id);
    //                                                   Navigator.of(
    //                                                       dialogContext).pop();
    //                                                 },
    //                                               ),
    //                                               // ignore: deprecated_member_use
    //                                               FlatButton(
    //                                                 child: Text("No"),
    //                                                 onPressed: () {
    //                                                   Navigator.of(
    //                                                       dialogContext).pop();
    //                                                 },
    //                                               )
    //                                             ],
    //                                           );
    //                                         });
    //                                   },
    //                                   icon: Icon(FontAwesomeIcons.trashAlt,
    //                                     color: Colors.red,),
    //                                   iconSize: 22,
    //                                 ),
    //                               ],
    //                             ),
    //                           ],
    //                         ),
    //
    //                       ),
    //
    //                     ],
    //                   ),
    //             ),
    //           ),
    //         ),
    //       ],
    //     ),
    //   ),
    //   floatingActionButton: FloatingActionButton.extended(
    //     elevation: 5.0,
    //     onPressed: () {
    //       Navigator.push(
    //           context,
    //           MaterialPageRoute(
    //               builder: (context) => AddCourseLanguage()));
    //     },
    //     backgroundColor: mode.easternBlueColor,
    //     label: Text(
    //       "+ Add Course Language",
    //       style: TextStyle(fontWeight: FontWeight.w500, fontSize: 18.0),
    //     ),
    //   ),
    // );
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Courses Language", style: TextStyle(color: Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black,),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.search, color: Colors.black,),
            onPressed: () {
              showSearch(context: context, delegate: Search(list));
            },
          ),
        ],
      ),
      body: FutureBuilder<CourseLanguageModel>(
        future: loadData(context),
        builder: (BuildContext context, AsyncSnapshot<CourseLanguageModel> snapshot) {
          if(!snapshot.hasData) {
            return Center(child: CircularProgressIndicator());
          } else if(snapshot.hasError) {
            return Text("Something went wrong!", style: TextStyle(color: Colors.red,),);
          }
          return Stack(
            children: [
              SingleChildScrollView(
                child: Container(
                  height: MediaQuery.of(context).size.height,
                  child: ListView.builder(
                    padding: EdgeInsets.only(bottom: 250.0),
                    itemCount: snapshot.data.language != null ? snapshot.data.language
                        .length :0,
                    itemBuilder: (BuildContext context, int idx) =>
                        Column(
                          children: <Widget>[
                            SizedBox(
                              height: 20,
                            ),
                            Container(
                              alignment: Alignment.bottomLeft,
                              margin: EdgeInsets.fromLTRB(20, 10, 20, 2),

                              padding: EdgeInsets.all(6.0),
                              height: 205,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                      color: Color(0x1c2464).withOpacity(0.30),
                                      blurRadius: 25.0,
                                      offset: Offset(0.0, 20.0),
                                      spreadRadius: -15.0)
                                ],
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  ListTile(
                                      leading: Icon(Icons.language_rounded,
                                        color: mode.easternBlueColor,),
                                      title: Text('Language ', style: TextStyle(
                                        fontFamily: 'SF Pro',
                                        fontSize: 15.0,
                                        fontWeight: FontWeight.bold,
                                      ),),
                                      subtitle: Text(
                                        snapshot.data.language[idx].name.en,
                                        style: TextStyle(
                                          fontFamily: 'SF Pro',
                                          fontSize: 15.0,
                                          fontWeight: FontWeight.normal,
                                        ),)
                                  ),


                                  Padding(
                                    padding: const EdgeInsets.all(15.0),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment
                                          .start,
                                      children: <Widget>[

                                        Text("Status", style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        ),
                                        SizedBox(width: 20,),

                                        SizedBox(
                                          height: 40,
                                          width: 120,
                                          child: LiteRollingSwitch(
                                            value: snapshot.data.language[idx]
                                                .status == "1" ? true : false,
                                            textOn: 'Active',
                                            textOff: 'Deactive',
                                            colorOn: Colors.green,
                                            colorOff: Colors.red,
                                            iconOn: Icons.check,
                                            iconOff: Icons.power_settings_new,
                                            onChanged: (bool state) {
                                              print('turned ${(state)
                                                  ? 'Active'
                                                  : 'Deactive'}');
                                            },
                                          ),
                                        )
                                      ],
                                    ),
                                  ),


                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      IconButton(onPressed: () {
                                        setState(() {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      EditCoursesLanguage(
                                                          snapshot.data.language[idx]
                                                              .id)));
                                        });
                                      },
                                        icon: Icon(Icons.edit_location_outlined,
                                            color: mode.easternBlueColor),),
                                      SizedBox(width: 15),
                                      IconButton(
                                        onPressed: () {
                                          showDialog(
                                              context: context,
                                              builder: (
                                                  BuildContext dialogContext) {
                                                return AlertDialog(
                                                  title: Text(
                                                    "Are you sure?",
                                                    style: TextStyle(
                                                        color: Colors.red),
                                                  ),
                                                  content: Text(
                                                      "Do you want to delete this Language?"),
                                                  actions: [
                                                    // ignore: deprecated_member_use
                                                    FlatButton(
                                                      child: Text("Yes"),
                                                      onPressed: () {
                                                        // Delete Code
                                                        _deleteData(context, snapshot.data.language[idx].id);
                                                        Navigator.of(
                                                            dialogContext).pop();
                                                      },
                                                    ),
                                                    // ignore: deprecated_member_use
                                                    FlatButton(
                                                      child: Text("No"),
                                                      onPressed: () {
                                                        Navigator.of(
                                                            dialogContext).pop();
                                                      },
                                                    )
                                                  ],
                                                );
                                              });
                                        },
                                        icon: Icon(FontAwesomeIcons.trashAlt,
                                          color: Colors.red,),
                                        iconSize: 22,
                                      ),
                                    ],
                                  ),
                                ],
                              ),

                            ),

                          ],
                        ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        elevation: 5.0,
        onPressed: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => AddCourseLanguage(reloadScreen)));
        },
        backgroundColor: mode.easternBlueColor,
        label: Text(
          "+ Add Course Language",
          style: TextStyle(fontWeight: FontWeight.w500, fontSize: 18.0),
        ),
      ),
    );
  }
  // @override
  // void initState() {
  //   // TODO: implement initState
  //   super.initState();
  //   loadData(context);
  // }

  Future<void> _deleteData(BuildContext context, int id) async {
    Dio dio = new Dio();

    String url = APIData.deleteCourseLanguagePrefix +
        id.toString() +
        APIData.deleteCourseLanguageSuffix +
        APIData.secretKey;

    print('URL : $url');

    Response response;
    try {
      response = await dio.delete(url);

      print("Response Code: " + "${response.statusCode}");

      if (response.statusCode == 200) {
        Fluttertoast.showToast(
            msg: "Course Language Deleted Successfully!",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            backgroundColor: Colors.blue,
            textColor: Colors.white,
            fontSize: 16.0);
        await Future.delayed(Duration(seconds: 3));
        reloadScreen();
        // Navigator.pushReplacement(
        //     context,
        //     MaterialPageRoute(
        //         builder: (context) => CourseLanguageLoadingScreen()));
      } else {
        Fluttertoast.showToast(
            msg: "Failed!",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        await Future.delayed(Duration(seconds: 3));
      }
    } catch (e) {
      print('Exception : $e');
      Fluttertoast.showToast(
          msg: "Failed!!",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
      await Future.delayed(Duration(seconds: 3));
    }
  }
}
