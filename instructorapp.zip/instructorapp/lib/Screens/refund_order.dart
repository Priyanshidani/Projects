import 'dart:developer';

import 'package:eclass/Screens/search_result_screen.dart';
import 'package:eclass/Screens/user_enrolled.dart';
import 'package:eclass/Screens/view_user_enrolled.dart';
import 'package:eclass/common/global.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:provider/provider.dart';
import '../common/theme.dart' as T;


class RefundOrder extends StatefulWidget {
  const RefundOrder({Key key}) : super(key: key);

  @override
  _RefundOrderState createState() => _RefundOrderState();
}

class _RefundOrderState extends State<RefundOrder> {
  // Future<RefundOrderModel> loadData(BuildContext context) async {
  //   RefundOrderProvider orderProvider =
  //   Provider.of<RefundOrderProvider>(context, listen: false);
  //   await orderProvider.getOrderData();
  //   log("Auth Token : $authToken");
  //   return orderProvider.orderModel;
  // }
  //
  // reloadScreen() {
  //   setState(() {
  //   });
  // }
  String valueChoose;
  bool isPopupVisible = false;
  List<String> list = List.generate(10, (index) => "Text $index");
  @override
  Widget build(BuildContext context) {
    T.Theme mode = Provider.of<T.Theme>(context);
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: mode.bgcolor,
        appBar: AppBar(
          backgroundColor: mode.bgcolor,
          centerTitle: true,
          leading: IconButton(
            icon:Icon(Icons.arrow_back,color: Colors.black,),
            onPressed: (){
              Navigator.of(context).pop();
            },
          ),
          actions: <Widget>[
            IconButton(
              icon: Icon(Icons.search,color: Colors.black,),
              onPressed: () {
                showSearch(context: context, delegate: Search(list));
              },
            ),
          ],
          title: Text('User Enrolled',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 20),),

        ),
        body:
        Stack(
          children:[
            Container(
              margin: EdgeInsets.symmetric(vertical: 20.0),
              // height: MediaQuery.of(context).size.height,
              height: 50,
              decoration: BoxDecoration(
                color: mode.bgcolor,
                boxShadow: [
                  BoxShadow(
                      color: Color(0x1c2464).withOpacity(0.30),
                      blurRadius: 25.0,
                      offset: Offset(0.0, 20.0),
                      spreadRadius: -15.0)
                ],
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: <Widget>[
                  //Edit.......
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 10, 5, 10),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        primary: mode.easternBlueColor,
                      ),
                      child: Text('Order'),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => UserEnrolled()));
                      },

                    ),
                  ),
                  //Course Include.......
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 10, 5, 10),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        primary: mode.easternBlueColor,
                      ),
                      child: Text('Refund Order'),
                      onPressed: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //     builder: (context) => CourseInclude()));
                      },

                    ),
                  ),


                ],
              ),
            ),
            SizedBox(height: 100),
            Container(
              height: MediaQuery.of(context).size.height,
              margin: EdgeInsets.fromLTRB(20, 80, 20, 10),
              child: ListView.builder(
                padding: EdgeInsets.only(bottom: 130.0),
                itemCount: 2,
                itemBuilder: (BuildContext context , int idx)=>
                    Column(
                      children: <Widget>[
                        SizedBox(
                          height: 30,
                        ),
                        Container(
                          alignment: Alignment.bottomLeft,
                          margin: EdgeInsets.fromLTRB(20, 10, 20, 15),

                          padding: EdgeInsets.all(6.0),
                          height: 433,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                  color: Color(0x1c2464).withOpacity(0.30),
                                  blurRadius: 25.0,
                                  offset: Offset(0.0, 20.0),
                                  spreadRadius: -15.0)
                            ],
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              ListTile(
                                  leading: Icon(Icons.person_pin_outlined,color: mode.easternBlueColor,),
                                  title: Text('User',style: TextStyle(
                                      fontFamily: 'SF Pro',
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold
                                  ),),
                                  subtitle: Text('Instructor Example',style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.normal,
                                  ),)
                              ),
                              ListTile(
                                leading: Icon(Icons.menu_book_sharp,color: mode.easternBlueColor),
                                title: Text(
                                  'Courses',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                subtitle: Text('Coding',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.normal,
                                  ),),
                              ),
                              ListTile(
                                leading: Icon(Icons.domain_verification_sharp,color: mode.easternBlueColor),
                                title: Text(
                                  'Order ID',
                                  style: TextStyle(
                                      fontFamily: 'SF Pro',
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold
                                  ),
                                ),
                                subtitle: Text(
                                  '--',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.normal,

                                  ),
                                ),
                              ),
                              ListTile(
                                leading: Icon(Icons.money_sharp,color: mode.easternBlueColor),
                                title: Text(
                                  'Payment Method',
                                  style: TextStyle(
                                      fontFamily: 'SF Pro',
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold
                                  ),
                                ),
                                subtitle: Text(
                                  'Admin enroll',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                                ),
                              ),


                              Padding(
                                padding: const EdgeInsets.all(14.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[

                                    Text("Status",style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    ),
                                    SizedBox(width: 20,),
                                    SizedBox(
                                      height: 40,
                                      width: 120,
                                      child: LiteRollingSwitch(
                                        value: true,
                                        textOn: 'Active',
                                        textOff: 'De-Active',
                                        colorOn: Colors.green,
                                        colorOff: Colors.red,
                                        iconOn: Icons.check,
                                        iconOff: Icons.power_settings_new,
                                        onChanged: (bool state) {
                                          print('turned ${(state) ? 'Active' : 'De-Active'}');
                                        },
                                      ),
                                    )
                                  ],
                                ),
                              ),

                              Padding(
                                padding: const EdgeInsets.all(6.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    IconButton(onPressed: (){
                                      setState(() {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) => ViewUserEnrolled()));
                                      });
                                    },
                                      icon: Icon(Icons.remove_red_eye_rounded,color:mode.easternBlueColor),),
                                    SizedBox(width:15),
                                    IconButton(
                                      onPressed: () {
                                        showDialog(
                                            context: context,
                                            builder: (
                                                BuildContext dialogContext) {
                                              return AlertDialog(
                                                title: Text(
                                                  "Are you sure?",
                                                  style: TextStyle(
                                                      color: Colors.red),
                                                ),
                                                content: Text(
                                                    "Do you want to delete this Language?"),
                                                actions: [
                                                  // ignore: deprecated_member_use
                                                  FlatButton(
                                                    child: Text("Yes"),
                                                    onPressed: () {
                                                      // Delete Code
                                                      // _deleteData(context, snapshot.data.language[idx].id);
                                                      Navigator.of(
                                                          dialogContext).pop();
                                                    },
                                                  ),
                                                  // ignore: deprecated_member_use
                                                  FlatButton(
                                                    child: Text("No"),
                                                    onPressed: () {
                                                      Navigator.of(
                                                          dialogContext).pop();
                                                    },
                                                  )
                                                ],
                                              );
                                            });
                                      },
                                      icon: Icon(FontAwesomeIcons.trashAlt,
                                        color: Colors.red,),
                                      iconSize: 22,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
              ),
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          elevation: 5.0,
          onPressed: () {
            // Navigator.pushReplacement(context,
            //     MaterialPageRoute(builder: (context) => AddUserEnroll()));
          },
          backgroundColor: mode.easternBlueColor,
          label: Text(
            "+ Enroll User",
            style: TextStyle(fontWeight: FontWeight.w500, fontSize: 18.0),
          ),
        ),
      ),

    );
  }
} 