import 'dart:io';import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_iconpicker/Models/IconPack.dart';
import 'package:flutter_iconpicker/flutter_iconpicker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:dio/dio.dart';import '../common/theme.dart' as T;
import 'package:provider/provider.dart';


class EditChildCategory extends StatefulWidget {
  const EditChildCategory({Key key}) : super(key: key);

  @override
  _EditChildCategoryState createState() => _EditChildCategoryState();
}

class _EditChildCategoryState extends State<EditChildCategory> {


  File _image;
  final picker = ImagePicker();
  Color newColor;
  String valueChoose;
  List listItem=[
    "Select an Option","Design","Development","Music","Photography","Game"
  ];
  String valueChoose1;
  List listItem1=[
    "Select an Option"
  ];
  String valueChoose2;
  List listItem2=[
    "Select an Option"
  ];
  String valueChoose3;
  List listItem3=[
    "Select an Option"
  ];
  String valueChoose4;
  List listItem4=[
    "Select an Option","English","Hindi","French","Spanish"
  ];
  String valueChoose5;
  List listItem5=[
    "Select an Option","Trending","Onsale","Bestseller","Intermediate"
  ];
  String valueChoose6;
  List listItem6=[
    "Select an Option","One","Two"
  ];
  String valueChoose7;
  List listItem7=[
    "Free","Paid"
  ];

  @override
  Widget build(BuildContext context) {
    Dio dio = new Dio();

    // String pathName = "";
    final picker = ImagePicker();

    String extractName(String path) {
      int i;
      for (i = path.length - 1; i >= 0; i--) {
        if (path[i] == "/") break;
      }
      return path.substring(i + 1);
    }

    Future getImageCamera() async {
      final pickedFile = await picker.getImage(source: ImageSource.camera);

      setState(() {
        if (pickedFile != null) {
          // imgCtl.text = extractName(_image.path);
          // _imgsel = true;
        } else {}
      });
    }

    Future getImageGallery() async {
      final pickedFile = await picker.getImage(source: ImageSource.gallery);

      setState(() {
        if (pickedFile != null) {
        } else {}
      });
    }

    void _showPicker(context) {
      showModalBottomSheet(
          context: context,
          builder: (BuildContext bc) {
            return SafeArea(
              child: Container(
                child: new Wrap(
                  children: <Widget>[
                    new ListTile(
                        leading: new Icon(Icons.photo_library),
                        title: new Text('Photo Library'),
                        onTap: () async {
                          await getImageGallery();
                          Navigator.of(context).pop();
                        }),
                    new ListTile(
                      leading: new Icon(Icons.photo_camera),
                      title: new Text('Camera'),
                      onTap: () async {
                        await getImageCamera();
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),
              ),
            );
          });
    }
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
        backgroundColor: mode.bgcolor,
        appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Edit Child Category",style:TextStyle(color:Colors.black),),
    centerTitle: true,
    leading: IconButton(
    icon:Icon(Icons.arrow_back,color: Colors.black,),
    onPressed:(){
    Navigator.pop(context);
    },
    ),
    ),

    body: SingleChildScrollView(
    padding: const EdgeInsets.all(8.0),
    child: Container(
    padding: EdgeInsets.all(20),
    //color: Colors.blue,
    height: 2300,
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [

    Text('Select Category:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
    DropdownButton(
    hint: Text('Select an Option'),
    dropdownColor: Colors.white,
    icon: Icon(Icons.arrow_drop_down,color: Colors.red,),
    iconSize: 30,
    isExpanded: true,
    //underline: SizedBox(),
    // style: TextStyle(color: Colors.black,fontSize: 22),
    value: valueChoose,
    onChanged: (newValue){
    setState(() {
    valueChoose=newValue;
    });
    },
    items: listItem.map((valueItem){
    return DropdownMenuItem(
    value: valueItem,
    child: Text(valueItem),
    );
    }).toList(),
    ),
    SizedBox(height: 5,),
    Text('Select Sub Categories:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
    DropdownButton(
    hint: Text('Select an Option'),
    dropdownColor: Colors.white,
    icon: Icon(Icons.arrow_drop_down,color: Colors.red,),
    iconSize: 30,
    isExpanded: true,
    //underline: SizedBox(),
    // style: TextStyle(color: Colors.black,fontSize: 22),
    value: valueChoose1,
    onChanged: (newValue){
    setState(() {
    valueChoose1=newValue;
    });
    },
    items: listItem1.map((valueItem){
    return DropdownMenuItem(
    value: valueItem,
    child: Text(valueItem),
    );
    }).toList(),
    ),
    SizedBox(height: 5,),
    Text('Title:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
    TextField(
    decoration: InputDecoration(
    border: OutlineInputBorder(),
    labelText: '',
    hintText: ''
    ),
    ),
    SizedBox(height: 5,),
    Text('Slug:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
    TextField(
    decoration: InputDecoration(
    border: OutlineInputBorder(),
    labelText: '',
    hintText: ''
    ),
    ),
    SizedBox(height: 5,),
    Text('Icon:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
    IconPick(),
    SizedBox(height: 5,),
    Text('Status:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
    Status(),
    SizedBox(height: 20,),
    // ImagePicker(),
    Row(
    children:[
    RaisedButton(
    onPressed: () {

    },
    color: const Color(0xFF01579B),
    child: Text(
    "Reset",
    style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),
    ),
    ),
    RaisedButton(
    onPressed: () {

    },
    color: const Color(0xFF01579B),
    child: Text(
    "Update",
    style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),
    ),
    ),
    ],
    ),
    ],
    ),
    ),
    ),
    );
  }
}


class CustomSwitch extends StatefulWidget {
  const CustomSwitch({Key key}) : super(key: key);

  @override
  _CustomSwitchState createState() => _CustomSwitchState();
}

class _CustomSwitchState extends State<CustomSwitch> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "ON",
            textOff: "OFF",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.blur_on_rounded,
            iconOff: Icons.blur_off_rounded,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],

    );
  }
}

class Status extends StatefulWidget {
  const Status({Key key}) : super(key: key);

  @override
  _StatusState createState() => _StatusState();
}

class _StatusState extends State<Status> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Active",
            textOff: "Deactive",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.blur_on_rounded,
            iconOff: Icons.blur_off_rounded,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],

    );
  }
}

class Duration extends StatefulWidget {
  const Duration({Key key}) : super(key: key);

  @override
  _DurationState createState() => _DurationState();
}

class _DurationState extends State<Duration> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Days",
            textOff: "Month",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.calendar_view_day_sharp,
            iconOff: Icons.calendar_view_month,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],

    );
  }
}

class Assign extends StatefulWidget {
  const Assign({Key key}) : super(key: key);

  @override
  _AssignState createState() => _AssignState();
}

class _AssignState extends State<Assign> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Yes",
            textOff: "No",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.check,
            iconOff: Icons.not_interested,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],
    );
  }
}

class Drip extends StatefulWidget {
  const Drip({Key key}) : super(key: key);

  @override
  _DripState createState() => _DripState();
}

class _DripState extends State<Drip> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Enable",
            textOff: "disable",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.check,
            iconOff: Icons.not_interested_rounded,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],
    );
  }
}

class IconPick extends StatefulWidget {
  const IconPick({Key key}) : super(key: key);

  @override
  _IconPickState createState() => _IconPickState();
}

class _IconPickState extends State<IconPick> {
  Icon _icon;
  _iconutil() async
  {
    IconData icon = await FlutterIconPicker.showIconPicker(context,iconPackMode: IconPack.fontAwesomeIcons),
        _icon = Icon(icon) as IconData;
    setState(() {

    });
    debugPrint('selected icon $icon');
  }
  @override
  Widget build(BuildContext context) {
    T.Theme mode = Provider.of<T.Theme>(context);
    return Container(
      height: 50,
      width: 50,
      child: SafeArea(
        child: Scaffold(
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                RaisedButton(
                  color: mode.easternBlueColor,
                  onPressed:() => _iconutil(),
                  child: Text('+'),
                ),
                SizedBox(height: 10,),
                // AnimatedSwitcher(
                //   duration: Duration()
                // ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}