import 'dart:developer';
import 'package:eclass/common/global.dart';
import 'package:eclass/model/dashboard_model.dart';
import 'package:eclass/model/dashboard_model.dart';
import 'package:eclass/provider/dashboard_provider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:eclass/common/theme.dart' as T;
import 'package:loading_overlay/loading_overlay.dart';
import 'package:provider/provider.dart';

class DashBoard extends StatefulWidget {
  const DashBoard({Key key}) : super(key: key);

  @override
  _DashBoardState createState() => _DashBoardState();
}

class _DashBoardState extends State<DashBoard> {

  DashboardProvider dashboardProvider;

  // Future<void> loadData(BuildContext context) async {
  //   dashboardProvider =
  //       Provider.of<DashboardProvider>(context, listen: false);
  //   await dashboardProvider.getDashboardData();
  //   log("Auth Token : $authToken");
  //   setState(() {
  //     isLoading = false;
  //   });
  // }
  Future<DashboardModel> loadData(BuildContext context) async {
    DashboardProvider dashboardProvider =
    Provider.of<DashboardProvider>(context, listen: false);
    await dashboardProvider.getDashboardData();
    log("Auth Token : $authToken");
    return dashboardProvider.dashboardModel;
  }

  reloadScreen() {
    setState(() {
    });
  }

  bool isPopupVisible = false;

  // @override
  // void initState() {
  //   // TODO: implement initState
  //   super.initState();
  //   // loadData(context);
  // }

  @override
  Widget build(BuildContext context) {
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
        backgroundColor: mode.bgcolor,
        //appBar: customAppBar(context,'DashBoard',),
        body:FutureBuilder<DashboardModel>(
          future: loadData(context),
          builder: (BuildContext context, AsyncSnapshot<DashboardModel> snapshot) {
            if(!snapshot.hasData) {
              return Center(child: CircularProgressIndicator());
            } else if(snapshot.hasError) {
              return Text("Something went wrong!", style: TextStyle(color: Colors.red,),);
            }
            return SingleChildScrollView(
              child:Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 120,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        // SizedBox(height: 10,),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Padding(
                              padding: EdgeInsets.all(8.0),
                              child: Text(
                                "Hi, ",
                                style: TextStyle(
                                    fontSize: 28.0,
                                    fontWeight: FontWeight.w700,
                                    color: Color(0xFF3F4654)),
                              ),
                            ),
                            Text(
                              "!",
                              style: TextStyle(
                                fontSize: 28.0,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF788295),
                              ),
                            ),
                            SizedBox(width: 200,),
                            CircleAvatar(
                              radius: 35.0,
                            ),
                          ],
                        ),
                        // SizedBox(
                        //   height: 1.0,
                        // ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            "Welcome to Instructor App",
                            style: TextStyle(
                                color: Color(0xFF3F4654),
                                fontSize: 20,
                                fontWeight: FontWeight.w600),
                          ),
                        ),

                      ],
                    ),
                  ),
                  Container(
                    child: SafeArea(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Padding(
                            padding: EdgeInsets.all(12.0),
                            child: Center(
                              child: Wrap(
                                children: <Widget>[
                                  SizedBox(
                                    width: 160.0,
                                    height: 170.0,
                                    child: Card(
                                      elevation: 20,
                                      // color: Color.fromARGB(255, 21, 21, 21),
                                      color: Colors.white,
                                      child: Padding(
                                        padding: EdgeInsets.all(8.0),
                                        child: Column(
                                          children: <Widget>[
                                            IconButton(icon: Icon(
                                              Icons.menu_book_sharp,
                                            ),
                                              iconSize: 50,
                                              color: mode.easternBlueColor,
                                              // splashColor: Colors.purple,
                                              onPressed: () {},),
                                            Text(snapshot != null ? snapshot.data.courseCount.toString() : "0",
                                              style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 30),),
                                            SizedBox(height: 5.0,),
                                            Text('Courses',style: TextStyle(),),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 160.0,
                                    height: 170.0,
                                    child: Card(
                                      elevation: 20,
                                      // color: Color.fromARGB(255, 21, 21, 21),
                                      color: Colors.white,
                                      child: Padding(
                                        padding: EdgeInsets.all(8.0),
                                        child: Column(
                                          children: <Widget>[
                                            IconButton(icon: Icon(
                                              Icons.supervised_user_circle_rounded,
                                            ),
                                              iconSize: 50,
                                              color: mode.easternBlueColor,
                                              onPressed: () {},),
                                            Text(snapshot != null ? snapshot.data.enrolledUserCount.toString() : "0",
                                              style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 30),),
                                            SizedBox(height: 5.0,),
                                            Text('User Enrolled',style: TextStyle(),),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 160.0,
                                    height: 170.0,
                                    child: Card(
                                      elevation: 20,
                                      // color: Color.fromARGB(255, 21, 21, 21),
                                      color: Colors.white,
                                      child: Padding(
                                        padding: EdgeInsets.all(8.0),
                                        child: Column(
                                          children: <Widget>[
                                            IconButton(icon: Icon(
                                              Icons.question_answer,
                                            ),
                                              iconSize: 50,
                                              color: mode.easternBlueColor,
                                              onPressed: () {},),
                                            Text(snapshot != null ? snapshot.data.questionsCount.toString() : "0",
                                              style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 30),),
                                            SizedBox(height: 5.0,),
                                            Text('Total Question',style: TextStyle(),),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(                            width: 160.0,
                                    height: 170.0,
                                    child: Card(
                                      elevation: 20,
                                      // color: Color.fromARGB(255, 21, 21, 21),
                                      color: Colors.white,
                                      child: Padding(
                                        padding: EdgeInsets.all(8.0),
                                        child: Column(
                                          children: <Widget>[
                                            IconButton(icon: Icon(
                                              Icons.question_answer_outlined,
                                            ),
                                              iconSize: 50,
                                              color: mode.easternBlueColor,
                                              onPressed: () {},),
                                            Text(snapshot != null ? snapshot.data.answerCount.toString() : "0",
                                              style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 30),),
                                            SizedBox(height: 5.0,),
                                            Text('Total Answer',style: TextStyle(),),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 160.0,
                                    height: 170.0,
                                    child: Card(
                                      elevation: 20,
                                      // color: Color.fromARGB(255, 21, 21, 21),
                                      color: Colors.white,
                                      child: Padding(
                                        padding: EdgeInsets.all(8.0),
                                        child: Column(
                                          children: <Widget>[
                                            IconButton(icon: Icon(
                                              Icons.book_outlined,
                                            ),
                                              iconSize: 50,
                                              color: mode.easternBlueColor,
                                              onPressed: () {},),
                                            Text(snapshot != null ? snapshot.data.featuredCourseCount.toString() : "0",
                                              style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 30),),
                                            SizedBox(height: 5.0,),
                                            Text('Featured Courses',style: TextStyle(),),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 160.0,
                                    height: 170.0,
                                    child: Card(
                                      elevation: 20,
                                      // color: Color.fromARGB(255, 21, 21, 21),
                                      color: Colors.white,
                                      child: Padding(
                                        padding: EdgeInsets.all(8.0),
                                        child: Column(
                                          children: <Widget>[
                                            IconButton(icon: Icon(
                                              Icons.message_outlined,
                                            ),
                                              iconSize: 50,
                                              color: mode.easternBlueColor,
                                              onPressed: () {},),
                                            Text(snapshot != null ? snapshot.data.blogCount.toString() : "0",
                                              style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 30),),
                                            SizedBox(height: 5.0,),
                                            Text('Blog',style: TextStyle(),),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 160.0,
                                    height: 170.0,
                                    child: Card(
                                      elevation: 20,
                                      // color: Color.fromARGB(255, 21, 21, 21),
                                      color: Colors.white,
                                      child: Padding(
                                        padding: EdgeInsets.all(8.0),
                                        child: Column(
                                          children: <Widget>[
                                            IconButton(icon: Icon(
                                              Icons.mic,
                                            ),
                                              iconSize: 50,
                                              color: mode.easternBlueColor,
                                              onPressed: () {},),
                                            Text(snapshot != null ? snapshot.data.bigblueMeetingCount.toString() : "0",
                                              style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 30),),
                                            SizedBox(height: 5.0,),
                                            Text('Big Blue Meeting',style: TextStyle(),),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 160.0,
                                    height: 170.0,
                                    child: Card(
                                      elevation: 20,
                                      // color: Color.fromARGB(255, 21, 21, 21),
                                      color: Colors.white,
                                      child: Padding(
                                        padding: EdgeInsets.all(8.0),
                                        child: Column(
                                          children: <Widget>[
                                            IconButton(icon: Icon(
                                              Icons.photo_camera_front,
                                            ),
                                              iconSize: 50,
                                              color: mode.easternBlueColor,
                                              // splashColor: Colors.purple,
                                              onPressed: () {},),
                                            Text(snapshot != null ? snapshot.data.zoommMeetingCount.toString() : "0",
                                              style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 30),),
                                            SizedBox(height: 5.0,),
                                            Text('Zoom Meeting',style: TextStyle(),),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 1.0,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      "Featured Categories",
                      style: TextStyle(
                          color: Color(0xFF3F4654),
                          fontSize: 20,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                  grid(),

                ],
              ),
            );
          },
        ),

    );
  }
}


class grid extends StatefulWidget {
  const grid({Key key}) : super(key: key);

  @override
  _gridState createState() => _gridState();
}

class _gridState extends State<grid> {
  bool isPopupVisible = false;
  @override
  Widget build(BuildContext context) {
    T.Theme mode = Provider.of<T.Theme>(context);
    return Container(
      margin: EdgeInsets.symmetric(vertical: 20.0),
      height: 300,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: <Widget>[
          Container(
            width: 160.0,
            child: Card(
              child: Wrap(
                children: <Widget>[
                  Image(image: AssetImage('assets/placeholder/featured.png'),
                    fit: BoxFit.cover,),
                ],
              ),
            ),
          ),
          Container(
            width: 160.0,
            child: Card(
              child: Wrap(
                children: <Widget>[
                  Image(image: AssetImage('assets/placeholder/featured.png'),
                    fit: BoxFit.cover,),
                ],
              ),
            ),
          ),
          Container(
            width: 160.0,
            child: Card(
              child: Wrap(
                children: <Widget>[
                  Image(image: AssetImage('assets/placeholder/featured.png'),
                    fit: BoxFit.cover,),
                ],
              ),
            ),
          ),
          Container(
            width: 160.0,
            child: Card(
              child: Wrap(
                children: <Widget>[
                  Image(image: AssetImage('assets/placeholder/featured.png'),
                    fit: BoxFit.cover,),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}