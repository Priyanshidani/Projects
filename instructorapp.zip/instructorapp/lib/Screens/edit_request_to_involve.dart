import 'package:eclass/Screens/request_to_involve.dart';
import 'package:flutter/material.dart';
import 'package:eclass/common/theme.dart' as T;
import 'package:provider/provider.dart';

class EditRequestToInvolve extends StatefulWidget {
  const EditRequestToInvolve({Key key}) : super(key: key);

  @override
  _EditRequestToInvolveState createState() => _EditRequestToInvolveState();
}

class _EditRequestToInvolveState extends State<EditRequestToInvolve> {
  String valueChoose;
  List listItem=[
    "","Instructor"
  ];
  @override
  Widget build(BuildContext context) {
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Edit Request To Involve",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Instructor:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
            DropdownButton(
              hint: Text('Select an Option'),
              dropdownColor: Colors.white,
              icon: Icon(Icons.arrow_drop_down,color: Colors.red,),
              iconSize: 30,
              isExpanded: true,
              //underline: SizedBox(),
              // style: TextStyle(color: Colors.black,fontSize: 22),
              value: valueChoose,
              onChanged: (newValue){
                setState(() {
                  valueChoose=newValue;
                });
              },
              items: listItem.map((valueItem){
                return DropdownMenuItem(
                  value: valueItem,
                  child: Text(valueItem),
                );
              }).toList(),
            ),
            SizedBox(height: 5,),
            Text('Reason:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
            TextField(
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: '',
                hintText: '',
              ),
            ),
            SizedBox(height: 15,),
            SizedBox(height: 20,),
            Row(
              children: [
                RaisedButton(
                  color: Colors.red,
                  // color: mode.easternBlueColor,
                  child: Text("Reset", style: TextStyle(color: Colors.white),),
                  onPressed: () {
                    // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
                  },
                ),
                SizedBox(width: 50,),
                RaisedButton(
                  color: Colors.red,
                  // color: mode.easternBlueColor,
                  child: Text("Update", style: TextStyle(color: Colors.white),),
                  onPressed: () {
                    // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
                  },
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
