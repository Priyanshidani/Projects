import 'dart:async';
import 'package:eclass/Screens/add_child_category.dart';
import 'package:eclass/Screens/edit_sub_category.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../Widgets/course_grid_item.dart';
import '../Widgets/custom_drawer.dart';
import '../Widgets/utils.dart';
import '../model/course.dart';
import '../model/home_model.dart';
import '../provider/categories.dart';
import '../provider/courses_provider.dart';
import '../provider/home_data_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../common/theme.dart' as T;

class CategoryScreen extends StatefulWidget {
  @override
  _CategoryScreenState createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  Widget gridView(List<Course> courses) {
    return SliverPadding(
      padding: EdgeInsets.only(left: 5.0, right: 5.0, bottom: 25.0),
      sliver: SliverGrid(
        delegate: SliverChildBuilderDelegate(
            (context, idx) => CourseGridItem(courses[idx], idx),
            childCount: courses.length),
        // gridDelegate: ,
        gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 200,
          mainAxisSpacing: 18,
          crossAxisSpacing: 18,
          // childAspectRatio: 0.74,
          // Changed
          childAspectRatio: 0.68,
        ),
      ),
    );
  }
  Widget subCategoriesList(int cateId, homeData) {
    return FutureBuilder(
      future: CategoryList().subcate(cateId, homeData),
      builder: (context, snap) {
        if (snap.hasData)
          return Column(
            children: [
              Container(
                height: 850,
              margin: EdgeInsets.only(right: 15.0, bottom: 10.0),
              child: Column(
                children: [
              Container(
                height: MediaQuery.of(context).size.height,
                child: GridView.builder(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      // childAspectRatio: 19 / 12,
                      mainAxisSpacing: 5.0,
                      crossAxisSpacing: 5.0,
                    ),
                    itemCount: snap.data.length,
                    itemBuilder: (BuildContext ctx, idx) {
                      return InkWell(

                        child: CustomContainer(title: snap.data[idx].title, navigation: snap.data[idx],));
                    }),
              ),
                ],
              ),
              ),
            ],
          );
        else
          return Container(
            child: Center(
              child: CircularProgressIndicator(),
            ),
          );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    MyCategory cate = ModalRoute.of(context).settings.arguments;
    T.Theme mode = Provider.of<T.Theme>(context);
    List<Course> courses =
        Provider.of<CoursesProvider>(context).getCategoryCourses(cate.id);
    var homeData =
        Provider.of<HomeDataProvider>(context, listen: false).subCategoryList;
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: secondaryAppBar(Colors.black, mode.bgcolor, context, cate.title),
      drawer: CustomDrawer(),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: subCategoriesList(cate.id, homeData),
          ),

          SliverToBoxAdapter(
            child: SizedBox(
              height: 6,
            ),
          ),
          // gridView(courses)
        ],

      ),
      floatingActionButton: FloatingActionButton.extended(
        elevation: 5.0,
        onPressed: () {
          //showAlertDialog(context, mode, widget.courseDetail.course.id, appointment);
          Navigator.push(context, MaterialPageRoute(builder: (context)=>AddChildCategory()));
        },
        backgroundColor: mode.easternBlueColor,
        label: Text(
          "+ Add Sub Category",
          style: TextStyle(fontWeight: FontWeight.w500, fontSize: 18.0),
        ),
      ),
    );
  }
}

class CustomContainer extends StatefulWidget {
  final String title;
  final navigation;
  const CustomContainer({Key key, @required this.title, this.navigation}) : super(key: key);

  @override
  _CustomContainerState createState() => _CustomContainerState();
}

class _CustomContainerState extends State<CustomContainer> {
  bool isOverFlowVisible = false;
  bool isPopupVisible = false;

  @override
  Widget build(BuildContext context) {
    T.Theme mode = Provider.of<T.Theme>(context);
    return InkWell(
        onTap: () {
          Navigator.of(context).pushNamed('/subCategory', arguments: widget.navigation);
        },
        onLongPress: (){
          setState(() {
            this.isOverFlowVisible = true;
          });
          // Future.delayed(Duration(seconds: 5),
          //         (){
          //   setState(() {
          //     this.isOverFlowVisible = false;
          //   });
          // });
        },
        child: Container(
      margin: EdgeInsets.only(right: 18.0, bottom: 10.0),
      child: Stack(
        children:[
          Column(
            children: [
              Container(
                height: 90.0,
                width: 70.0,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image:
                        AssetImage("assets/images/cat.png"))),
              ),
              SizedBox(
                height: 10,
              ),
              Expanded(
                  child: Container(
                      alignment: Alignment.topCenter,
                      width: 83.0,
                      child: Text(
                        widget.title,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.grey[700],
                            fontWeight: FontWeight.w500,
                       ),
                    ),
                 ),
              ),
            ],
          ),
          this.isOverFlowVisible? Container(
            decoration: BoxDecoration(color: mode.bgcolor,borderRadius: BorderRadius.all(Radius.circular(10.0))),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(onPressed: (){
                  setState(() {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => EditSubCategory()));
                  });
                },
                  icon: Icon(Icons.edit_location_outlined,color: mode.easternBlueColor,),
                  iconSize: 22,
                ),
                IconButton(
                  onPressed: () {
                    showDialog(
                        context: context,
                        builder: (
                            BuildContext dialogContext) {
                          return AlertDialog(
                            title: Text(
                              "Are you sure?",
                              style: TextStyle(
                                  color: Colors.red),
                            ),
                            content: Text(
                                "Do you want to delete this Language?"),
                            actions: [
                              // ignore: deprecated_member_use
                              FlatButton(
                                child: Text("Yes"),
                                onPressed: () {
                                  // Delete Code
                                  // _deleteData(context, courseLanguageProvider.courseLanguageModel
                                  //  .language[idx].id);
                                  Navigator.of(
                                      dialogContext).pop();
                                },
                              ),
                              // ignore: deprecated_member_use
                              FlatButton(
                                child: Text("No"),
                                onPressed: () {
                                  Navigator.of(
                                      dialogContext).pop();
                                },
                              )
                            ],
                          );
                        });
                  },
                  icon: Icon(FontAwesomeIcons.trashAlt,
                    color: Colors.red,),
                  iconSize: 22,
                ),
                // InkWell(child: Padding(child: Icon(Icons.edit_location_outlined,color: Colors.blue),
                //     padding: EdgeInsets.symmetric(vertical: 1.0, horizontal: 8.0,)), onTap: ()=>print('hello')),
                // InkWell(
                //     child: Padding(
                //       child: Icon(FontAwesomeIcons.trashAlt,color: Colors.red,),
                //       padding: EdgeInsets.symmetric(vertical: 1.0, horizontal: 8.0),),
                //     onTap: (){
                //       setState(() {
                //         this.isPopupVisible = true;
                //       });
                //     }
                // ),
               ],
            ),
          ) : SizedBox(width: 0, height: 0),
        ],
      ),
    ));
  }
}
