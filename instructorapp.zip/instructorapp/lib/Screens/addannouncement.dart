import 'package:eclass/Widgets/appbar.dart';
import 'package:flutter/material.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import '../common/theme.dart' as T;
import 'package:provider/provider.dart';

class AddAnnouncement extends StatelessWidget {
  const AddAnnouncement({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Add Announcement",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed:(){
            Navigator.pop(context);
          },
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          padding: EdgeInsets.all(20),
          //color: Colors.blue,
          height: 500,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Courses:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: ''
                ),
              ),
              SizedBox(height: 5,),
              Text('Announcement:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Enter Your Announcement',
                    hintText: ''
                ),
              ),
              SizedBox(height: 5,),
              Text('Status:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              toggle(),
            ],
          ),
        ),
      ),
    );
  }
}

class toggle extends StatefulWidget {
  const toggle({Key key}) : super(key: key);

  @override
  _toggleState createState() => _toggleState();
}

class _toggleState extends State<toggle> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Enable",
            textOff: "Disable",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.check,
            iconOff: Icons.not_interested,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
        SizedBox(height: 20,),
        Center(
          child: RaisedButton(
            color: Colors.red,
            // color: mode.easternBlueColor,
            child: Text("Save", style: TextStyle(color: Colors.white),),
            onPressed: () {
              // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
            },
          ),
        ),
    ],
        );
  }
}

