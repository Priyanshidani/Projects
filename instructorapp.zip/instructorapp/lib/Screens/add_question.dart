
import 'package:eclass/model/question.dart';
import 'package:eclass/provider/course_language_provider.dart';
import 'package:eclass/provider/question_provider.dart';
import 'package:eclass/services/http_services.dart';
import 'package:flutter/material.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:eclass/common/theme.dart' as T;
import 'package:provider/provider.dart';
import 'package:dio/dio.dart';

class AddQuestion extends StatelessWidget {
   AddQuestion({Key key}) : super(key: key);

   HttpService httpService = new HttpService();

  @override
  Widget build(BuildContext context) {

    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Add Question",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          padding: EdgeInsets.all(20),
          //color: Colors.blue,
          height: 500,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Course:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: 'Course'
                ),
              ),
              SizedBox(height: 5,),
              Text('Question:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: 'Question'
                ),
              ),
              SizedBox(height: 5,),
              Text('Status:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              toggle(),
            ],
          ),
        ),
      ),
    );
  }
}

class toggle extends StatefulWidget {
  const toggle({Key key}) : super(key: key);

  @override
  _toggleState createState() => _toggleState();
}

class _toggleState extends State<toggle> {
  @override
  Widget build(BuildContext context) {
    Dio dio = new Dio();
//
//   String url = APIData.addCategory + APIData.secretKey;
//
//   String _imageFileName =
//   imageFile != null ? imageFile!.path!.split('/').last : '';
//
//   var _body;
//   _body = FormData.fromMap({
//     "title": name.text,
//     "icon": icon.text,
//     "slug": slug.text,
//     "status": status,
//     "featured": featured,
//     "image": await MultipartFile.fromFile(imageFile!.path!,
//         filename: _imageFileName)
//   });
//
//   Response response;
//   try {
//     response = await dio.post(
//       url,
//       data: _body,
//       // options: Options(
//       //   method: 'POST',
//       //   // headers: {
//       //   //   HttpHeaders.authorizationHeader: "Bearer " + authToken,
//       //   // },
//       // ),
//     );
//
//     print("Response Code: " + "${response.statusCode}");
//
//     if (response.statusCode == 200) {
//       Fluttertoast.showToast(
//           msg: "Category Submitted Successfully!",
//           toastLength: Toast.LENGTH_SHORT,
//           gravity: ToastGravity.CENTER,
//           backgroundColor: Colors.blue,
//           textColor: Colors.white,
//           fontSize: 16.0);
//       await Future.delayed(Duration(seconds: 3));
//       Navigator.pushReplacement(
//           context,
//           MaterialPageRoute(
//               builder: (context) => CourseCategoriesLoadingScreen()));
//     } else {
//       Fluttertoast.showToast(
//           msg: "Failed!",
//           toastLength: Toast.LENGTH_SHORT,
//           gravity: ToastGravity.CENTER,
//           backgroundColor: Colors.red,
//           textColor: Colors.white,
//           fontSize: 16.0);
//       await Future.delayed(Duration(seconds: 3));
//     }
//   } catch (e) {
//     print('Exception : $e');
//     Fluttertoast.showToast(
//         msg: "Failed!!",
//         toastLength: Toast.LENGTH_SHORT,
//         gravity: ToastGravity.CENTER,
//         backgroundColor: Colors.red,
//         textColor: Colors.white,
//         fontSize: 16.0);
//     await Future.delayed(Duration(seconds: 3));
//   }
//
//   print(
//       'Name : ${name.text}, \nSlug : ${slug.text},\nIcon : ${icon.text},\nFeatured : $featured,\nStatus : $status,\nFile : $_imageFileName,\n');
// }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Enable",
            textOff: "Disable",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.check,
            iconOff: Icons.not_interested,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
        SizedBox(height: 20,),
        Row(
          children: [
            RaisedButton(
              color: Colors.red,
              // color: mode.easternBlueColor,
              child: Text("Reset", style: TextStyle(color: Colors.white),),
              onPressed: () {
                // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
              },
            ),
            SizedBox(width: 40,),
            RaisedButton(
              color: Colors.red,
              // color: mode.easternBlueColor,
              child: Text("Create", style: TextStyle(color: Colors.white),),
              onPressed: () {
                // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
              },
            ),
          ],
        ),
      ],
    );
  }
}