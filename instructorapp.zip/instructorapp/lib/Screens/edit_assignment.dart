import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import '../common/theme.dart' as T;
import 'package:lite_rolling_switch/lite_rolling_switch.dart';


class EditAssignment extends StatefulWidget {
  const EditAssignment({Key key}) : super(key: key);

  @override
  _EditAssignmentState createState() => _EditAssignmentState();
}

class _EditAssignmentState extends State<EditAssignment> {
  @override
  Widget build(BuildContext context) {

    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Edit Assignment",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed:(){
            Navigator.pop(context);
          },
        ),
        // actions: <Widget>[
        //   IconButton(
        //     icon: Icon(Icons.search,color: Colors.black,),
        //     onPressed: () {
        //     },
        //   ),
        // ],
      ),
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          child: ListView.builder(
            itemCount: 1,
            itemBuilder: (BuildContext context , int idx)=>
                Column(
                  children: <Widget>[
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      alignment: Alignment.bottomLeft,
                      margin: EdgeInsets.fromLTRB(20, 0, 20, 20),

                      padding: EdgeInsets.all(6.0),
                      height: 800,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                              color: Color(0x1c2464).withOpacity(0.30),
                              blurRadius: 25.0,
                              offset: Offset(0.0, 20.0),
                              spreadRadius: -15.0)
                        ],
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          InkWell(
                            child: CircleAvatar(
                              radius: 50.0,
                              backgroundColor: Colors.white,
                              child: CircleAvatar(
                                child: Align(
                                  alignment: Alignment.bottomRight,
                                  // child: CircleAvatar(
                                  //   backgroundColor: Colors.white,
                                  //   radius: 12.0,
                                  //   // child: Icon(
                                  //   //   Icons.camera_alt,
                                  //   //   size: 15.0,
                                  //   //   color: Color(0xFF404040),
                                  //   //
                                  //   // ),
                                  // ),
                                ),
                                radius: 48.0,
                                // backgroundImage: AssetImage(
                                //     'assets/images/user-image-default.png'),
                              ),
                            ),

                          ),

                          Center(
                            child: Container(
                              padding: EdgeInsets.only(top: 16.0),
                              child: ListTile(
                                  title: Text('User : ',style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                  ),),
                                  subtitle: Text('Admin Example',style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 12.0,
                                  ),)
                              ),
                            ),
                          ),
                          Center(
                            child: Container(
                              padding: EdgeInsets.only(top: 2.0),
                              child: ListTile(
                                title: Text(
                                  'Courses :',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                  ),
                                ),
                                subtitle: Text('WordPress Theme Development',style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 12.0,
                                ),),
                              ),
                            ),
                          ),
                          Center(
                            child: Container(
                              padding: EdgeInsets.only(top: 2.0),
                              child: ListTile(
                                title: Text(
                                  'Course Chapters :',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                  ),
                                ),
                                subtitle: Text(' WordPress Theme: Set Up',style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 12.0,
                                ),),
                              ),
                            ),
                          ),
                          Center(
                            child: Container(
                              padding: EdgeInsets.only(top: 2.0),
                              child: ListTile(
                                title: Text(
                                  'Assignment Title : ',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                  ),
                                ),
                                subtitle: Text('Test',style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 12.0,
                                ),),
                              ),
                            ),
                          ),
                          Center(
                            child: Container(
                              padding: EdgeInsets.only(top: 2.0),
                              child: ListTile(
                                title: Text(
                                  'Assignment Title : ',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                  ),
                                ),
                                subtitle: Text('Download',style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 12.0,
                                ),),
                                trailing: Icon(Icons.download_rounded,color: mode.easternBlueColor),
                              ),
                            ),
                          ),

                          Padding(
                            padding: const EdgeInsets.all(14.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("Review Assignment",style: TextStyle(
                                  fontSize: 15,
                                ),
                                ),

                                SizedBox(
                                  height: 40,
                                  width: 120,
                                  child: LiteRollingSwitch(
                                    value: true,
                                    textOn: '',
                                    textOff: '',
                                    colorOn: mode.easternBlueColor,
                                    colorOff: Colors.red[400],
                                    iconOn: Icons.check,
                                    iconOff: Icons.power_settings_new,
                                    onChanged: (bool state) {
                                      print('turned ${(state) ? 'Enabled' : 'Disable'}');
                                    },
                                  ),
                                ),
                                SizedBox(height: 10,),
                                Text("Give scores to assignment (1 to 10):",style: TextStyle(
                                  fontSize: 15,
                                ),
                                ),
                                TextField(
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(),
                                    labelText: '',
                                    hintText: '',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Center(
                            child: Padding(
                              padding: const EdgeInsets.all(6.0),
                              child: Container(
                                padding:
                                EdgeInsets.fromLTRB(60.0, 8.0, 25.0, 30.0),
                                // decoration: BoxDecoration(
                                //   color: Colors.white38,
                                //   borderRadius:
                                //   BorderRadius.all(Radius.circular(20.0)),
                                // ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    RaisedButton(
                                      color: Colors.red,
                                      // color: mode.easternBlueColor,
                                      child: Text("Reset", style: TextStyle(color: Colors.white),),
                                      onPressed: () {
                                        // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
                                      },
                                    ),
                                    SizedBox(width: 30,),
                                    RaisedButton(
                                      color: Colors.red,
                                      // color: mode.easternBlueColor,
                                      child: Text("Update", style: TextStyle(color: Colors.white),),
                                      onPressed: () {
                                        // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),

                        ],
                      ),

                    ),
                    SizedBox(
                      height: 30,
                    ),

                  ],
                ),
          ),
        ),
      ),
    );
  }
}