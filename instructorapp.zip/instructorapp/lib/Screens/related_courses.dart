import 'package:eclass/Screens/add_related_courses.dart';
import 'package:eclass/Screens/bottom_navigation_screen.dart';
import 'package:eclass/Screens/edit_related_course.dart';
import 'package:eclass/Screens/search_result_screen.dart';
import 'package:eclass/Screens/what_learns.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:provider/provider.dart';
import '../common/theme.dart' as T;
import 'package:eclass/Screens/announcement.dart';
import 'package:eclass/Screens/appointment.dart';
import 'package:eclass/Screens/course_chapters.dart';
import 'package:eclass/Screens/course_classes.dart';
import 'package:eclass/Screens/course_include.dart';
import 'package:eclass/Screens/courses_screen.dart';
import 'package:eclass/Screens/edit_course.dart';
import 'package:eclass/Screens/previous_paper.dart';
import 'package:eclass/Screens/questions.dart';
import 'package:eclass/Screens/quiz_topic.dart';
import 'package:eclass/Screens/review_reports.dart';
import 'package:eclass/Screens/reviews_ratings.dart';

class RelatedCourses extends StatefulWidget {
  const RelatedCourses({Key key}) : super(key: key);

  @override
  _RelatedCoursesState createState() => _RelatedCoursesState();
}

class _RelatedCoursesState extends State<RelatedCourses> {
  String valueChoose;
  bool isPopupVisible = false;

  @override
  Widget build(BuildContext context) {
    List<String> list = List.generate(10, (index) => "Text $index");
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text("Related Courses", style: TextStyle(color: Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black,),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => MyBottomNavigationBar(pageInd: 1,)));
          },
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.search, color: Colors.black,),
            onPressed: () {
              showSearch(context: context, delegate: Search(list));
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          Container(
            margin: EdgeInsets.symmetric(vertical: 20.0),
            // height: MediaQuery.of(context).size.height,
            height: 50,
            decoration: BoxDecoration(
              color: mode.bgcolor,
              boxShadow: [
                BoxShadow(
                    color: Color(0x1c2464).withOpacity(0.30),
                    blurRadius: 25.0,
                    offset: Offset(0.0, 20.0),
                    spreadRadius: -15.0)
              ],
              borderRadius: BorderRadius.circular(10.0),
            ),
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: <Widget>[
                //Edit.......
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 5, 10),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: mode.easternBlueColor,
                    ),
                    child: Text('Edit'),
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => grid()));
                    },

                  ),
                ),
                //Course Include.......
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 5, 10),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: mode.easternBlueColor,
                    ),
                    child: Text('Course Include'),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(
                          builder: (context) => CourseInclude()));
                    },

                  ),
                ),
                //What Learn.........
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 5, 10),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: mode.easternBlueColor,
                    ),
                    child: Text('What Learn'),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(
                          builder: (context) => WhatLearns()));
                    },

                  ),
                ),
                //Course Chapter.........
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 5, 10),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: mode.easternBlueColor,
                    ),
                    child: Text('Course Chapters'),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(
                          builder: (context) => CourseChapters()));
                    },

                  ),
                ),
                //Course Class..........
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 5, 10),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: mode.easternBlueColor,
                    ),
                    child: Text('Course Classes'),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(
                          builder: (context) => CourseClasses()));
                    },

                  ),
                ),
                //Related Course...
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 5, 10),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: mode.easternBlueColor,
                    ),
                    child: Text('Related Courses'),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(
                          builder: (context) => RelatedCourses()));
                    },

                  ),
                ),
                //Question.............
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 5, 10),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: mode.easternBlueColor,
                    ),
                    child: Text('Question'),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(
                          builder: (context) => Question()));
                    },

                  ),
                ),
                //Review And Ratings......................
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 5, 10),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: mode.easternBlueColor,
                    ),
                    child: Text('Review And Ratings'),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(
                          builder: (context) => ReviewsRatings()));
                    },

                  ),
                ),
                //Announcement...............
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 5, 10),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: mode.easternBlueColor,
                    ),
                    child: Text('Announcement'),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(
                          builder: (context) => Announcement()));
                    },

                  ),
                ),
                //Review Report............
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 5, 10),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: mode.easternBlueColor,
                    ),
                    child: Text('Review Report'),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(
                          builder: (context) => ReviewReports()));
                    },
                  ),
                ),
                //Quiz Topic............
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 5, 10),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: mode.easternBlueColor,
                    ),
                    child: Text('Quiz Topic'),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(
                          builder: (context) => QuizTopic()));
                    },
                  ),
                ),
                //Appointment.................
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 5, 10),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: mode.easternBlueColor,
                    ),
                    child: Text('Appointment'),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(
                          builder: (context) => Appointment()));
                    },

                  ),
                ),
                //PreviousPaper.....................
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 10, 5, 10),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: mode.easternBlueColor,
                    ),
                    child: Text('Previous Paper'),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(
                          builder: (context) => PreviousPaper()));
                    },

                  ),
                ),

              ],
            ),
          ),
          SizedBox(height: 100),
          Container(
            height: MediaQuery.of(context).size.height,
            margin: EdgeInsets.fromLTRB(20, 80, 20, 10),
            child: ListView.builder(
              padding: EdgeInsets.only(bottom: 120.0),
              itemCount: 1,
              itemBuilder: (BuildContext context, int idx) =>
                  Column(
                    children: <Widget>[
                      SizedBox(
                        height: 20,
                      ),
                      Container(
                        alignment: Alignment.bottomLeft,
                        margin: EdgeInsets.fromLTRB(20, 10, 20, 10),

                        padding: EdgeInsets.all(6.0),
                        height: 200,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                                color: Color(0x1c2464).withOpacity(0.30),
                                blurRadius: 25.0,
                                offset: Offset(0.0, 20.0),
                                spreadRadius: -15.0)
                          ],
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        child: SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              ListTile(
                                  leading: Icon(Icons.menu_book_sharp,color: mode.easternBlueColor,),
                                  title: Text('Related Courses', style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.bold,
                                  ),),
                                  subtitle: Text(
                                    'Hair styling- The Ultimate Hair Course',
                                    style: TextStyle(
                                      fontFamily: 'SF Pro',
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.normal,
                                    ),)
                              ),

                              Padding(
                                padding: const EdgeInsets.all(15.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[

                                    Text("Status", style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    ),
                                    SizedBox(width: 20,),

                                    SizedBox(
                                      height: 40,
                                      width: 120,
                                      child: LiteRollingSwitch(
                                        value: true,
                                        textOn: 'Active',
                                        textOff: 'Deactive',
                                        colorOn: Colors.green,
                                        colorOff: Colors.red,
                                        iconOn: Icons.check,
                                        iconOff: Icons.power_settings_new,
                                        onChanged: (bool state) {
                                          print('turned ${(state)
                                              ? 'Active'
                                              : 'Deactive'}');
                                        },
                                      ),
                                    )
                                  ],
                                ),
                              ),


                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [

                                  IconButton(onPressed: () {
                                    setState(() {
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) => EditRelatedCourse()));
                                    });
                                  },
                                    icon: Icon(Icons.edit_location_outlined,color: mode.easternBlueColor,),
                                    iconSize: 22,
                                  ),
                                  SizedBox(width:15),

                                  IconButton(
                                    onPressed: () {
                                      setState(() {
                                        this.isPopupVisible = true;
                                      });
                                    },
                                    icon: Icon(FontAwesomeIcons.trashAlt,color: Colors.red,),
                                    iconSize: 22,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),

                      ),

                    ],
                  ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        elevation: 5.0,
        onPressed: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => AddRelatedCourses()));
        },
        backgroundColor: mode.easternBlueColor,
        label: Text(
          "+ Add Related Courses",
          style: TextStyle(fontWeight: FontWeight.w500, fontSize: 18.0),
        ),
      ),
    );
  }
}