import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../common/theme.dart' as T;

class ViewCompletedPayout extends StatefulWidget {
  const ViewCompletedPayout({Key key}) : super(key: key);

  @override
  _ViewCompletedPayoutState createState() => _ViewCompletedPayoutState();
}

class _ViewCompletedPayoutState extends State<ViewCompletedPayout> {
  @override
  Widget build(BuildContext context) {
    List<String> list = List.generate(10, (index) => "Text $index");
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Invoice",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed:(){
            Navigator.pop(context);
          },
        ),
      ),
      body:SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          child: ListView.builder(
            padding: EdgeInsets.only(bottom: 130.0),
            itemCount: 1,
            itemBuilder: (BuildContext context , int idx)=>
                Column(
                  children: <Widget>[
                    SizedBox(
                      height: 20,
                    ),

                    Container(
                      alignment: Alignment.bottomLeft,
                      margin: EdgeInsets.fromLTRB(20, 10, 20, 15),

                      padding: EdgeInsets.all(6.0),
                      height: 900,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                              color: Color(0x1c2464).withOpacity(0.30),
                              blurRadius: 25.0,
                              offset: Offset(0.0, 20.0),
                              spreadRadius: -15.0)
                        ],
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [

                          ListTile
                            (
                            leading: SizedBox(
                              height: 100.0,
                              width: 100.0, // fixed width and height
                              child: Image.asset('assets/images/logo.png'),
                            ),
                            horizontalTitleGap: 120,
                            title: Text(
                              'Invoice',
                              style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 15.0,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold
                              ),
                            ),
                            subtitle: Text('Date: 23th September 2021',
                              style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 12.0,
                                  fontWeight: FontWeight.normal
                              ),),
                          ),
                          Divider(),
                          ListTile(
                            title: Text(
                              'From:',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                color: Colors.black,
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ),
                          ListTile(
                            isThreeLine: true,
                            title: Text(
                              'Admin:',
                              style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 15.0,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold
                              ),
                            ),
                            subtitle: Text('Address: Company 12345 South Main Street Anywhere Rajasthan,INDIA\n +917777777777\nadmin@mediacity.co.in',
                              style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 12.0,
                                  fontWeight: FontWeight.normal
                              ),),
                          ),
                          Divider(),
                          ListTile(
                            title: Text(
                              'To:',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                color: Colors.black,
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ),
                          ListTile(
                            isThreeLine: true,
                            title: Text(
                              'Instructor :',
                              style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 15.0,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold
                              ),
                            ),
                            subtitle: Text('Address: Company 12345 South Main Street Anywhere Alabama, UNITED STATES \n +9123456789\n instructor@mediacity.co.in',
                              style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 12.0,
                                  fontWeight: FontWeight.normal
                              ),),
                          ),
                          Divider(),
                          ListTile(
                            title: Row(
                              children: [
                                Text(
                                  'Order ID: ',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  '#00000001,#00000002',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 12.0,
                                    color: Colors.black,
                                    fontWeight: FontWeight.normal,
                                  ),
                                ),
                              ],
                            ),
                          ),

                          ListTile(
                            title: Row(
                              children: [
                                Text(
                                  'Payment Method: ',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  'Paytm',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 12.0,
                                    color: Colors.black,
                                    fontWeight: FontWeight.normal,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          ListTile(
                            title: Row(
                              children: [
                                Text(
                                  'Currency: ',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  'USD',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 12.0,
                                    color: Colors.black,
                                    fontWeight: FontWeight.normal,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Divider(),
                          ListTile(
                            title: Row(
                              children: [
                              Text(
                              'Instructor: ',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              'Instructor :',
                              style: TextStyle(
                              fontFamily: 'SF Pro',
                              fontSize: 12.0,
                              color: Colors.black,
                              fontWeight: FontWeight.normal,
                            ),
                          ),
                        ],
                      ),
                    ),

                    ListTile(
                      title: Row(
                        children: [
                          Text(
                            'Currency: ',
                            style: TextStyle(
                              fontFamily: 'SF Pro',
                              fontSize: 15.0,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'USD',
                            style: TextStyle(
                              fontFamily: 'SF Pro',
                              fontSize: 12.0,
                              color: Colors.black,
                              fontWeight: FontWeight.normal,
                            ),
                          ),
                        ],
                      ),
                    ),
                    ListTile(
                      title: Row(
                        children: [
                          Text(
                            'Total : ',
                            style: TextStyle(
                              fontFamily: 'SF Pro',
                              fontSize: 15.0,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'USD-1050',
                            style: TextStyle(
                              fontFamily: 'SF Pro',
                              fontSize: 12.0,
                              color: Colors.black,
                              fontWeight: FontWeight.normal,
                            ),
                          ),
                        ],
                      ),
                    ),
                          ListTile(
                            title: Row(
                              children: [
                                Text(
                                  'Payment Method : ',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  'Paytm',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 12.0,
                                    color: Colors.black,
                                    fontWeight: FontWeight.normal,
                                  ),
                                ),
                              ],
                            ),
                          ),

                        ],
                      ),
                    ),
                  ],
                ),
          ),
        ),
      ),
    );
  }
}