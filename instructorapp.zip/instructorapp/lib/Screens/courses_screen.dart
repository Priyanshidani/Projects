import 'dart:developer';
import 'package:eclass/Screens/add_courses.dart';
import 'package:eclass/Screens/course_details_screen.dart';
import 'package:eclass/Widgets/featured_list_item.dart';
import 'package:eclass/common/global.dart';
import 'package:eclass/model/course_model.dart';
import 'package:eclass/provider/course_provider.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import '../common/theme.dart' as T;
import 'edit_course.dart';

class CoursesScreen extends StatefulWidget {

  @override
  _CoursesScreenState createState() => _CoursesScreenState();
}

class _CoursesScreenState extends State<CoursesScreen> {

  Future<CourseModel> loadData(BuildContext context) async {
    print("Calling loadData");
    CourseProvider courseProvider =
    Provider.of<CourseProvider>(context, listen: false);
    await courseProvider.getCourseData();
    // log("Auth Token : $authToken");
    return courseProvider.courseModel;
  }

  reloadScreen() {
    setState(() {
    });
  }

  bool isPopupVisible = false;

  @override
  Widget build(BuildContext context) {
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      body:
      FutureBuilder<CourseModel>(
        future: loadData(context),
        builder: (BuildContext context, AsyncSnapshot<CourseModel> snapshot) {
          if(!snapshot.hasData) {
            return Center(child: CircularProgressIndicator());
          } else if(snapshot.hasError) {
            return Text("Something went wrong!", style: TextStyle(color: Colors.red,),);
          }
          return Stack(
            children:[
              GridView.builder(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 4/7,
                    mainAxisSpacing: 7.0,
                    crossAxisSpacing: 5.0,
                  ),
                  itemCount: snapshot.data.course != null ? snapshot.data.course
                      .length :0,
                  itemBuilder: (BuildContext ctx, idx) {
                    return Container(
                      margin: EdgeInsets.fromLTRB(10, 10, 10.0, 10),
                      height: 600,
                      width: MediaQuery.of(context).orientation == Orientation.landscape
                          ? 700
                          : MediaQuery.of(context).size.width / 1.6,
                      decoration: BoxDecoration(
                        color: mode.tilecolor,
                        borderRadius: BorderRadius.circular(10.0),
                        boxShadow: [
                          BoxShadow(
                              color: Color(0x1c2464).withOpacity(0.30),
                              blurRadius: 16.0,
                              offset: Offset(-13.0, 20.5),
                              spreadRadius: -15.0)
                        ],
                      ),
                      child:InkWell(
                        borderRadius: BorderRadius.circular(10.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(
                                height: 100,
                                child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(15.0),
                                        topRight: Radius.circular(15.0),
                                      ),
                                      image: DecorationImage(
                                        image: AssetImage('assets/placeholder/featured.png'),
                                        fit: BoxFit.cover,
                                      ),
                                    ))
                            ),
                            Container(

                              padding: EdgeInsets.all(15.0),
                              child: Column(
                                children: [

                                  Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Flexible(
                                            child: Text(
                                              snapshot.data.course[idx].title.en,
                                              overflow: TextOverflow.ellipsis,
                                              maxLines: 1,
                                              style: TextStyle(
                                                fontSize: 18.0,
                                                fontWeight: FontWeight.w700,
                                                foreground: Paint()..shader = linearGradient,
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          Text(
                                            "Free",
                                            maxLines: 1,
                                            style: TextStyle(
                                                color: mode.txtcolor,
                                                fontSize: 18.0,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ],
                                      ),],
                                  ),


                                  Column(
                                    children: [
                                      Align(
                                        alignment: Alignment.topLeft,
                                        child: Text('sdfghjs',
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                              color: mode.titleTextColor,
                                              fontWeight: FontWeight.w700,
                                              fontSize: 20),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 10.0,
                                      ),
                                      Text(snapshot.data.course[idx].detail.en,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                            color: mode.shortTextColor,
                                            fontSize: 18.0,
                                            fontWeight: FontWeight.w600),
                                      ),
                                      SizedBox(
                                        height: 10.0,
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            "by admin",
                                            style:
                                            TextStyle(fontSize: 14.0, color: Colors.grey),
                                          ),

                                        ],
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.end,
                                        children: [
                                          IconButton(onPressed: (){
                                            setState(() {
                                              Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (context) => grid()));
                                            });
                                          },
                                            icon: Icon(Icons.edit_location_outlined,color: mode.easternBlueColor,),),
                                          SizedBox(width: 15),
                                          IconButton(
                                            onPressed: () {
                                              showDialog(
                                                  context: context,
                                                  builder: (
                                                      BuildContext dialogContext) {
                                                    return AlertDialog(
                                                      title: Text(
                                                        "Are you sure?",
                                                        style: TextStyle(
                                                            color: Colors.red),
                                                      ),
                                                      content: Text(
                                                          "Do you want to delete this Language?"),
                                                      actions: [
                                                        // ignore: deprecated_member_use
                                                        FlatButton(
                                                          child: Text("Yes"),
                                                          onPressed: () {
                                                            // Delete Code
                                                           // _deleteData(context, snapshot.data.language[idx].id);
                                                            Navigator.of(
                                                                dialogContext).pop();
                                                          },
                                                        ),
                                                        // ignore: deprecated_member_use
                                                        FlatButton(
                                                          child: Text("No"),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                dialogContext).pop();
                                                          },
                                                        )
                                                      ],
                                                    );
                                                  });
                                            },
                                            icon: Icon(FontAwesomeIcons.trashAlt,
                                              color: Colors.red,),
                                            iconSize: 22,
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>CourseDetailScreen()));
                        },
                      ),
                    );
                  }
              ),
            ],
          );
        },
      ),


      floatingActionButton: FloatingActionButton.extended(
        elevation: 5.0,
        onPressed: () {
          //showAlertDialog(context, mode, widget.courseDetail.course.id, appointment);
          Navigator.push(context, MaterialPageRoute(builder: (context)=>AddCourses()));
          //Navigator.push(context, MaterialPageRoute(builder: (context)=>Image()));
        },
        backgroundColor: mode.easternBlueColor,
        label: Text(
          "+ Add Courses",
          style: TextStyle(fontWeight: FontWeight.w500, fontSize: 18.0),
        ),
      ),
    );
  }
  // @override
  // void initState() {
  //   // TODO: implement initState
  //   super.initState();
  //   loadData(context);
  // }
}










