import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

class PdfViewer extends StatefulWidget {
  PdfViewer({this.file, this.isLocal = false});

  String file;
  bool isLocal;

  @override
  _PdfViewerState createState() => _PdfViewerState();
}

class _PdfViewerState extends State<PdfViewer> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'PDF File Viewer',
        ),
      ),
      body: Container(
        child: widget.isLocal
            ? SfPdfViewer.file(File(widget.file))
            : SfPdfViewer.network(widget.file),
      ),
    );
  }
}
