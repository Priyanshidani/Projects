
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:dio/dio.dart';
import 'package:image_picker/image_picker.dart';
import '../common/theme.dart' as T;
import 'package:provider/provider.dart';


class AddCourses extends StatefulWidget {
  const AddCourses({Key key}) : super(key: key);

  @override
  _AddCoursesState createState() => _AddCoursesState();
}

class _AddCoursesState extends State<AddCourses> {


  final picker = ImagePicker();
  Color newColor;
  String valueChoose;
  List listItem=[
    "Select an Option","Design","Development","Music","Photography","Game"
  ];
  String valueChoose1;
  List listItem1=[
    "Select an Option"
  ];
  String valueChoose2;
  List listItem2=[
    "Select an Option"
  ];
  String valueChoose3;
  List listItem3=[
    "Select an Option"
  ];
  String valueChoose4;
  List listItem4=[
    "Select an Option","English","Hindi","French","Spanish"
  ];
  String valueChoose5;
  List listItem5=[
    "Select an Option","Test","Refund Policy"
  ];
  String valueChoose6;
  List listItem6=[
    "Select an Option","Trending","Onsale","Bestseller","Beginner","Intermediate","Expert"
  ];
  String valueChoose7;
  List listItem7=[
    "Free","Paid"
  ];



  @override
  Widget build(BuildContext context) {
    Dio dio = new Dio();

    // String pathName = "";
    final picker = ImagePicker();

    String extractName(String path) {
      int i;
      for (i = path.length - 1; i >= 0; i--) {
        if (path[i] == "/") break;
      }
      return path.substring(i + 1);
    }

    Future getImageCamera() async {
      final pickedFile = await picker.getImage(source: ImageSource.camera);

      setState(() {
        if (pickedFile != null) {
          // imgCtl.text = extractName(_image.path);
          // _imgsel = true;
        } else {}
      });
    }

    Future getImageGallery() async {
      final pickedFile = await picker.getImage(source: ImageSource.gallery);

      setState(() {
        if (pickedFile != null) {
        } else {}
      });
    }

    void _showPicker(context) {
      showModalBottomSheet(
          context: context,
          builder: (BuildContext bc) {
            return SafeArea(
              child: Container(
                child: new Wrap(
                  children: <Widget>[
                    new ListTile(
                        leading: new Icon(Icons.photo_library),
                        title: new Text('Photo Library'),
                        onTap: () async {
                          await getImageGallery();
                          Navigator.of(context).pop();
                        }),
                    new ListTile(
                      leading: new Icon(Icons.photo_camera),
                      title: new Text('Camera'),
                      onTap: () async {
                        await getImageCamera();
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),
              ),
            );
          });
    }
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Add Courses",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed:(){
            Navigator.pop(context);
          },
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          padding: EdgeInsets.all(20),
          //color: Colors.blue,
          height: 2200,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              //Text('Add Courses',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
              SizedBox(height: 20,),
              Text('Categories:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              DropdownButton(
                hint: Text('Select an Option'),
                dropdownColor: Colors.white,
                icon: Icon(Icons.arrow_drop_down,color: Colors.red,),
                iconSize: 30,
                isExpanded: true,
               //underline: SizedBox(),
               // style: TextStyle(color: Colors.black,fontSize: 22),
                value: valueChoose,
                onChanged: (newValue){
                  setState(() {
                 valueChoose=newValue;
                  });
                },
                items: listItem.map((valueItem){
                  return DropdownMenuItem(
                    value: valueItem,
                    child: Text(valueItem),
                  );
                }).toList(),
              ),
              Text('Sub Categories',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              DropdownButton(
                hint: Text('Select an Option'),
                dropdownColor: Colors.white,
                icon: Icon(Icons.arrow_drop_down,color: Colors.red,),
                iconSize: 30,
                isExpanded: true,
                //underline: SizedBox(),
                // style: TextStyle(color: Colors.black,fontSize: 22),
                value: valueChoose1,
                onChanged: (newValue){
                  setState(() {
                    valueChoose1=newValue;
                  });
                },
                items: listItem1.map((valueItem){
                  return DropdownMenuItem(
                    value: valueItem,
                    child: Text(valueItem),
                  );
                }).toList(),
              ),
              Text('Child Categories:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              DropdownButton(
                hint: Text('Select an Option'),
                dropdownColor: Colors.white,
                icon: Icon(Icons.arrow_drop_down,color: Colors.red,),
                iconSize: 30,
                isExpanded: true,
                //underline: SizedBox(),
                // style: TextStyle(color: Colors.black,fontSize: 22),
                value: valueChoose2,
                onChanged: (newValue){
                  setState(() {
                    valueChoose2=newValue;
                  });
                },
                items: listItem2.map((valueItem){
                  return DropdownMenuItem(
                    value: valueItem,
                    child: Text(valueItem),
                  );
                }).toList(),
              ),
              Text('Instructor',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              DropdownButton(
                hint: Text('Select an Option'),
                dropdownColor: Colors.white,
                icon: Icon(Icons.arrow_drop_down,color: Colors.red,),
                iconSize: 30,
                isExpanded: true,
                //underline: SizedBox(),
                // style: TextStyle(color: Colors.black,fontSize: 22),
                value: valueChoose3,
                onChanged: (newValue){
                  setState(() {
                    valueChoose3=newValue;
                  });
                },
                items: listItem3.map((valueItem){
                  return DropdownMenuItem(
                    value: valueItem,
                    child: Text(valueItem),
                  );
                }).toList(),
              ),
              Text('Language:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              DropdownButton(
                hint: Text('Select an Option'),
                dropdownColor: Colors.white,
                icon: Icon(Icons.arrow_drop_down,color: Colors.red,),
                iconSize: 30,
                isExpanded: true,
                //underline: SizedBox(),
                // style: TextStyle(color: Colors.black,fontSize: 22),
                value: valueChoose4,
                onChanged: (newValue){
                  setState(() {
                    valueChoose4=newValue;
                  });
                },
                items: listItem4.map((valueItem){
                  return DropdownMenuItem(
                    value: valueItem,
                    child: Text(valueItem),
                  );
                }).toList(),
              ),
              Text('Select Refund Policy',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              DropdownButton(
                hint: Text('Select an Option'),
                dropdownColor: Colors.white,
                icon: Icon(Icons.arrow_drop_down,color: Colors.red,),
                iconSize: 30,
                isExpanded: true,
                //underline: SizedBox(),
                // style: TextStyle(color: Colors.black,fontSize: 22),
                value: valueChoose5,
                onChanged: (newValue){
                  setState(() {
                    valueChoose5=newValue;
                  });
                },
                items: listItem5.map((valueItem){
                  return DropdownMenuItem(
                    value: valueItem,
                    child: Text(valueItem),
                  );
                }).toList(),
              ),
              Text('Title:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Enter Title',
                    hintText: 'Enter Your Title'
                ),
              ),
              SizedBox(height: 5,),
              Text('Slug:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Enter Slug',
                    hintText: 'Slug'
                ),
              ),
              SizedBox(height: 5,),
              Text('Short Detail:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Enter Short Detail',
                    hintText: 'Enter Detail'
                ),
              ),
              SizedBox(height: 5,),
              Text('Requirement:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Enter Your Requirement',
                    hintText: 'Enter Requirement'
                ),
              ),
              SizedBox(height: 5,),
              Text('Detail:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Enter Your Detail',
                    hintText: 'Enter Detail'
                ),
              ),
              SizedBox(height: 5,),
              Text('Select Tag:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              DropdownButton(
                hint: Text('Select an Option'),
                dropdownColor: Colors.white,
                icon: Icon(Icons.arrow_drop_down,color: Colors.red,),
                iconSize: 30,
                isExpanded: true,
                //underline: SizedBox(),
                // style: TextStyle(color: Colors.black,fontSize: 22),
                value: valueChoose6,
                onChanged: (newValue){
                  setState(() {
                    valueChoose6=newValue;
                  });
                },
                items: listItem6.map((valueItem){
                  return DropdownMenuItem(
                    value: valueItem,
                    child: Text(valueItem),
                  );
                }).toList(),
              ),
              Text('Course Tags:*',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: ''
                ),
              ),
              SizedBox(height: 5,),
              Text('Free:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
               DropdownButton(
                hint: Text('Select an Option'),
                dropdownColor: Colors.white,
                icon: Icon(Icons.arrow_drop_down,color: Colors.red,),
                iconSize: 30,
                isExpanded: true,
                //underline: SizedBox(),
                // style: TextStyle(color: Colors.black,fontSize: 22),
                value: valueChoose7,
                onChanged: (newValue){
                  setState(() {
                    valueChoose7=newValue;
                  });
                },
                items: listItem7.map((valueItem){
                  return DropdownMenuItem(
                    value: valueItem,
                    child: Text(valueItem),
                  );
                }).toList(),
              ),
              TextField(
                decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Enter Price(if paid)/Optional'
                ),
              ),
              SizedBox(height: 5,),
              TextField(
                decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Enter Discount Price(if paid)/Optional'
                ),
              ),
              SizedBox(height: 5,),
             // GridView(),
              Text('Featured:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              CustomSwitch(),
              SizedBox(height: 5,),
              Text('Status:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              Status(),
              SizedBox(height: 5,),
              Text('Involvement',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              Text('Request:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              CustomSwitch(),
              //preview vedio:
              SizedBox(height: 5,),
              Text('Duration:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              Duration(),
              SizedBox(height: 5,),
              Text('Course Expire Duration:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Enter Course Expire Duration',
                    hintText: 'Enter Expire Duration'
                ),
              ),
              SizedBox(height: 5,),
              Text('Preview Video:- size:270x200',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              ListTile(
                leading: Icon(Icons.upload_rounded),
                // leading: CircleAvatar(
                //   backgroundImage: NetworkImage(imageUrl),
                // ),
                title: Text('Upload Video',style: TextStyle(
                  fontFamily: 'SF Pro',
                  fontSize: 15.0,
                ),),

                // contentPadding: EdgeInsets.symmetric(horizontal: 0.0),
                onTap: (){
                  _showPicker(context);
                },
              ),

              SizedBox(height: 10,),
             // ImagePicker(),
              Text('Instructors Revenue:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '%',
                    hintText: '%'
                ),
              ),
              Text('Assignment:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              Assign(),
              SizedBox(height: 5,),
              Text('Appointment:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              Assign(),
              SizedBox(height: 5,),
              Text('Certificate Enable:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              Assign(),
              SizedBox(height: 5,),
              Text('Drip Content:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              Drip(),
              SizedBox(height: 10,),
              Center(
                child: RaisedButton(
                  onPressed: () {
                    //Firstly Generate CheckSum bcoz Paytm Require this
                  //  generateTxnToken(0, payment.paytmMerchantId,
                    //    payment.paytmMerchantKey, userDetails.id);
                  },
                  color: const Color(0xFF01579B),
                  child: Text(
                    "Submit",
                    style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class CustomSwitch extends StatefulWidget {
  const CustomSwitch({Key key}) : super(key: key);

  @override
  _CustomSwitchState createState() => _CustomSwitchState();
}

class _CustomSwitchState extends State<CustomSwitch> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      // crossAxisAlignment: CrossAxisAlignment.start,
      //   mainAxisAlignment: MainAxisAlignment.center,
      // children: <Widget>[
      //   CustomSwitch(
      //     value: isSwitched,
      //     activeColor: Colors.blue,
      //     onChanged: (value){
      //       print('VALUE : $value');
      //       setState(() {
      //         isSwitched = value;
      //
      //       });
      //     },
      //   ),
      // ],
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "ON",
            textOff: "OFF",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.blur_on_rounded,
            iconOff: Icons.blur_off_rounded,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],

    );
  }
}

class Status extends StatefulWidget {
  const Status({Key key}) : super(key: key);

  @override
  _StatusState createState() => _StatusState();
}

class _StatusState extends State<Status> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Active",
            textOff: "Deactive",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.blur_on_rounded,
            iconOff: Icons.blur_off_rounded,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],

    );
  }
}

class Duration extends StatefulWidget {
  const Duration({Key key}) : super(key: key);

  @override
  _DurationState createState() => _DurationState();
}

class _DurationState extends State<Duration> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Days",
            textOff: "Month",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.calendar_view_day_sharp,
            iconOff: Icons.calendar_view_month,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],

    );
  }
}

class Assign extends StatefulWidget {
  const Assign({Key key}) : super(key: key);

  @override
  _AssignState createState() => _AssignState();
}

class _AssignState extends State<Assign> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Yes",
            textOff: "No",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.check,
            iconOff: Icons.not_interested,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],
    );
  }
}

class Drip extends StatefulWidget {
  const Drip({Key key}) : super(key: key);

  @override
  _DripState createState() => _DripState();
}

class _DripState extends State<Drip> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Enable",
            textOff: "Disable",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.check,
            iconOff: Icons.not_interested_rounded,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],
    );
  }
}


















