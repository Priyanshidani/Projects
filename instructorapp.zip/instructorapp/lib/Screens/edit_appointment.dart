import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../common/theme.dart' as T;
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:dio/dio.dart';
import 'package:image_picker/image_picker.dart';

class EditAppointment extends StatefulWidget {
  const EditAppointment({Key key}) : super(key: key);

  @override
  _EditAppointmentState createState() => _EditAppointmentState();
}

class _EditAppointmentState extends State<EditAppointment> {
  @override
  Widget build(BuildContext context) {
    Dio dio = new Dio();

    // String pathName = "";
    File _image;
    final picker = ImagePicker();

    String extractName(String path) {
      int i;
      for (i = path.length - 1; i >= 0; i--) {
        if (path[i] == "/") break;
      }
      return path.substring(i + 1);
    }

    Future getImageCamera() async {
      final pickedFile = await picker.getImage(source: ImageSource.camera);

      setState(() {
        if (pickedFile != null) {
          _image = File(pickedFile.path);
          // imgCtl.text = extractName(_image.path);
          // _imgsel = true;
        } else {}
      });
    }

    Future getImageGallery() async {
      final pickedFile = await picker.getImage(source: ImageSource.gallery);

      setState(() {
        if (pickedFile != null) {
          _image = File(pickedFile.path);
        } else {}
      });
    }

    void _showPicker(context) {
      showModalBottomSheet(
          context: context,
          builder: (BuildContext bc) {
            return SafeArea(
              child: Container(
                child: new Wrap(
                  children: <Widget>[
                    new ListTile(
                        leading: new Icon(Icons.photo_library),
                        title: new Text('Photo Library'),
                        onTap: () async {
                          await getImageGallery();
                          Navigator.of(context).pop();
                        }),
                    new ListTile(
                      leading: new Icon(Icons.photo_camera),
                      title: new Text('Camera'),
                      onTap: () async {
                        await getImageCamera();
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),
              ),
            );
          });
    }

    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Edit Appointment",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed:(){
            Navigator.pop(context);
          },
        ),

      ),
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          child: ListView.builder(
            padding: EdgeInsets.only(bottom: 100.0),
            itemCount: 1,
            itemBuilder: (BuildContext context , int idx)=>
                Column(
                  children: <Widget>[
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      alignment: Alignment.bottomLeft,
                      margin: EdgeInsets.fromLTRB(20, 10, 20, 15),

                      padding: EdgeInsets.all(6.0),
                      height: 564,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                              color: Color(0x1c2464).withOpacity(0.30),
                              blurRadius: 25.0,
                              offset: Offset(0.0, 20.0),
                              spreadRadius: -15.0)
                        ],
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          InkWell(
                            child: CircleAvatar(
                              radius: 40.0,
                              backgroundColor: Colors.white,
                              child: CircleAvatar(
                                child: Align(
                                  alignment: Alignment.bottomRight,
                                  child: CircleAvatar(
                                    backgroundColor: Colors.white,
                                    radius: 12.0,
                                    child: Icon(
                                      Icons.camera_alt,
                                      size: 15.0,
                                      color: Color(0xFF404040),

                                    ),
                                  ),
                                ),
                                radius: 48.0,
                                // backgroundImage: AssetImage(
                                //     'assets/images/user-image-default.png'),
                              ),
                            ),
                            onTap: () {
                              _showPicker(context);
                            },
                          ),
                          ListTile(
                              leading: Icon(Icons.person,color:mode.easternBlueColor),
                              title: Text('User',style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.bold
                              ),),
                              subtitle: Text('Agnes Victoire Baganda',style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                fontWeight: FontWeight.normal,
                              ),)
                          ),
                          ListTile(
                            leading: Icon(Icons.menu_book_sharp,color:mode.easternBlueColor),
                            title: Text(
                              'Courses',
                              style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 15.0,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold
                              ),
                            ),
                            subtitle: Text('Listening & Speaking Beginner(LS101)',
                              style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.normal
                              ),),
                          ),
                          ListTile(
                              leading: Icon(Icons.drive_file_rename_outline,color:mode.easternBlueColor),
                              title: Text('Title :',style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,
                              ),),
                              subtitle: Text('Discuss the board',style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                fontWeight: FontWeight.normal,
                              ),)
                          ),
                          ListTile(
                            leading: Icon(Icons.details,color:mode.easternBlueColor),
                            title: Text(
                              'Detail :',
                              style: TextStyle(
                                fontFamily: 'SF Pro',
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            subtitle: Text('Hello Sir,\n Can I Discuss the board with you?',style: TextStyle(
                              fontFamily: 'SF Pro',
                              fontSize: 15.0,
                              fontWeight: FontWeight.normal,
                            ),),
                          ),

                          Padding(
                            padding: const EdgeInsets.all(14.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text("Accept",style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,

                                ),
                                ),

                                SizedBox(
                                  height: 40,
                                  width: 120,
                                  child: LiteRollingSwitch(
                                    value: true,
                                    textOn: 'Yes',
                                    textOff: 'No',
                                    colorOn: Colors.green,
                                    colorOff: Colors.red,
                                    iconOn: Icons.check,
                                    iconOff: Icons.power_settings_new,
                                    onChanged: (bool state) {
                                      print('turned ${(state) ? 'Yes' : 'No'}');
                                    },
                                  ),
                                ),

                              ],
                            ),
                          ),
                          Center(
                            child: Padding(
                              padding: const EdgeInsets.all(6.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  RaisedButton(
                                    color: Colors.red,
                                    onPressed: (){},
                                    child: Text('Reset',style: TextStyle(
                                      fontFamily: 'SF Pro',
                                      fontSize: 12.0,
                                      color:Colors.white,
                                    ),),

                                  ),
                                  SizedBox(width:15),
                                  RaisedButton(
                                    color: Colors.red,
                                    onPressed: (){},
                                    child: Text('Update',style: TextStyle(
                                      fontFamily: 'SF Pro',
                                      fontSize: 12.0,
                                      color:Colors.white,
                                    ),),

                                  ),
                                ],
                              ),
                            ),
                          ),

                        ],
                      ),

                    ),


                  ],
                ),
          ),
        ),
      ),
    );
  }
}