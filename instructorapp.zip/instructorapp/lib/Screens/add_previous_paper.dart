import 'package:eclass/Screens/vacation_enable.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:dio/dio.dart';
import '../common/theme.dart' as T;
import 'package:provider/provider.dart';


class AddPreviousPaper extends StatefulWidget {
  const AddPreviousPaper({Key key}) : super(key: key);

  @override
  _AddPreviousPaperState createState() => _AddPreviousPaperState();
}

class _AddPreviousPaperState extends State<AddPreviousPaper> {


  final picker = ImagePicker();
  Color newColor;
  String valueChoose;
  List listItem=[
    "Select an Option","A","B","C","D",
  ];




  @override
  Widget build(BuildContext context) {
    Dio dio = new Dio();

    // String pathName = "";
    final picker = ImagePicker();

    String extractName(String path) {
      int i;
      for (i = path.length - 1; i >= 0; i--) {
        if (path[i] == "/") break;
      }
      return path.substring(i + 1);
    }

    Future getImageCamera() async {
      final pickedFile = await picker.getImage(source: ImageSource.camera);

      setState(() {
        if (pickedFile != null) {
          // imgCtl.text = extractName(_image.path);
          // _imgsel = true;
        } else {}
      });
    }

    Future getImageGallery() async {
      final pickedFile = await picker.getImage(source: ImageSource.gallery);

      setState(() {
        if (pickedFile != null) {
        } else {}
      });
    }

    void _showPicker(context) {
      showModalBottomSheet(
          context: context,
          builder: (BuildContext bc) {
            return SafeArea(
              child: Container(
                child: new Wrap(
                  children: <Widget>[
                    new ListTile(
                        leading: new Icon(Icons.photo_library),
                        title: new Text('Photo Library'),
                        onTap: () async {
                          await getImageGallery();
                          Navigator.of(context).pop();
                        }),
                    new ListTile(
                      leading: new Icon(Icons.photo_camera),
                      title: new Text('Camera'),
                      onTap: () async {
                        await getImageCamera();
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),
              ),
            );
          });
    }
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Add Previous Paper",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed:(){
            Navigator.pop(context);
          },
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          padding: EdgeInsets.all(20),
          //color: Colors.blue,
          height: 2200,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Title:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: 'Enter Title'
                ),
              ),
              SizedBox(height: 5,),
              Text('Detail',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: 'Detail'
                ),
              ),
              SizedBox(height: 5,),
              Text('Paper Upload',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              ListTile(
                leading: Icon(Icons.upload_rounded),
                // leading: CircleAvatar(
                //   backgroundImage: NetworkImage(imageUrl),
                // ),
                title: Text('Upload',style: TextStyle(
                  fontFamily: 'SF Pro',
                  fontSize: 15.0,
                ),),

                // contentPadding: EdgeInsets.symmetric(horizontal: 0.0),
                onTap: (){
                  _showPicker(context);
                },
              ),
              SizedBox(height: 5,),
              Text('Status',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              CustomSwitch(),
              SizedBox(height: 10,),
              Row(
                children:[
                  RaisedButton(
                    onPressed: () {

                    },
                    color: const Color(0xFF01579B),
                    child: Text(
                      "Reset",
                      style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),
                    ),
                  ),
                  SizedBox(width: 50,),
                  RaisedButton(
                    onPressed: () {

                    },
                    color: const Color(0xFF01579B),
                    child: Text(
                      "Create",
                      style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class CustomSwitch extends StatefulWidget {
  const CustomSwitch({Key key}) : super(key: key);

  @override
  _CustomSwitchState createState() => _CustomSwitchState();
}

class _CustomSwitchState extends State<CustomSwitch> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "",
            textOff: "",
            colorOn: Colors.red,
            colorOff: Colors.green,
            iconOn: Icons.blur_off_rounded,
            iconOff: Icons.blur_on_rounded,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],

    );
  }
}

class Status extends StatefulWidget {
  const Status({Key key}) : super(key: key);

  @override
  _StatusState createState() => _StatusState();
}

class _StatusState extends State<Status> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Deactive",
            textOff: "Active",
            colorOn: Colors.red,
            colorOff: Colors.green,
            iconOn: Icons.blur_off_rounded,
            iconOff: Icons.blur_on_rounded,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],

    );
  }
}

class Duration extends StatefulWidget {
  const Duration({Key key}) : super(key: key);

  @override
  _DurationState createState() => _DurationState();
}

class _DurationState extends State<Duration> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Days",
            textOff: "Month",
            colorOn: Colors.red,
            colorOff: Colors.green,
            iconOn: Icons.calendar_view_day_sharp,
            iconOff: Icons.calendar_view_month,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],

    );
  }
}

class Assign extends StatefulWidget {
  const Assign({Key key}) : super(key: key);

  @override
  _AssignState createState() => _AssignState();
}

class _AssignState extends State<Assign> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Yes",
            textOff: "No",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.check,
            iconOff: Icons.not_interested,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],
    );
  }
}

class Drip extends StatefulWidget {
  const Drip({Key key}) : super(key: key);

  @override
  _DripState createState() => _DripState();
}

class _DripState extends State<Drip> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Disable",
            textOff: "Enable",
            colorOn: Colors.red,
            colorOff: Colors.green,
            iconOn: Icons.not_interested,
            iconOff: Icons.check,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],
    );
  }
}

class date extends StatefulWidget {
  const date({Key key}) : super(key: key);

  @override
  _dateState createState() => _dateState();
}

class _dateState extends State<date> {
  String _dateofbirth = "";
  bool _datesel = false;
  TextEditingController dobCtrl = new TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 90,
      child: TextFormField(
        controller: dobCtrl,
        validator: (value) {
          if (value == "")
            return "Please choose a valid dob!";
          else
            return null;
        },
        readOnly: true,
        style: TextStyle(
          //color: txtColor,
            fontSize: 17,
            fontWeight: _datesel ? FontWeight.normal : FontWeight.w600),
        decoration: InputDecoration(
          // focusedBorder: foborder(borderClr),
          // enabledBorder: enborder(borderClr),
            labelText: "Select Date and Time",hintStyle: (TextStyle(fontWeight: FontWeight.bold)),
            //  labelStyle: _labelStyle,
            suffixIcon: IconButton(
                icon: Icon(
                  Icons.calendar_today,
                  color: Colors.grey,
                ),
                onPressed: () async {
                  DateTime date = DateTime(1900);
                  FocusScope.of(context).requestFocus(new FocusNode());

                  date = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(1900),
                      lastDate: DateTime(2100));
                  setState(() {
                    _datesel = true;
                    _dateofbirth = date.toIso8601String();
                  });
                  dobCtrl.text = "${date.day}/${date.month}/${date.year}";
                })),
      ),
    );
  }
}
