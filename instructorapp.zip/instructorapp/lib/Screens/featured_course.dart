import 'package:eclass/Screens/add_featured_course.dart';
import 'package:eclass/Screens/search_result_screen.dart';
import 'package:eclass/Screens/view_featured_courses.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import '../common/theme.dart' as T;

class FeaturedCourses extends StatefulWidget {
  const FeaturedCourses({Key key}) : super(key: key);

  @override
  _FeaturedCoursesState createState() => _FeaturedCoursesState();
}

class _FeaturedCoursesState extends State<FeaturedCourses> {
  String valueChoose;
  bool isPopupVisible = false;
  @override
  Widget build(BuildContext context) {
    List<String> list = List.generate(10, (index) => "Text $index");
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Feature Courses",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed:(){
            Navigator.pop(context);
          },
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.search,color: Colors.black,),
            onPressed: () {
              showSearch(context: context, delegate: Search(list));
            },
          ),
        ],
      ),
      body: Stack(
        children:[
          SingleChildScrollView(
            child: Container(
              height: MediaQuery.of(context).size.height,
              child: ListView.builder(
                padding: EdgeInsets.only(bottom: 100.0),
                itemCount: 1,
                itemBuilder: (BuildContext context , int idx)=>
                    Column(
                      children: <Widget>[
                        SizedBox(
                          height: 20,
                        ),
                        Container(
                          alignment: Alignment.bottomLeft,
                          margin: EdgeInsets.fromLTRB(20, 10, 20, 15),

                          padding: EdgeInsets.all(6.0),
                          height: 437,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                  color: Color(0x1c2464).withOpacity(0.30),
                                  blurRadius: 25.0,
                                  offset: Offset(0.0, 20.0),
                                  spreadRadius: -15.0)
                            ],
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              ListTile(
                                  leading: Icon(Icons.person,color: mode.easternBlueColor,),
                                  title: Text('User',style: TextStyle(
                                      fontFamily: 'SF Pro',
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold
                                  ),),
                                  subtitle: Text('Instructor',style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.normal,
                                  ),)
                              ),
                              ListTile(
                                leading: Icon(Icons.menu_book_sharp,color: mode.easternBlueColor,),
                                title: Text(
                                  'Courses',
                                  style: TextStyle(
                                      fontFamily: 'SF Pro',
                                      fontSize: 15.0,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold
                                  ),
                                ),
                                subtitle: Text('Internationally Accredited Diploma In Yoga Training',
                                  style: TextStyle(
                                      fontFamily: 'SF Pro',
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.normal
                                  ),),
                              ),
                              ListTile(
                                leading: Icon(Icons.domain_verification_sharp,color: mode.easternBlueColor,),
                                title: Text(
                                  'Transaction ID',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.bold,

                                  ),
                                ),
                                subtitle: Text(
                                  'PAYID -L2NMPLAWE234567UI',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                                ),
                              ),
                              ListTile(
                                leading: Icon(Icons.money_sharp,color: mode.easternBlueColor,),
                                title: Text(
                                  'Payment Method',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.bold,

                                  ),
                                ),
                                subtitle: Text(
                                  'Paypal',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                                ),
                              ),
                              ListTile(
                                leading: Icon(Icons.attach_money_outlined,color: mode.easternBlueColor,),
                                title: Text(
                                  'Total Amount',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.bold,

                                  ),
                                ),
                                subtitle: Text(
                                  'Rs- 100',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    color:Colors.green,
                                    fontWeight: FontWeight.normal,
                                  ),
                                ),
                              ),


                              Padding(
                                padding: const EdgeInsets.all(6.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    IconButton(onPressed: (){
                                      setState(() {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) => ViewFeaturedCourses()));
                                      });
                                    },
                                      icon: Icon(Icons.remove_red_eye_rounded,color:mode.easternBlueColor),),
                                    SizedBox(width:15),
                                    IconButton(
                                      onPressed: (){
                                        setState(() {
                                          this.isPopupVisible = true;
                                        });
                                      },
                                      icon: Icon(FontAwesomeIcons.trashAlt,color: Colors.red,),
                                      iconSize: 22,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),

                        ),
                      ],
                    ),
              ),
            ),
          ),isPopupVisible ? Center(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 24.0),
              child: Container(
                padding: EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                    color: mode.bgcolor,
                    boxShadow: [
                      BoxShadow(
                          color: Color(0x1c2464).withOpacity(0.30),
                          blurRadius: 25.0,
                          offset: Offset(0.0, 20.0),
                          spreadRadius: -15.0)
                    ],
                    borderRadius: BorderRadius.all(Radius.circular(5.0))
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('Do you want to delete?'),
                    SizedBox(height: 24.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton(onPressed: () {
                          setState(() {
                            isPopupVisible = false;
                          });
                        }, child: Text('No')),
                        ElevatedButton(onPressed: ()=>print('Hi'), child: Text('Yes')),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ):SizedBox(height: 0,width: 0,)],
      ),
      floatingActionButton: FloatingActionButton.extended(
        elevation: 5.0,
        onPressed: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => AddFeaturedCourse()));
        },
        backgroundColor: mode.easternBlueColor,
        label: Text(
          "+ Add Course",
          style: TextStyle(fontWeight: FontWeight.w500, fontSize: 18.0),
        ),
      ),
    );
  }
}