import 'package:eclass/Screens/announcement.dart';
import 'package:flutter/material.dart';
import 'package:eclass/common/theme.dart' as T;
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:provider/provider.dart';

class EditRelatedCourse extends StatefulWidget {
  const EditRelatedCourse({Key key}) : super(key: key);

  @override
  _EditRelatedCourseState createState() => _EditRelatedCourseState();
}

class _EditRelatedCourseState extends State<EditRelatedCourse> {
  String valueChoose;
  List listItem=[
    "Wordpress Theme Development","Ultimate Boxing Training:Professional Boxing Techniques","Ultimate Photoshop Training"
  ];
  String valueChoose1;
  List listItem1=[
    "Admin",""
  ];
  @override
  Widget build(BuildContext context) {
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Related Courses:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
            DropdownButton(
              hint: Text('Select an Option'),
              dropdownColor: Colors.white,
              icon: Icon(Icons.arrow_drop_down,color: Colors.red,),
              iconSize: 30,
              isExpanded: true,
              //underline: SizedBox(),
              // style: TextStyle(color: Colors.black,fontSize: 22),
              value: valueChoose,
              onChanged: (newValue){
                setState(() {
                  valueChoose=newValue;
                });
              },
              items: listItem.map((valueItem){
                return DropdownMenuItem(
                  value: valueItem,
                  child: Text(valueItem),
                );
              }).toList(),
            ),
            SizedBox(height: 5,),
            Text('Edit Related Course:',style: TextStyle(fontWeight: FontWeight.normal,fontSize: 15),),
            Status(),
            SizedBox(height: 20,),
            Row(
              children: [
                RaisedButton(
                  color: Colors.red,
                  // color: mode.easternBlueColor,
                  child: Text("Reset", style: TextStyle(color: Colors.white),),
                  onPressed: () {
                    // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
                  },
                ),
                SizedBox(width: 50,),
                RaisedButton(
                  color: Colors.red,
                  // color: mode.easternBlueColor,
                  child: Text("Create", style: TextStyle(color: Colors.white),),
                  onPressed: () {
                    // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
                  },
                ),
              ],
            )
          ],
        ),
      ),
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Edit Related Course",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
    );
  }
}

class Status extends StatefulWidget {
  const Status({Key key}) : super(key: key);

  @override
  _StatusState createState() => _StatusState();
}

class _StatusState extends State<Status> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Active",
            textOff: "Deactive",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.blur_on_rounded,
            iconOff: Icons.blur_off_rounded,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],

    );
  }
}