import 'dart:io';
import 'package:eclass/Screens/edit_request_to_involve.dart';
import 'package:eclass/Screens/search_result_screen.dart';
import 'package:eclass/Widgets/custom_drawer.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import '../common/theme.dart' as T;
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:dio/dio.dart';
import 'package:image_picker/image_picker.dart';

class RequestToInvolve extends StatefulWidget {
  const RequestToInvolve({Key key}) : super(key: key);

  @override
  _RequestToInvolveState createState() => _RequestToInvolveState();
}

class _RequestToInvolveState extends State<RequestToInvolve> {
  String valueChoose;
  bool isPopupVisible = false;
  @override
  Widget build(BuildContext context) {
    Dio dio = new Dio();

    // String pathName = "";
    File _image;
    final picker = ImagePicker();

    String extractName(String path) {
      int i;
      for (i = path.length - 1; i >= 0; i--) {
        if (path[i] == "/") break;
      }
      return path.substring(i + 1);
    }

    Future getImageCamera() async {
      final pickedFile = await picker.getImage(source: ImageSource.camera);

      setState(() {
        if (pickedFile != null) {
          _image = File(pickedFile.path);
          // imgCtl.text = extractName(_image.path);
          // _imgsel = true;
        } else {}
      });
    }

    Future getImageGallery() async {
      final pickedFile = await picker.getImage(source: ImageSource.gallery);

      setState(() {
        if (pickedFile != null) {
          _image = File(pickedFile.path);
        } else {}
      });
    }

    void _showPicker(context) {
      showModalBottomSheet(
          context: context,
          builder: (BuildContext bc) {
            return SafeArea(
              child: Container(
                child: new Wrap(
                  children: <Widget>[
                    new ListTile(
                        leading: new Icon(Icons.photo_library),
                        title: new Text('Photo Library'),
                        onTap: () async {
                          await getImageGallery();
                          Navigator.of(context).pop();
                        }),
                    new ListTile(
                      leading: new Icon(Icons.photo_camera),
                      title: new Text('Camera'),
                      onTap: () async {
                        await getImageCamera();
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),
              ),
            );
          });
    }
    List<String> list = List.generate(10, (index) => "Text $index");
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Request To Involve",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed:(){
            Navigator.pop(context);
          },
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.search,color: Colors.black,),
            onPressed: () {
              showSearch(context: context, delegate: Search(list));
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            child: Container(
              height: MediaQuery.of(context).size.height,
              child: ListView.builder(
                padding: EdgeInsets.only(bottom: 100.0),
                itemCount: 4,
                itemBuilder: (BuildContext context , int idx)=>
                    Column(
                      children: <Widget>[
                        SizedBox(
                          height: 20,
                        ),
                        Container(
                          alignment: Alignment.bottomLeft,
                          margin: EdgeInsets.fromLTRB(20, 10, 20, 15),

                          padding: EdgeInsets.all(6.0),
                          height: 450,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                  color: Color(0x1c2464).withOpacity(0.30),
                                  blurRadius: 25.0,
                                  offset: Offset(0.0, 20.0),
                                  spreadRadius: -15.0)
                            ],
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              InkWell(
                                child: CircleAvatar(
                                  radius: 40.0,
                                  backgroundColor: Colors.white,
                                  child: CircleAvatar(
                                    child: Align(
                                      alignment: Alignment.bottomRight,
                                      child: CircleAvatar(
                                        backgroundColor: Colors.white,
                                        radius: 12.0,
                                        child: Icon(
                                          Icons.camera_alt,
                                          size: 15.0,
                                          color: Color(0xFF404040),

                                        ),
                                      ),
                                    ),
                                    radius: 48.0,
                                    // backgroundImage: AssetImage(
                                    //     'assets/images/user-image-default.png'),
                                  ),
                                ),
                                onTap: () {
                                  _showPicker(context);
                                },
                              ),


                              ListTile(
                                  leading: Icon(Icons.drive_file_rename_outline,color: mode.easternBlueColor,),
                                  title: Text('Title :',style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.bold,
                                  ),),
                                  subtitle: Text('Art & Science of Drawing- Ultimate Drawing Course',style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.normal,
                                  ),)
                              ),
                              ListTile(
                                leading: Icon(Icons.book_online_rounded,color: mode.easternBlueColor,),
                                title: Text(
                                  'Slug :',
                                  style: TextStyle(
                                    fontFamily: 'SF Pro',
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                subtitle: Text('art-science-of-drawing-ultimate-drawing-course',style: TextStyle(
                                  fontFamily: 'SF Pro',
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.normal,
                                ),),
                              ),

                              Padding(
                                padding: const EdgeInsets.all(14.0),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Text("Featured",style: TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold
                                    ),
                                    ),

                                    SizedBox(
                                      height: 40,
                                      width: 120,
                                      child: LiteRollingSwitch(
                                        value: true,
                                        textOn: 'Enabled',
                                        textOff: 'Disable',
                                        colorOn: Colors.green,
                                        colorOff: Colors.red,
                                        iconOn: Icons.check,
                                        iconOff: Icons.power_settings_new,
                                        onChanged: (bool state) {
                                          print('turned ${(state) ? 'Enabled' : 'Disable'}');
                                        },
                                      ),
                                    ),
                                    SizedBox(height:10),
                                    Text("Status",style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    ),

                                    SizedBox(
                                      height: 40,
                                      width: 120,
                                      child: LiteRollingSwitch(
                                        value: true,
                                        textOn: 'Active',
                                        textOff: 'Deactive',
                                        colorOn: Colors.green,
                                        colorOff: Colors.red,
                                        iconOn: Icons.check,
                                        iconOff: Icons.power_settings_new,
                                        textSize: 12,
                                        onChanged: (bool state) {
                                          print('turned ${(state) ? 'Active' : 'Deactive'}');
                                        },
                                      ),
                                    )
                                  ],
                                ),
                              ),

                              Center(
                                child: Padding(
                                  padding: const EdgeInsets.all(1.0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      IconButton(onPressed: (){
                                        setState(() {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) => EditRequestToInvolve()));
                                        });
                                      },
                                        icon: Icon(Icons.edit_location_outlined,color:mode.easternBlueColor),),
                                      SizedBox(width:15),
                                      IconButton(
                                        onPressed: (){
                                          setState(() {
                                            this.isPopupVisible = true;
                                          });
                                        },
                                        icon: Icon(FontAwesomeIcons.trashAlt,color: Colors.red,),
                                        iconSize: 22,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),

                        ),

                      ],
                    ),
              ),
            ),
          ),isPopupVisible ? Center(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 24.0),
              child: Container(
                padding: EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                    color: mode.bgcolor,
                    boxShadow: [
                      BoxShadow(
                          color: Color(0x1c2464).withOpacity(0.30),
                          blurRadius: 25.0,
                          offset: Offset(0.0, 20.0),
                          spreadRadius: -15.0)
                    ],
                    borderRadius: BorderRadius.all(Radius.circular(5.0))
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('Do you want to delete?'),
                    SizedBox(height: 24.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton(onPressed: () {
                          setState(() {
                            isPopupVisible = false;
                          });
                        }, child: Text('No')),
                        ElevatedButton(onPressed: ()=>print('Hi'), child: Text('Yes')),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ):SizedBox(height: 0,width: 0,)],
      ),
    );
  }
}