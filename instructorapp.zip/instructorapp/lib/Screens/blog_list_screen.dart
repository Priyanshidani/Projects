import 'package:eclass/Screens/add_courses.dart';
import 'package:eclass/Screens/addblog.dart';
import 'package:eclass/Screens/blog_screen.dart';
import 'package:eclass/Screens/edit_blog.dart';
import 'package:eclass/Screens/edit_courses.dart';
import 'package:eclass/Screens/search_result_screen.dart';
import 'package:eclass/Widgets/appbar.dart';
import 'package:eclass/Widgets/custom_drawer.dart';
import 'package:eclass/common/apidata.dart';
import 'package:eclass/provider/blog_provider.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'package:eclass/common/theme.dart' as T;

class BlogListScreen extends StatefulWidget {

  @override
  _BlogListScreenState createState() => _BlogListScreenState();
}

class _BlogListScreenState extends State<BlogListScreen> {
bool _visible = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      final blogs= Provider.of<BlogProvider>(context, listen: false);
      await blogs.fetchBlogList(context);
      setState(() {
        _visible = true;
      });
    });
  }
List<String> list = List.generate(10, (index) => "Text $index");
  @override
  Widget build(BuildContext context) {
    var blogModel = Provider.of<BlogProvider>(context).blogModel;
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Blogs",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.search,color: Colors.black,),
            onPressed: () {
              showSearch(context: context, delegate: Search(list));
            },
          ),
        ],
      ),
      body: _visible == true ? ListView.builder(
          padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 15.0),
          itemCount: blogModel.blog.length,
          itemBuilder: (context, index){
            return Container(
              height: 400,
              margin: EdgeInsets.only(bottom: 20.0),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Material(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(10.0),
                child: InkWell(
                  borderRadius: BorderRadius.circular(10.0),
                  child: Container(
                    margin: EdgeInsets.only(bottom: 10.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(10.0),
                            topRight: Radius.circular(10.0),
                          ),
                          child: Image.network("${APIData.blogImage}${blogModel.blog[index].image}",
                            height: 200,
                            fit: BoxFit.cover,
                            width: double.infinity,
                            alignment: Alignment.center,),
                        ),
                        SizedBox(
                          height: 15.0,
                        ),
                        Padding(padding: EdgeInsets.symmetric(horizontal: 10.0),
                          child: Text("${blogModel.blog[index].heading}", style: TextStyle(fontSize: 18.0,
                              color: mode.titleTextColor,
                              fontWeight: FontWeight.w700), maxLines: 2, overflow: TextOverflow.ellipsis,),),
                        SizedBox(
                          height: 5.0,
                        ),
                        Padding(padding: EdgeInsets.symmetric(horizontal: 10.0), child: Text(
                          DateFormat.yMMMd().format(DateTime.parse("${blogModel.blog[index].updatedAt}"),),
                          style: TextStyle(
                              color: mode.titleTextColor.withOpacity(0.5),
                              fontSize: 13.0),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),),
                        SizedBox(
                          height: 5.0,
                        ),
                        Padding(padding: EdgeInsets.symmetric(horizontal: 10.0),
                          child: Text(
                            "${blogModel.blog[index].detail}",
                            style: TextStyle(
                                color: mode.titleTextColor.withOpacity(0.7),
                                fontSize: 13.0),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            IconButton(onPressed: (){
                              setState(() {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => EditBlog()));
                              });
                            },
                              icon: Icon(Icons.edit_location_outlined,color: mode.easternBlueColor,),),
                            SizedBox(width: 15),
                            IconButton(onPressed: (){},
                              icon: Icon(FontAwesomeIcons.trashAlt,color: Colors.red,),
                              iconSize: 22,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          }) : Center(
        child: CircularProgressIndicator(),
      ),
      floatingActionButton: FloatingActionButton.extended(
        elevation: 5.0,
        onPressed: () {
          //showAlertDialog(context, mode, widget.courseDetail.course.id, appointment);
          Navigator.push(context, MaterialPageRoute(builder: (context)=>AddBlog()));
          //Navigator.push(context, MaterialPageRoute(builder: (context)=>Image()));
        },
        backgroundColor: mode.easternBlueColor,
        label: Text(
          "+ Add Blogs",
          style: TextStyle(fontWeight: FontWeight.w500, fontSize: 18.0),
        ),
      ),
    );
  }
}

