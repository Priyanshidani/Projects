import 'dart:io';
import 'package:custom_switch/custom_switch.dart';
import 'package:eclass/Screens/add_category.dart';
import 'package:eclass/Screens/bigblue_list_meeting.dart';
import 'package:eclass/Screens/courses_screen.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:dio/dio.dart';
import 'package:image_picker/image_picker.dart';
import '../common/theme.dart' as T;
import 'package:provider/provider.dart';


class EditBigblueMeeting extends StatefulWidget {
  const EditBigblueMeeting({Key key}) : super(key: key);

  @override
  _EditBigblueMeetingState createState() => _EditBigblueMeetingState();
}

class _EditBigblueMeetingState extends State<EditBigblueMeeting> {


  final picker = ImagePicker();
  Color newColor;
  String valueChoose;
  List listItem=[
    "Select an Option","Design","Development","Music","Photography","Game"
  ];
  String valueChoose1;
  List listItem1=[
    "Select an Option"
  ];
  String valueChoose2;
  List listItem2=[
    "Select an Option"
  ];
  String valueChoose3;
  List listItem3=[
    "Select an Option"
  ];
  String valueChoose4;
  List listItem4=[
    "Select an Option","English","Hindi","French","Spanish"
  ];
  String valueChoose5;
  List listItem5=[
    "Select an Option","Test","Refund Policy"
  ];
  String valueChoose6;
  List listItem6=[
    "Select an Option","Trending","Onsale","Bestseller","Beginner","Intermediate","Expert"
  ];
  String valueChoose7;
  List listItem7=[
    "Free","Paid"
  ];



  @override
  Widget build(BuildContext context) {
    Dio dio = new Dio();

    // String pathName = "";
    final picker = ImagePicker();

    String extractName(String path) {
      int i;
      for (i = path.length - 1; i >= 0; i--) {
        if (path[i] == "/") break;
      }
      return path.substring(i + 1);
    }

    Future getImageCamera() async {
      final pickedFile = await picker.getImage(source: ImageSource.camera);

      setState(() {
        if (pickedFile != null) {
          // imgCtl.text = extractName(_image.path);
          // _imgsel = true;
        } else {}
      });
    }

    Future getImageGallery() async {
      final pickedFile = await picker.getImage(source: ImageSource.gallery);

      setState(() {
        if (pickedFile != null) {
        } else {}
      });
    }

    void _showPicker(context) {
      showModalBottomSheet(
          context: context,
          builder: (BuildContext bc) {
            return SafeArea(
              child: Container(
                child: new Wrap(
                  children: <Widget>[
                    new ListTile(
                        leading: new Icon(Icons.photo_library),
                        title: new Text('Photo Library'),
                        onTap: () async {
                          await getImageGallery();
                          Navigator.of(context).pop();
                        }),
                    new ListTile(
                      leading: new Icon(Icons.photo_camera),
                      title: new Text('Camera'),
                      onTap: () async {
                        await getImageCamera();
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),
              ),
            );
          });
    }
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Edit Meeting",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          padding: EdgeInsets.all(20),
          //color: Colors.blue,
          height: 1000,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Link By Course:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              CustomSwitch(),
              Text('Presenter Name:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '123456',
                    hintText: ''
                ),
              ),
              Text('Meeting ID',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Test',
                    hintText: ''
                ),
              ),
              Text('Meeting Name:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Test',
                    hintText: ''
                ),
              ),
              Text('Meeting Duration',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: '40'
                ),
              ),
              Text('Moderator Password:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '**',
                    hintText: 'Enter Moderator Password'
                ),
              ),
              Text('Attandee Password',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              Text('(Tip! Share your attendee password to students using social handling networks.)',style: TextStyle(fontWeight: FontWeight.normal,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '**',
                    hintText: 'Enter attendee password'
                ),
              ),
              Text('Should be different from Moderator Password',style: TextStyle(fontWeight: FontWeight.normal,fontSize: 15),),
              Text('Set Welcome Message:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: 'Enter welcome message'
                ),
              ),
              SizedBox(height: 5,),
              Text('Set Max Participants:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: '',
                    hintText: 'enter maximum participant no., leave blank if want unlimited participant'
                ),
              ),
              SizedBox(height: 5,),
              Text('Set Mute On Start:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              Status(),
              Text('Allow Record:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
              Status(),
              SizedBox(height: 10,),
              Row(
                children:[
                  RaisedButton(
                    onPressed: () {
                    },
                    color: Colors.red,
                    child: Text(
                      "Reset",
                      style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),
                    ),
                  ),
                  SizedBox(width: 120,),
                  RaisedButton(
                    onPressed: () {
                    },
                    color: Colors.red,
                    child: Text(
                      "Update",
                      style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class CustomSwitch extends StatefulWidget {
  const CustomSwitch({Key key}) : super(key: key);

  @override
  _CustomSwitchState createState() => _CustomSwitchState();
}

class _CustomSwitchState extends State<CustomSwitch> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "",
            textOff: "",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.insert_link,
            iconOff: Icons.link_off,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],

    );
  }
}

class Status extends StatefulWidget {
  const Status({Key key}) : super(key: key);

  @override
  _StatusState createState() => _StatusState();
}

class _StatusState extends State<Status> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "",
            textOff: "",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.mic,
            iconOff: Icons.mic_off_outlined,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],

    );
  }
}

class Duration extends StatefulWidget {
  const Duration({Key key}) : super(key: key);

  @override
  _DurationState createState() => _DurationState();
}

class _DurationState extends State<Duration> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Days",
            textOff: "Month",
            colorOn: Colors.red,
            colorOff: Colors.green,
            iconOn: Icons.calendar_view_day_sharp,
            iconOff: Icons.calendar_view_month,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],

    );
  }
}

class Assign extends StatefulWidget {
  const Assign({Key key}) : super(key: key);

  @override
  _AssignState createState() => _AssignState();
}

class _AssignState extends State<Assign> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Yes",
            textOff: "No",
            colorOn: Colors.green,
            colorOff: Colors.red,
            iconOn: Icons.check,
            iconOff: Icons.not_interested,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],
    );
  }
}

class Drip extends StatefulWidget {
  const Drip({Key key}) : super(key: key);

  @override
  _DripState createState() => _DripState();
}

class _DripState extends State<Drip> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Disable",
            textOff: "Enable",
            colorOn: Colors.red,
            colorOff: Colors.green,
            iconOn: Icons.not_interested,
            iconOff: Icons.check,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],
    );
  }
}
