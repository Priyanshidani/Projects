import 'package:eclass/Screens/add_child_category.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import '../Widgets/appbar.dart';
import '../Widgets/course_grid_item.dart';
import '../Widgets/utils.dart';
import '../model/course.dart';
import '../model/home_model.dart';
import '../provider/courses_provider.dart';
import '../provider/categories.dart';
import '../provider/home_data_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../common/theme.dart' as T;

class SubCategoryScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    List<String> img = ["assets/images/cate1.png", "assets/images/cate2.png"];
    SubCategory subCategory = ModalRoute.of(context).settings.arguments;
    Color spcl = Color(0xff655586);
    T.Theme mode = Provider.of<T.Theme>(context);
    List<Course> courses = Provider.of<CoursesProvider>(context)
        .getsubcatecourses(subCategory.id, subCategory.categoryId);
    var homeData = Provider.of<HomeDataProvider>(context).childCategoryList;
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: customAppBar(context, subCategory.title),
      body: Container(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
                child:headingTitle("Child Categories", Color(0xff0083A4), 16)),
            SliverToBoxAdapter(
              child: FutureBuilder(
                  future: CategoryList().childcate(subCategory.id.toString(),
                      subCategory.categoryId, homeData),
                  builder: (context, snap) {
                    if (snap.hasData)
                      return  Container(
                        height: 130,
                        child: ListView.builder(
                            itemCount: snap.data.length,
                            scrollDirection: Axis.horizontal,
                            itemBuilder: (context, idx) {
                              return InkWell(

                                  child: CustomContainer(title: snap.data[idx].title, navigation: snap.data[idx],));
                            }),
                      );
                    else
                      return Container(
                        child: Center(
                          child: CircularProgressIndicator(),
                        ),
                      );
                  }),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        elevation: 5.0,
        onPressed: () {
          //showAlertDialog(context, mode, widget.courseDetail.course.id, appointment);
          Navigator.push(context, MaterialPageRoute(builder: (context)=>AddChildCategory()));
        },
        backgroundColor: mode.easternBlueColor,
        label: Text(
          "+ Add Child Category",
          style: TextStyle(fontWeight: FontWeight.w500, fontSize: 18.0),
        ),
      ),
    );
  }
}

class CustomContainer extends StatefulWidget {
  final String title;
  final navigation;
  const CustomContainer({Key key, @required this.title, this.navigation}) : super(key: key);

  @override
  _CustomContainerState createState() => _CustomContainerState();
}

class _CustomContainerState extends State<CustomContainer> {
  bool isOverFlowVisible = false;
  bool isPopupVisible = false;

  @override
  Widget build(BuildContext context) {
    T.Theme mode = Provider.of<T.Theme>(context);
    return InkWell(
        // onTap: () {
        //   Navigator.of(context).pushNamed('/subCategory', arguments: widget.navigation);
        // },
        onLongPress: (){
          setState(() {
            this.isOverFlowVisible = true;
          });
          Future.delayed(Duration(seconds: 5), (){
            setState(() {
              this.isOverFlowVisible = false;
            });
          });
        },
        child: Container(
          margin: EdgeInsets.only(right: 18.0, bottom: 10.0),
          child: Stack(
            children:[
              Column(
                children: [
                  Container(
                    height: 90.0,
                    width: 70.0,
                    decoration: BoxDecoration(
                        image: DecorationImage(
                            image:
                            AssetImage("assets/images/cat.png"))),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Expanded(
                    child: Container(
                      alignment: Alignment.topCenter,
                      width: 83.0,
                      child: Text(
                        widget.title,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.grey[700],
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              this.isOverFlowVisible? Container(
                decoration: BoxDecoration(color: mode.bgcolor,borderRadius: BorderRadius.all(Radius.circular(10.0))),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    InkWell(
                        child: Padding(
                            child: Icon(Icons.edit_location_outlined,color: Colors.blue
                            ),
                        padding: EdgeInsets.symmetric(vertical: 1.0, horizontal: 8.0,)),
                        onTap: ()=>print('hello')
                    ),
                    InkWell(
                        child: Padding(
                          child: Icon(FontAwesomeIcons.trashAlt,color: Colors.red,),
                          padding: EdgeInsets.symmetric(vertical: 1.0, horizontal: 8.0),),
                        onTap:(){
                          setState(() {
                            this.isPopupVisible = true;
                          });
                      }
                    ),isPopupVisible ? Center(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 24.0),
                        child: Container(
                          padding: EdgeInsets.all(8.0),
                          decoration: BoxDecoration(
                              color: mode.bgcolor,
                              boxShadow: [
                                BoxShadow(
                                    color: Color(0x1c2464).withOpacity(0.30),
                                    blurRadius: 25.0,
                                    offset: Offset(0.0, 20.0),
                                    spreadRadius: -15.0)
                              ],
                              borderRadius: BorderRadius.all(Radius.circular(5.0))
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text('Do you want to delete?'),
                              SizedBox(height: 24.0),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  ElevatedButton(onPressed: () {
                                    setState(() {
                                      isPopupVisible = false;
                                    });
                                  }, child: Text('No')),
                                  ElevatedButton(onPressed: ()=>print('Hi'), child: Text('Yes')),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ):SizedBox(height: 0,width: 0,)],

                ),
              ) : SizedBox(width: 0, height: 0),
            ],
          ),
        ),
    );
  }
}
