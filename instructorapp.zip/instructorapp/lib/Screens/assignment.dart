import 'package:eclass/Screens/Assignment_page.dart';
import 'package:eclass/Screens/search_result_screen.dart';
import 'package:eclass/model/assignment_model.dart';
import 'package:eclass/provider/assignment_provider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../common/theme.dart' as T;

class Assignment extends StatefulWidget {
  const Assignment({Key key}) : super(key: key);

  @override
  _AssignmentState createState() => _AssignmentState();
}

class _AssignmentState extends State<Assignment> {
  Future<AssignmentModel> loadData(BuildContext context) async {
    AssignmentProvider assignmentProvider =
    Provider.of<AssignmentProvider>(context, listen: false);
    await assignmentProvider.getAssignmentData();
    return assignmentProvider.assignmentModel;
  }

  reloadScreen() {
    setState(() {
    });
  }
  @override
  Widget build(BuildContext context) {
    List<String> list = List.generate(10, (index) => "Text $index");
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor:  mode.bgcolor,
        title: Text("All Assignment",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed:(){
            Navigator.pop(context);
          },
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.search,color: Colors.black,),
            onPressed: () {
              showSearch(context: context, delegate: Search(list));
            },
          ),
        ],
      ),
      body:FutureBuilder<AssignmentModel>(
        future: loadData(context),
        builder: (BuildContext context, AsyncSnapshot<AssignmentModel> snapshot) {
          if(!snapshot.hasData) {
            return Center(child: CircularProgressIndicator());
          } else if(snapshot.hasError) {
            return Text("Something went wrong!", style: TextStyle(color: Colors.red,),);
          }
          return Stack(
            children:[ SingleChildScrollView(
              child: Container(
                height: MediaQuery.of(context).size.height,
                child: ListView.builder(
                  padding: EdgeInsets.only(bottom: 100.0),
                  itemCount: 10,
                  itemBuilder: (BuildContext context , int idx)=>
                      SingleChildScrollView(
                        child: Column(
                          children: <Widget>[
                            SizedBox(
                              height: 20,
                            ),
                            Container(
                              alignment: Alignment.bottomLeft,
                              margin: EdgeInsets.fromLTRB(20, 10, 20, 0),

                              padding: EdgeInsets.all(6.0),
                              // height: 100,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                      color: Color(0x1c2464).withOpacity(0.30),
                                      blurRadius: 25.0,
                                      offset: Offset(0.0, 20.0),
                                      spreadRadius: -15.0)
                                ],
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [

                                  ListTile(
                                    leading: Icon(Icons.menu_book_sharp,color: mode.easternBlueColor,),
                                    // leading: CircleAvatar(
                                    //   backgroundImage: NetworkImage(imageUrl),
                                    // ),
                                    title: Text('Courses',style: TextStyle(
                                      fontFamily: 'SF Pro',
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold,
                                    ),),
                                    subtitle: Text('Word Press Theme Development',style: TextStyle(
                                      fontFamily: 'SF Pro',
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.normal,
                                    ),),
                                    trailing: Icon(Icons.arrow_forward_ios_rounded,color: mode.easternBlueColor),
                                    // contentPadding: EdgeInsets.symmetric(horizontal: 0.0),
                                    onTap: (){
                                      Navigator.pushReplacement(context,
                                          MaterialPageRoute(builder: (context) => Assignment_Page()));
                                    },
                                  ),

                                ],
                              ),

                            ),

                          ],
                        ),
                      ),
                ),
              ),
            ),
          ],
          );
        },
      ),




    );
  }
}