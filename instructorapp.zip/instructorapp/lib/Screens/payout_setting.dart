import 'package:eclass/Screens/announcement.dart';
import 'package:flutter/material.dart';
import 'package:eclass/common/theme.dart' as T;
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:provider/provider.dart';

class PayoutSetting extends StatefulWidget {
  const PayoutSetting({Key key}) : super(key: key);

  @override
  _PayoutSettingState createState() => _PayoutSettingState();
}

class _PayoutSettingState extends State<PayoutSetting> {
  String valueChoose;
  List listItem=[
    "Select an option","Paytm","Paypal","Bank Transfer"
  ];
  String valueChoose1;
  List listItem1=[
    "","Instructor"
  ];
  @override
  Widget build(BuildContext context) {
    T.Theme mode = Provider.of<T.Theme>(context);
    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Type:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
            DropdownButton(
              hint: Text('Select an Option'),
              dropdownColor: Colors.white,
              icon: Icon(Icons.arrow_drop_down,color: Colors.red,),
              iconSize: 30,
              isExpanded: true,
              //underline: SizedBox(),
              // style: TextStyle(color: Colors.black,fontSize: 22),
              value: valueChoose,
              onChanged: (newValue){
                setState(() {
                  valueChoose=newValue;
                });
              },
              items: listItem.map((valueItem){
                return DropdownMenuItem(
                  value: valueItem,
                  child: Text(valueItem),
                );
              }).toList(),
            ),
            SizedBox(height: 5,),
            Text('Paytm Payment:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
            Text('Paytm Mobile Number:',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
            TextField(
              decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: '',
                  hintText: ''
              ),
            ),
            SizedBox(height: 10,),

            Row(
              children: [
                RaisedButton(
                  color: Colors.red,
                  // color: mode.easternBlueColor,
                  child: Text("Reset", style: TextStyle(color: Colors.white),),
                  onPressed: () {
                    // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
                  },
                ),
                SizedBox(width: 50,),
                RaisedButton(
                  color: Colors.red,
                  // color: mode.easternBlueColor,
                  child: Text("Create", style: TextStyle(color: Colors.white),),
                  onPressed: () {
                    // Navigator.of(context).popUntil(ModalRoute.withName(Navigator.defaultRouteName));
                  },
                ),
              ],
            )
          ],
        ),
      ),
      backgroundColor: mode.bgcolor,
      appBar: AppBar(
        backgroundColor: mode.bgcolor,
        title: Text("Payment Setting",style:TextStyle(color:Colors.black),),
        centerTitle: true,
        leading: IconButton(
          icon:Icon(Icons.arrow_back,color: Colors.black,),
          onPressed:(){
            Navigator.pop(context);
          },
        ),
      ),
    );
  }
}

class Status extends StatefulWidget {
  const Status({Key key}) : super(key: key);

  @override
  _StatusState createState() => _StatusState();
}

class _StatusState extends State<Status> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          width: 120,
          child: LiteRollingSwitch(
            value: true,
            textOn: "Deactive",
            textOff: "Active",
            colorOn: Colors.red,
            colorOff: Colors.green,
            iconOn: Icons.blur_off_rounded,
            iconOff: Icons.blur_on_rounded,
            textSize: 15.0,
            onChanged: (bool position){},
          ),
        ),
      ],

    );
  }
}