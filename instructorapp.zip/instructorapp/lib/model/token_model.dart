class Tokens {
  String access;
  String refresh;
  Tokens(this.access, this.refresh);
}