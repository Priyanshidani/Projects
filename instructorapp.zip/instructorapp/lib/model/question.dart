/// status : "active"
/// Q: : "Yoga training related question"
/// course : [{"number":1,"name":"Word Press theme"},{"number":2,"name":"Development"}]

class Question {
  Question({
      String status, 
      String q,
      List<Course> course,}){
    _status = status;
    _q = q;
    _course = course;
}

  Question.fromJson(dynamic json) {
    _status = json['status'];
    _q = json['Q:'];
    if (json['course'] != null) {
      _course = [];
      json['course'].forEach((v) {
        _course.add(Course.fromJson(v));
      });
    }
  }
  String _status;
  String _q;
  List<Course> _course;

  String get status => _status;
  String get q => _q;
  List<Course> get course => _course;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = _status;
    map['Q:'] = _q;
    if (_course != null) {
      map['course'] = _course.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// number : 1
/// name : "Word Press theme"

class Course {
  Course({
      int number, 
      String name,}){
    _number = number;
    _name = name;
}

  Course.fromJson(dynamic json) {
    _number = json['number'];
    _name = json['name'];
  }
  int _number;
  String _name;

  int get number => _number;
  String get name => _name;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['number'] = _number;
    map['name'] = _name;
    return map;
  }

}