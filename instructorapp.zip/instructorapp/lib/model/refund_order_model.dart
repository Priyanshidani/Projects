/// refund : []

class RefundOrderModel {
  RefundOrderModel({
      List<dynamic> refund,}){
    _refund = refund;
}

  RefundOrderModel.fromJson(dynamic json) {
    if (json['refund'] != null) {
      _refund = [];
      json['refund'].forEach((v) {
        _refund.add(dynamic.fromJson(v));
      });
    }
  }
  List<dynamic> _refund;

  List<dynamic> get refund => _refund;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_refund != null) {
      map['refund'] = _refund.map((v) => v.toJson()).toList();
    }
    return map;
  }

}