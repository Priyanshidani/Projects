/// enroll_details : [{"id":14,"instructor_id":"2","user_id":"48","user":"Foysal Ahmed ","course_id":"The Mordern JavaScript - The Complete Guide","order_id":"#00000001","transaction_id":"ch_1JIrWHGBj6eLM2HWqMoGzzuq","payment_method":"Stripe","total_amount":"800","coupon_discount":"0","currency":"USD","currency_icon":"fa fa-dollar","duration":null,"enroll_start":null,"enroll_expire":null,"bundle_course_id":null,"bundle_id":null,"proof":null,"sale_id":null,"refunded":"0","price_id":null,"subscription_id":null,"customer_id":null,"subscription_status":null,"status":"1","created_at":"2021-07-30T08:56:44.000000Z","updated_at":"2021-07-30T08:56:44.000000Z"},{"id":21,"instructor_id":"2","user_id":"3","user":"John Dann","course_id":"Music Production with Mixing & Mastering","order_id":"#00000008","transaction_id":"ch_3JPMoqGBj6eLM2HW1xgGPybT","payment_method":"Stripe","total_amount":"900","coupon_discount":"0","currency":"USD","currency_icon":"fa fa-dollar","duration":null,"enroll_start":null,"enroll_expire":null,"bundle_course_id":null,"bundle_id":null,"proof":null,"sale_id":null,"refunded":"0","price_id":null,"subscription_id":null,"customer_id":null,"subscription_status":null,"status":"1","created_at":"2021-08-17T07:34:46.000000Z","updated_at":"2021-08-17T07:34:46.000000Z"}]

class OrderModel {
  OrderModel({
      List<Enroll_details> enrollDetails,}){
    _enrollDetails = enrollDetails;
}

  OrderModel.fromJson(dynamic json) {
    if (json['enroll_details'] != null) {
      _enrollDetails = [];
      json['enroll_details'].forEach((v) {
        _enrollDetails.add(Enroll_details.fromJson(v));
      });
    }
  }
  List<Enroll_details> _enrollDetails;

  List<Enroll_details> get enrollDetails => _enrollDetails;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_enrollDetails != null) {
      map['enroll_details'] = _enrollDetails.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 14
/// instructor_id : "2"
/// user_id : "48"
/// user : "Foysal Ahmed "
/// course_id : "The Mordern JavaScript - The Complete Guide"
/// order_id : "#00000001"
/// transaction_id : "ch_1JIrWHGBj6eLM2HWqMoGzzuq"
/// payment_method : "Stripe"
/// total_amount : "800"
/// coupon_discount : "0"
/// currency : "USD"
/// currency_icon : "fa fa-dollar"
/// duration : null
/// enroll_start : null
/// enroll_expire : null
/// bundle_course_id : null
/// bundle_id : null
/// proof : null
/// sale_id : null
/// refunded : "0"
/// price_id : null
/// subscription_id : null
/// customer_id : null
/// subscription_status : null
/// status : "1"
/// created_at : "2021-07-30T08:56:44.000000Z"
/// updated_at : "2021-07-30T08:56:44.000000Z"

class Enroll_details {
  Enroll_details({
      int id, 
      String instructorId, 
      String userId, 
      String user, 
      String courseId, 
      String orderId, 
      String transactionId, 
      String paymentMethod, 
      String totalAmount, 
      String couponDiscount, 
      String currency, 
      String currencyIcon, 
      dynamic duration, 
      dynamic enrollStart, 
      dynamic enrollExpire, 
      dynamic bundleCourseId, 
      dynamic bundleId, 
      dynamic proof, 
      dynamic saleId, 
      String refunded, 
      dynamic priceId, 
      dynamic subscriptionId, 
      dynamic customerId, 
      dynamic subscriptionStatus, 
      String status, 
      String createdAt, 
      String updatedAt,}){
    _id = id;
    _instructorId = instructorId;
    _userId = userId;
    _user = user;
    _courseId = courseId;
    _orderId = orderId;
    _transactionId = transactionId;
    _paymentMethod = paymentMethod;
    _totalAmount = totalAmount;
    _couponDiscount = couponDiscount;
    _currency = currency;
    _currencyIcon = currencyIcon;
    _duration = duration;
    _enrollStart = enrollStart;
    _enrollExpire = enrollExpire;
    _bundleCourseId = bundleCourseId;
    _bundleId = bundleId;
    _proof = proof;
    _saleId = saleId;
    _refunded = refunded;
    _priceId = priceId;
    _subscriptionId = subscriptionId;
    _customerId = customerId;
    _subscriptionStatus = subscriptionStatus;
    _status = status;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
}

  Enroll_details.fromJson(dynamic json) {
    _id = json['id'];
    _instructorId = json['instructor_id'];
    _userId = json['user_id'];
    _user = json['user'];
    _courseId = json['course_id'];
    _orderId = json['order_id'];
    _transactionId = json['transaction_id'];
    _paymentMethod = json['payment_method'];
    _totalAmount = json['total_amount'];
    _couponDiscount = json['coupon_discount'];
    _currency = json['currency'];
    _currencyIcon = json['currency_icon'];
    _duration = json['duration'];
    _enrollStart = json['enroll_start'];
    _enrollExpire = json['enroll_expire'];
    _bundleCourseId = json['bundle_course_id'];
    _bundleId = json['bundle_id'];
    _proof = json['proof'];
    _saleId = json['sale_id'];
    _refunded = json['refunded'];
    _priceId = json['price_id'];
    _subscriptionId = json['subscription_id'];
    _customerId = json['customer_id'];
    _subscriptionStatus = json['subscription_status'];
    _status = json['status'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
  }
  int _id;
  String _instructorId;
  String _userId;
  String _user;
  String _courseId;
  String _orderId;
  String _transactionId;
  String _paymentMethod;
  String _totalAmount;
  String _couponDiscount;
  String _currency;
  String _currencyIcon;
  dynamic _duration;
  dynamic _enrollStart;
  dynamic _enrollExpire;
  dynamic _bundleCourseId;
  dynamic _bundleId;
  dynamic _proof;
  dynamic _saleId;
  String _refunded;
  dynamic _priceId;
  dynamic _subscriptionId;
  dynamic _customerId;
  dynamic _subscriptionStatus;
  String _status;
  String _createdAt;
  String _updatedAt;

  int get id => _id;
  String get instructorId => _instructorId;
  String get userId => _userId;
  String get user => _user;
  String get courseId => _courseId;
  String get orderId => _orderId;
  String get transactionId => _transactionId;
  String get paymentMethod => _paymentMethod;
  String get totalAmount => _totalAmount;
  String get couponDiscount => _couponDiscount;
  String get currency => _currency;
  String get currencyIcon => _currencyIcon;
  dynamic get duration => _duration;
  dynamic get enrollStart => _enrollStart;
  dynamic get enrollExpire => _enrollExpire;
  dynamic get bundleCourseId => _bundleCourseId;
  dynamic get bundleId => _bundleId;
  dynamic get proof => _proof;
  dynamic get saleId => _saleId;
  String get refunded => _refunded;
  dynamic get priceId => _priceId;
  dynamic get subscriptionId => _subscriptionId;
  dynamic get customerId => _customerId;
  dynamic get subscriptionStatus => _subscriptionStatus;
  String get status => _status;
  String get createdAt => _createdAt;
  String get updatedAt => _updatedAt;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['instructor_id'] = _instructorId;
    map['user_id'] = _userId;
    map['user'] = _user;
    map['course_id'] = _courseId;
    map['order_id'] = _orderId;
    map['transaction_id'] = _transactionId;
    map['payment_method'] = _paymentMethod;
    map['total_amount'] = _totalAmount;
    map['coupon_discount'] = _couponDiscount;
    map['currency'] = _currency;
    map['currency_icon'] = _currencyIcon;
    map['duration'] = _duration;
    map['enroll_start'] = _enrollStart;
    map['enroll_expire'] = _enrollExpire;
    map['bundle_course_id'] = _bundleCourseId;
    map['bundle_id'] = _bundleId;
    map['proof'] = _proof;
    map['sale_id'] = _saleId;
    map['refunded'] = _refunded;
    map['price_id'] = _priceId;
    map['subscription_id'] = _subscriptionId;
    map['customer_id'] = _customerId;
    map['subscription_status'] = _subscriptionStatus;
    map['status'] = _status;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    return map;
  }

}