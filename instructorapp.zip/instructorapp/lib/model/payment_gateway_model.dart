class PaymentGatewayModel{
  int id;
  String name;
  String walletImage;
  String status;
  PaymentGatewayModel(this.id, this.name, this.walletImage, this.status);
}