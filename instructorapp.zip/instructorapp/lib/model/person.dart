/// name : "Anita Rai"
/// age : 23
/// salary : 25000.55
/// mobile_no : [{"sim":1,"number":"9876543210"},{"sim":2,"number":"9876543211"}]

class Person {
  Person({
      String name, 
      int age, 
      double salary, 
      List<Mobile_no> mobileNo,}){
    _name = name;
    _age = age;
    _salary = salary;
    _mobileNo = mobileNo;
}

  Person.fromJson(dynamic json) {
    _name = json['name'];
    _age = json['age'];
    _salary = json['salary'];
    if (json['mobile_no'] != null) {
      _mobileNo = [];
      json['mobile_no'].forEach((v) {
        _mobileNo.add(Mobile_no.fromJson(v));
      });
    }
  }
  String _name;
  int _age;
  double _salary;
  List<Mobile_no> _mobileNo;

  String get name => _name;
  int get age => _age;
  double get salary => _salary;
  List<Mobile_no> get mobileNo => _mobileNo;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['age'] = _age;
    map['salary'] = _salary;
    if (_mobileNo != null) {
      map['mobile_no'] = _mobileNo.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// sim : 1
/// number : "9876543210"

class Mobile_no {
  Mobile_no({
      int sim, 
      String number,}){
    _sim = sim;
    _number = number;
}

  Mobile_no.fromJson(dynamic json) {
    _sim = json['sim'];
    _number = json['number'];
  }
  int _sim;
  String _number;

  int get sim => _sim;
  String get number => _number;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['sim'] = _sim;
    map['number'] = _number;
    return map;
  }

}