/// meeting : [{"id":8,"meeting_id":"73646144786","user_id":"1","owner_id":"noshenhussain@gmail.com","meeting_title":"Photoshop Training","start_time":"2020-05-20 11:05:54","zoom_url":"https://us04web.zoom.us/s/73646144786?zak=eyJ6bV9za20iOiJ6bV9vMm0iLCJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJjbGllbnQiLCJ1aWQiOiJHY1hwUzVNVlFqS2JENS1lQmg2OWRBIiwiaXNzIjoid2ViIiwic3R5Ijox","link_by":"course","course_id":"3","created_at":"2020-05-30T07:50:01.000000Z","updated_at":"2020-08-15T18:16:18.000000Z","type":null,"agenda":null,"image":null},{"id":18,"meeting_id":"74973649357","user_id":"1","owner_id":"noshenhussain@gmail.com","meeting_title":"Time","start_time":"2020-09-20 13:00:00","zoom_url":"https://us04web.zoom.us/s/74973649357?zak=eyJ6bV9za20iOiJ6bV9vMm0iLCJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJjbGllbnQiLCJ1aWQiOiJHY1hwUzVNVlFqS2JENS1lQmg2OWRBIiwiaXNzIjoid2ViIiwic3R5Ijox","link_by":null,"course_id":null,"created_at":"2020-08-06T12:23:49.000000Z","updated_at":"2020-08-06T20:32:03.000000Z","type":null,"agenda":null,"image":null},{"id":19,"meeting_id":"74979623957","user_id":"1","owner_id":"noshenhussain@gmail.com","meeting_title":"Music Class","start_time":"2007-08-20 12:06:50","zoom_url":"https://us04web.zoom.us/s/74979623957?zak=eyJ6bV9za20iOiJ6bV9vMm0iLCJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJjbGllbnQiLCJ1aWQiOiJHY1hwUzVNVlFqS2JENS1lQmg2OWRBIiwiaXNzIjoid2ViIiwic3R5Ijox","link_by":null,"course_id":null,"created_at":"2020-08-06T20:36:48.000000Z","updated_at":"2020-08-15T18:15:24.000000Z","type":null,"agenda":null,"image":null},{"id":20,"meeting_id":"79381914848","user_id":"1","owner_id":"noshenhussain@gmail.com","meeting_title":"Yoga Training Classes","start_time":"2020-08-20 06:12:51","zoom_url":"https://us04web.zoom.us/s/79381914848?zak=eyJ6bV9za20iOiJ6bV9vMm0iLCJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJjbGllbnQiLCJ1aWQiOiJHY1hwUzVNVlFqS2JENS1lQmg2OWRBIiwiaXNzIjoid2ViIiwic3R5Ijox","link_by":null,"course_id":null,"created_at":"2020-08-06T20:43:21.000000Z","updated_at":"2020-08-15T18:18:58.000000Z","type":null,"agenda":null,"image":null},{"id":21,"meeting_id":"83973073069","user_id":"1","owner_id":"ch10kismat@gmail.com","meeting_title":"WordPress Theme","start_time":"2021-07-20 10:37:20","zoom_url":"https://us05web.zoom.us/s/83973073069?zak=eyJ0eXAiOiJKV1QiLCJzdiI6IjAwMDAwMSIsInptX3NrbSI6InptX28ybSIsImFsZyI6IkhTMjU2In0.eyJhdWQiOiJjbGllbnRzbSIsInVpZCI6IkVtMk5pSmxpUzIyOEtqem1GWnJfeUEiLCJpc","link_by":"course","course_id":"1","created_at":"2021-07-20T05:08:40.000000Z","updated_at":"2021-07-20T05:08:40.000000Z","type":"2","agenda":"WordPress Theme","image":null},{"id":22,"meeting_id":"85631889870","user_id":"1","owner_id":"rkdhaker000@gmail.com","meeting_title":"test","start_time":"2021-08-20 05:09:57","zoom_url":"https://us05web.zoom.us/s/85631889870?zak=eyJ0eXAiOiJKV1QiLCJzdiI6IjAwMDAwMSIsInptX3NrbSI6InptX28ybSIsImFsZyI6IkhTMjU2In0.eyJhdWQiOiJjbGllbnRzbSIsInVpZCI6IncwWnpYV19xUTNpbVBvdGpIN05XRUEiLCJpc","link_by":"course","course_id":"1","created_at":"2021-08-20T12:09:57.000000Z","updated_at":"2021-08-20T12:09:57.000000Z","type":"3","agenda":"test","image":null},{"id":24,"meeting_id":"76618511646","user_id":"1","owner_id":"akanshagautambhl@gmail.com","meeting_title":"qwefghm","start_time":"2021-08-24 14:42:20","zoom_url":"https://us04web.zoom.us/s/76618511646?zak=eyJ0eXAiOiJKV1QiLCJzdiI6IjAwMDAwMSIsInptX3NrbSI6InptX28ybSIsImFsZyI6IkhTMjU2In0.eyJhdWQiOiJjbGllbnRzbSIsInVpZCI6ImdqYlN0TnBjUWc2REFzX05lOGZmN1EiLCJpc","link_by":null,"course_id":null,"created_at":"2021-08-24T09:11:47.000000Z","updated_at":"2021-08-24T09:12:20.000000Z","type":"2","agenda":"vbsdfghj","image":null},{"id":25,"meeting_id":"86493174310","user_id":"1","owner_id":"rkdhaker000@gmail.com","meeting_title":"testing zoom","start_time":"2021-09-07 13:27:57","zoom_url":"https://us05web.zoom.us/s/86493174310?zak=eyJ0eXAiOiJKV1QiLCJzdiI6IjAwMDAwMSIsInptX3NrbSI6InptX28ybSIsImFsZyI6IkhTMjU2In0.eyJhdWQiOiJjbGllbnRzbSIsInVpZCI6IncwWnpYV19xUTNpbVBvdGpIN05XRUEiLCJpc","link_by":null,"course_id":null,"created_at":"2021-09-07T07:57:57.000000Z","updated_at":"2021-09-07T07:57:57.000000Z","type":"3","agenda":"zoom test","image":null},{"id":26,"meeting_id":"85872487004","user_id":"1","owner_id":"rkdhaker000@gmail.com","meeting_title":"testing zoom","start_time":"2021-09-07 13:28:54","zoom_url":"https://us05web.zoom.us/s/85872487004?zak=eyJ0eXAiOiJKV1QiLCJzdiI6IjAwMDAwMSIsInptX3NrbSI6InptX28ybSIsImFsZyI6IkhTMjU2In0.eyJhdWQiOiJjbGllbnRzbSIsInVpZCI6IncwWnpYV19xUTNpbVBvdGpIN05XRUEiLCJpc","link_by":"course","course_id":"1","created_at":"2021-09-07T07:58:54.000000Z","updated_at":"2021-09-07T07:58:54.000000Z","type":"3","agenda":"zoom test","image":null},{"id":27,"meeting_id":"88686326730","user_id":"1","owner_id":"rkdhaker000@gmail.com","meeting_title":"zoom test","start_time":"2021-09-07 15:21:51","zoom_url":"https://us05web.zoom.us/s/88686326730?zak=eyJ0eXAiOiJKV1QiLCJzdiI6IjAwMDAwMSIsInptX3NrbSI6InptX28ybSIsImFsZyI6IkhTMjU2In0.eyJhdWQiOiJjbGllbnRzbSIsInVpZCI6IncwWnpYV19xUTNpbVBvdGpIN05XRUEiLCJpc","link_by":"course","course_id":"1","created_at":"2021-09-07T09:51:51.000000Z","updated_at":"2021-09-07T09:51:51.000000Z","type":"3","agenda":"zoom test","image":null}]

class ZoomMeetingModel {
  ZoomMeetingModel({
      List<Meeting> meeting,}){
    _meeting = meeting;
}

  ZoomMeetingModel.fromJson(dynamic json) {
    if (json['meeting'] != null) {
      _meeting = [];
      json['meeting'].forEach((v) {
        _meeting.add(Meeting.fromJson(v));
      });
    }
  }
  List<Meeting> _meeting;

  List<Meeting> get meeting => _meeting;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_meeting != null) {
      map['meeting'] = _meeting.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 8
/// meeting_id : "73646144786"
/// user_id : "1"
/// owner_id : "noshenhussain@gmail.com"
/// meeting_title : "Photoshop Training"
/// start_time : "2020-05-20 11:05:54"
/// zoom_url : "https://us04web.zoom.us/s/73646144786?zak=eyJ6bV9za20iOiJ6bV9vMm0iLCJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJjbGllbnQiLCJ1aWQiOiJHY1hwUzVNVlFqS2JENS1lQmg2OWRBIiwiaXNzIjoid2ViIiwic3R5Ijox"
/// link_by : "course"
/// course_id : "3"
/// created_at : "2020-05-30T07:50:01.000000Z"
/// updated_at : "2020-08-15T18:16:18.000000Z"
/// type : null
/// agenda : null
/// image : null

class Meeting {
  Meeting({
      int id, 
      String meetingId, 
      String userId, 
      String ownerId, 
      String meetingTitle, 
      String startTime, 
      String zoomUrl, 
      String linkBy, 
      String courseId, 
      String createdAt, 
      String updatedAt, 
      dynamic type, 
      dynamic agenda, 
      dynamic image,}){
    _id = id;
    _meetingId = meetingId;
    _userId = userId;
    _ownerId = ownerId;
    _meetingTitle = meetingTitle;
    _startTime = startTime;
    _zoomUrl = zoomUrl;
    _linkBy = linkBy;
    _courseId = courseId;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
    _type = type;
    _agenda = agenda;
    _image = image;
}

  Meeting.fromJson(dynamic json) {
    _id = json['id'];
    _meetingId = json['meeting_id'];
    _userId = json['user_id'];
    _ownerId = json['owner_id'];
    _meetingTitle = json['meeting_title'];
    _startTime = json['start_time'];
    _zoomUrl = json['zoom_url'];
    _linkBy = json['link_by'];
    _courseId = json['course_id'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
    _type = json['type'];
    _agenda = json['agenda'];
    _image = json['image'];
  }
  int _id;
  String _meetingId;
  String _userId;
  String _ownerId;
  String _meetingTitle;
  String _startTime;
  String _zoomUrl;
  String _linkBy;
  String _courseId;
  String _createdAt;
  String _updatedAt;
  dynamic _type;
  dynamic _agenda;
  dynamic _image;

  int get id => _id;
  String get meetingId => _meetingId;
  String get userId => _userId;
  String get ownerId => _ownerId;
  String get meetingTitle => _meetingTitle;
  String get startTime => _startTime;
  String get zoomUrl => _zoomUrl;
  String get linkBy => _linkBy;
  String get courseId => _courseId;
  String get createdAt => _createdAt;
  String get updatedAt => _updatedAt;
  dynamic get type => _type;
  dynamic get agenda => _agenda;
  dynamic get image => _image;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['meeting_id'] = _meetingId;
    map['user_id'] = _userId;
    map['owner_id'] = _ownerId;
    map['meeting_title'] = _meetingTitle;
    map['start_time'] = _startTime;
    map['zoom_url'] = _zoomUrl;
    map['link_by'] = _linkBy;
    map['course_id'] = _courseId;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    map['type'] = _type;
    map['agenda'] = _agenda;
    map['image'] = _image;
    return map;
  }

}