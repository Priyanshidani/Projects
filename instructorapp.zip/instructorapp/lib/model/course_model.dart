/// course : [{"id":4,"subcategory_id":"16","category_id":"0","childcategory_id":"16","language_id":"1","user_id":"2","title":{"en":"Internationally Accredited Diploma in Yoga Training"},"short_detail":{"en":"Start a New Career in Yoga with this Yoga Course for Beginners/Intermediates"},"requirement":{"en":"A Yoga MatWillingness to apply Yogic knowledge into regular practice"},"detail":{"en":"Now earn your INTERNATIONALLY ACCREDITED DIPLOMA IN YOGA TRAINING accredited by CPD Certification Service, which is an independent body that ensures qualifications are in line with the most current professional standards. This means this course comply with universally accepted principles of Continual Professional Development (CPD) and have been structured to meet the criteria of personal development plans. CPD certification means that the content and structure of the courses have been independently assessed and approved for multi-disciplinary and industry-wide continuing personal and professional development purposes."},"price":"1500","discount_price":"1200","day":null,"video":"1632726452Dashboard · nex.mp4","video_path":"http://castleindia.in/eclass/public/video/preview/1632726452Dashboard · nex.mp4","video_url":null,"url":"https://www.youtube.com/watch?v=VaoV1PrYft4","featured":"0","status":"1","slug":"internationally-accredited-diploma-in-yoga-training","duration":null,"duration_type":"m","instructor_revenue":null,"involvement_request":"0","refund_policy_id":null,"assignment_enable":"1","appointment_enable":"1","certificate_enable":"1","course_tags":null,"level_tags":null,"preview_image":"1579688543yoga.jpg","imagepath":"http://castleindia.in/eclass/public/images/course/1579688543yoga.jpg","reject_txt":"Rejected","drip_enable":"0","preview_type":"video","updated_at":"2020-01-22T11:22:23.000000Z"},{"id":7,"subcategory_id":"4","category_id":"1","childcategory_id":"4","language_id":"1","user_id":"2","title":{"en":"Pro SketchUp  - A Practical Course &  Infinite Skills"},"short_detail":{"en":"This course will show you how to organize the model, including creating the second floor and additional openings."},"requirement":{"en":"By the fruition of this PC based instructional class, you will be happy with utilizing a large number of the fundamental and complex apparatuses in SketchUp. Working documents are incorporated, permitting you to track with the creator all through the exercises."},"detail":{"en":"You will begin by learning the rudiments of the drawing instruments, and afterward rapidly bounce into figuring out how to make diverse rooftop types. This course will tell you the best way to sort out the model, including making the subsequent floor and extra openings, utilizing the outliner, and review layer conditions of the model. This video instructional exercise will tell you the best way to make the various pieces of a home, including the roof, staircase, entryways and windows, chimney, and kitchen. You will figure out how to include furniture utilizing the 3D distribution center and model the furniture from a photo. You will at that point move to making the outside of the home, from setting the structure set up to including sun oriented boards. At long last, Dan will show you different sending out alternatives and how to make a rendering and activity."},"price":null,"discount_price":null,"day":null,"video":null,"video_path":"http://castleindia.in/eclass/public/video/preview","video_url":null,"url":"https://www.youtube.com/watch?v=v_s7lpikWQU","featured":"0","status":"1","slug":"pro-sketchup-a-practical-course-infinite-skills","duration":null,"duration_type":"m","instructor_revenue":null,"involvement_request":null,"refund_policy_id":null,"assignment_enable":"1","appointment_enable":"1","certificate_enable":"1","course_tags":null,"level_tags":null,"preview_image":"157969332641.jpg","imagepath":"http://castleindia.in/eclass/public/images/course/157969332641.jpg","reject_txt":"","drip_enable":"0","preview_type":"url","updated_at":"2020-01-22T12:42:06.000000Z"},{"id":10,"subcategory_id":"6","category_id":"2","childcategory_id":"6","language_id":"1","user_id":"2","title":{"en":"The Mordern JavaScript - The Complete Guide"},"short_detail":{"en":"Modern JavaScript from the beginning - all the way up to JS expert level! THE must-have JavaScript resource in 2020."},"requirement":{"en":"This is the most far reaching and present day course you can discover on JavaScript - it depends on all my JavaScript information AND educating experience. It's both a total guide, beginning with the center essentials of the language, just as a broad reference of the JavaScript language and condition, guaranteeing that the two newcomers just as experienced JavaScript designers get a great deal out of this course!"},"detail":{"en":"It's an enormous course since it's stuffed with significant information and supportive substance. From the center nuts and bolts, over cutting edge ideas and JavaScript strengths, as far as possible up to master points like execution enhancement and testing - this course has everything. My objective was to make your go-to asset for the JavaScript language, which you can use for learning it as well as an asset you can return to and look into significant themes. The course depends on my experience as a long haul JavaScript engineer just as an instructor with in excess of 1,000,000 understudies on Udemy just as on my YouTube channel Academind. It's stuffed with models, demos, ventures, assignments, tests and obviously recordings - all with the objective of giving you the most ideal method for learning JavaScript."},"price":"1000","discount_price":"800","day":null,"video":null,"video_path":"http://castleindia.in/eclass/public/video/preview","video_url":null,"url":"https://www.youtube.com/watch?v=Lgxgm-T9cgA&list=PL0b6OzIxLPbx-BZTaWu_AF7hsKo_Fvsnf","featured":"0","status":"1","slug":"the-mordern-javascript-the-complete-guide","duration":null,"duration_type":"m","instructor_revenue":null,"involvement_request":null,"refund_policy_id":null,"assignment_enable":"1","appointment_enable":"1","certificate_enable":"1","course_tags":null,"level_tags":null,"preview_image":"157976014948.jpg","imagepath":"http://castleindia.in/eclass/public/images/course/157976014948.jpg","reject_txt":"","drip_enable":"0","preview_type":"url","updated_at":"2020-01-23T07:15:01.000000Z"},{"id":14,"subcategory_id":"8","category_id":"3","childcategory_id":"11","language_id":"1","user_id":"2","title":{"en":"Music Production with Mixing & Mastering"},"short_detail":{"en":"Learning the tricks and techniques to mixing and mastering your songs"},"requirement":{"en":"Focused on clients that need to show signs of improvement at their blending and acing inside Studio One Music Composers, Producers working with Studio who need to realize the instruments better Clients who need to take their Studio one Songs further and clean them up so they contrast and other business discharges."},"detail":{"en":"On the off chance that you need to improve your melody blends in Studio One, this is the ideal course for you! Figure out how to Mix and Master them inside Studio One This is a finished course showing you how to utilize every one of the apparatuses and capabilities in Studio One to give you an incredible blended, aced and settled tune/s With simple to-follow instructional exercises and a true case of a melody from beginning to end, you'll appreciate learning while at the same time making a move."},"price":"1000","discount_price":"900","day":null,"video":null,"video_path":"http://castleindia.in/eclass/public/video/preview","video_url":null,"url":"https://www.youtube.com/watch?v=ab_TBVZewoQ","featured":"1","status":"1","slug":"music-production-with-mixing-mastering","duration":null,"duration_type":"m","instructor_revenue":null,"involvement_request":null,"refund_policy_id":null,"assignment_enable":"1","appointment_enable":"1","certificate_enable":"1","course_tags":null,"level_tags":null,"preview_image":"157976172453.jpg","imagepath":"http://castleindia.in/eclass/public/images/course/157976172453.jpg","reject_txt":"","drip_enable":"0","preview_type":"url","updated_at":"2020-01-23T07:42:04.000000Z"},{"id":16,"subcategory_id":"10","category_id":"4","childcategory_id":"1","language_id":"1","user_id":"2","title":{"en":"Art & Science of Drawing-  Ultimate Drawing Course"},"short_detail":{"en":"A comprehensive video and ebook course designed for people wanting to learn the core concepts of drawing."},"requirement":{"en":"This top of the line course is currently far and away superior with new substance as of late included just as improved picture and sound. This refreshed adaptation of the course currently incorporates long stretches of reward drawing exhibits that will tell you the best way to apply your new attracting abilities to a wide scope of topic including botanicals and feathered creatures. There's even a prologue to essential figure drawing."},"detail":{"en":"The Art and Science of Drawing is an exceptional program that will show you how to draw each day in turn. The program is straightforward, every day you'll watch one video exercise that will present a fundamental drawing ability, and afterward do the prescribed practice. The Art and Science of Drawing is flooding with ground-breaking bits of knowledge into the drawing procedure and offers the absolute most clear, most open drawing guidance accessible. A large number of the apparatuses and strategies you'll learn here are once in a while observed outside of private workmanship institutes. This course is enthusiastically suggested for anybody keen on painting too. Most ace painters concur that drawing is a key and fundamental expertise for all painters. Essential SKILLS is the ideal introduction for anybody needing to figure out how to draw. The abilities you'll learn here will significantly improve your specialty and configuration regardless of what medium you work in."},"price":"1000","discount_price":"600","day":null,"video":null,"video_path":"http://castleindia.in/eclass/public/video/preview","video_url":null,"url":"https://www.youtube.com/watch?v=ewMksAbgdBI","featured":"0","status":"1","slug":"art-science-of-drawing-ultimate-drawing-course","duration":"3","duration_type":"m","instructor_revenue":null,"involvement_request":"1","refund_policy_id":null,"assignment_enable":"1","appointment_enable":"1","certificate_enable":"1","course_tags":null,"level_tags":null,"preview_image":"157976281055.jpg","imagepath":"http://castleindia.in/eclass/public/images/course/157976281055.jpg","reject_txt":"","drip_enable":"0","preview_type":"url","updated_at":"2020-01-23T08:00:10.000000Z"},{"id":18,"subcategory_id":"11","category_id":"4","childcategory_id":"16","language_id":"1","user_id":"2","title":{"en":"Hair styling- The Ultimate Hair Course"},"short_detail":{"en":"You won't visit a hairdresser again! Cut, dye  and style your hair yourself at home."},"requirement":{"en":"Next, how about we talk about the apparatuses and the correct temperature to make solid twists. We are completing with a hair obsession. A large number of brands and varnishes. Be that as it may, many don't hold hair and make dust. Subsequently, the styling is messy."},"detail":{"en":"Voluminous, solid twists without backcombing/prodding or pleating, even the biggest length. Is it accurate to say that you are longing for radiant twists and a huge volume? However, your customers fear prodding or pleating... I know it all about twists. What's more, in this exercise I sincerely share every one of the privileged insights. You even didn't feel that everything is so straightforward. Anybody with any degree of preparing can ace the abilities. I will tell about hair arrangement. This is the most significant advance. Skirting this specific advance, you are committing a gross error."},"price":"1200","discount_price":"500","day":null,"video":null,"video_path":"http://castleindia.in/eclass/public/video/preview","video_url":null,"url":"https://www.youtube.com/watch?v=-poUN5MNb_U","featured":"0","status":"1","slug":"hair-styling-the-ultimate-hair-course","duration":null,"duration_type":"m","instructor_revenue":null,"involvement_request":null,"refund_policy_id":null,"assignment_enable":"1","appointment_enable":"1","certificate_enable":"1","course_tags":null,"level_tags":null,"preview_image":"157976385857.jpg","imagepath":"http://castleindia.in/eclass/public/images/course/157976385857.jpg","reject_txt":"","drip_enable":"0","preview_type":"url","updated_at":"2020-01-23T08:17:38.000000Z"},{"id":22,"subcategory_id":"5","category_id":"2","childcategory_id":"5","language_id":"1","user_id":"2","title":{"en":"Flutter Dart"},"short_detail":{"en":"This is a Short Detail."},"requirement":{"en":"This is requirements."},"detail":{"en":"This is a Detail."},"price":null,"discount_price":null,"day":null,"video":null,"video_path":"http://castleindia.in/eclass/public/video/preview","video_url":null,"url":null,"featured":"1","status":"1","slug":"flutter","duration":"9","duration_type":"m","instructor_revenue":null,"involvement_request":"1","refund_policy_id":"20","assignment_enable":"1","appointment_enable":"1","certificate_enable":"1","course_tags":"three","level_tags":null,"preview_image":"1629865050Computer Magister.png","imagepath":"http://castleindia.in/eclass/public/images/course/1629865050Computer Magister.png","reject_txt":"","drip_enable":"1","preview_type":"video","updated_at":"2021-08-25T04:17:29.000000Z"},{"id":23,"subcategory_id":"1","category_id":"1","childcategory_id":"1","language_id":"2","user_id":"2","title":{"en":"Test"},"short_detail":{"en":"test"},"requirement":{"en":"test"},"detail":{"en":"test"},"price":null,"discount_price":null,"day":null,"video":"1630062413VID-20210824-WA0004.mp4","video_path":"http://castleindia.in/eclass/public/video/preview/1630062413VID-20210824-WA0004.mp4","video_url":null,"url":null,"featured":"0","status":"1","slug":"test","duration":"30","duration_type":"m","instructor_revenue":null,"involvement_request":"1","refund_policy_id":"20","assignment_enable":"1","appointment_enable":"1","certificate_enable":"1","course_tags":"test","level_tags":null,"preview_image":"1630062413Screenshot_2021-08-25-07-38-39-617_lockscreen.jpg","imagepath":"http://castleindia.in/eclass/public/images/course/1630062413Screenshot_2021-08-25-07-38-39-617_lockscreen.jpg","reject_txt":"","drip_enable":"1","preview_type":"video","updated_at":"2021-08-27T11:06:53.000000Z"}]

class CourseModel {
  CourseModel({
      List<Course> course,}){
    _course = course;
}

  CourseModel.fromJson(dynamic json) {
    if (json['course'] != null) {
      _course = [];
      json['course'].forEach((v) {
        _course.add(Course.fromJson(v));
      });
    }
  }
  List<Course> _course;

  List<Course> get course => _course;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_course != null) {
      map['course'] = _course.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 4
/// subcategory_id : "16"
/// category_id : "0"
/// childcategory_id : "16"
/// language_id : "1"
/// user_id : "2"
/// title : {"en":"Internationally Accredited Diploma in Yoga Training"}
/// short_detail : {"en":"Start a New Career in Yoga with this Yoga Course for Beginners/Intermediates"}
/// requirement : {"en":"A Yoga MatWillingness to apply Yogic knowledge into regular practice"}
/// detail : {"en":"Now earn your INTERNATIONALLY ACCREDITED DIPLOMA IN YOGA TRAINING accredited by CPD Certification Service, which is an independent body that ensures qualifications are in line with the most current professional standards. This means this course comply with universally accepted principles of Continual Professional Development (CPD) and have been structured to meet the criteria of personal development plans. CPD certification means that the content and structure of the courses have been independently assessed and approved for multi-disciplinary and industry-wide continuing personal and professional development purposes."}
/// price : "1500"
/// discount_price : "1200"
/// day : null
/// video : "1632726452Dashboard · nex.mp4"
/// video_path : "http://castleindia.in/eclass/public/video/preview/1632726452Dashboard · nex.mp4"
/// video_url : null
/// url : "https://www.youtube.com/watch?v=VaoV1PrYft4"
/// featured : "0"
/// status : "1"
/// slug : "internationally-accredited-diploma-in-yoga-training"
/// duration : null
/// duration_type : "m"
/// instructor_revenue : null
/// involvement_request : "0"
/// refund_policy_id : null
/// assignment_enable : "1"
/// appointment_enable : "1"
/// certificate_enable : "1"
/// course_tags : null
/// level_tags : null
/// preview_image : "1579688543yoga.jpg"
/// imagepath : "http://castleindia.in/eclass/public/images/course/1579688543yoga.jpg"
/// reject_txt : "Rejected"
/// drip_enable : "0"
/// preview_type : "video"
/// updated_at : "2020-01-22T11:22:23.000000Z"

class Course {
  Course({
      int id, 
      String subcategoryId, 
      String categoryId, 
      String childcategoryId, 
      String languageId, 
      String userId, 
      Title title, 
      Short_detail shortDetail, 
      Requirement requirement, 
      Detail detail, 
      String price, 
      String discountPrice, 
      dynamic day, 
      String video, 
      String videoPath, 
      dynamic videoUrl, 
      String url, 
      String featured, 
      String status, 
      String slug, 
      dynamic duration, 
      String durationType, 
      dynamic instructorRevenue, 
      String involvementRequest, 
      dynamic refundPolicyId, 
      String assignmentEnable, 
      String appointmentEnable, 
      String certificateEnable, 
      dynamic courseTags, 
      dynamic levelTags, 
      String previewImage, 
      String imagepath, 
      String rejectTxt, 
      String dripEnable, 
      String previewType, 
      String updatedAt,}){
    _id = id;
    _subcategoryId = subcategoryId;
    _categoryId = categoryId;
    _childcategoryId = childcategoryId;
    _languageId = languageId;
    _userId = userId;
    _title = title;
    _shortDetail = shortDetail;
    _requirement = requirement;
    _detail = detail;
    _price = price;
    _discountPrice = discountPrice;
    _day = day;
    _video = video;
    _videoPath = videoPath;
    _videoUrl = videoUrl;
    _url = url;
    _featured = featured;
    _status = status;
    _slug = slug;
    _duration = duration;
    _durationType = durationType;
    _instructorRevenue = instructorRevenue;
    _involvementRequest = involvementRequest;
    _refundPolicyId = refundPolicyId;
    _assignmentEnable = assignmentEnable;
    _appointmentEnable = appointmentEnable;
    _certificateEnable = certificateEnable;
    _courseTags = courseTags;
    _levelTags = levelTags;
    _previewImage = previewImage;
    _imagepath = imagepath;
    _rejectTxt = rejectTxt;
    _dripEnable = dripEnable;
    _previewType = previewType;
    _updatedAt = updatedAt;
}

  Course.fromJson(dynamic json) {
    _id = json['id'];
    _subcategoryId = json['subcategory_id'];
    _categoryId = json['category_id'];
    _childcategoryId = json['childcategory_id'];
    _languageId = json['language_id'];
    _userId = json['user_id'];
    _title = json['title'] != null ? Title.fromJson(json['title']) : null;
    _shortDetail = json['short_detail'] != null ? Short_detail.fromJson(json['shortDetail']) : null;
    _requirement = json['requirement'] != null ? Requirement.fromJson(json['requirement']) : null;
    _detail = json['detail'] != null ? Detail.fromJson(json['detail']) : null;
    _price = json['price'];
    _discountPrice = json['discount_price'];
    _day = json['day'];
    _video = json['video'];
    _videoPath = json['video_path'];
    _videoUrl = json['video_url'];
    _url = json['url'];
    _featured = json['featured'];
    _status = json['status'];
    _slug = json['slug'];
    _duration = json['duration'];
    _durationType = json['duration_type'];
    _instructorRevenue = json['instructor_revenue'];
    _involvementRequest = json['involvement_request'];
    _refundPolicyId = json['refund_policy_id'];
    _assignmentEnable = json['assignment_enable'];
    _appointmentEnable = json['appointment_enable'];
    _certificateEnable = json['certificate_enable'];
    _courseTags = json['course_tags'];
    _levelTags = json['level_tags'];
    _previewImage = json['preview_image'];
    _imagepath = json['imagepath'];
    _rejectTxt = json['reject_txt'];
    _dripEnable = json['drip_enable'];
    _previewType = json['preview_type'];
    _updatedAt = json['updated_at'];
  }
  int _id;
  String _subcategoryId;
  String _categoryId;
  String _childcategoryId;
  String _languageId;
  String _userId;
  Title _title;
  Short_detail _shortDetail;
  Requirement _requirement;
  Detail _detail;
  String _price;
  String _discountPrice;
  dynamic _day;
  String _video;
  String _videoPath;
  dynamic _videoUrl;
  String _url;
  String _featured;
  String _status;
  String _slug;
  dynamic _duration;
  String _durationType;
  dynamic _instructorRevenue;
  String _involvementRequest;
  dynamic _refundPolicyId;
  String _assignmentEnable;
  String _appointmentEnable;
  String _certificateEnable;
  dynamic _courseTags;
  dynamic _levelTags;
  String _previewImage;
  String _imagepath;
  String _rejectTxt;
  String _dripEnable;
  String _previewType;
  String _updatedAt;

  int get id => _id;
  String get subcategoryId => _subcategoryId;
  String get categoryId => _categoryId;
  String get childcategoryId => _childcategoryId;
  String get languageId => _languageId;
  String get userId => _userId;
  Title get title => _title;
  Short_detail get shortDetail => _shortDetail;
  Requirement get requirement => _requirement;
  Detail get detail => _detail;
  String get price => _price;
  String get discountPrice => _discountPrice;
  dynamic get day => _day;
  String get video => _video;
  String get videoPath => _videoPath;
  dynamic get videoUrl => _videoUrl;
  String get url => _url;
  String get featured => _featured;
  String get status => _status;
  String get slug => _slug;
  dynamic get duration => _duration;
  String get durationType => _durationType;
  dynamic get instructorRevenue => _instructorRevenue;
  String get involvementRequest => _involvementRequest;
  dynamic get refundPolicyId => _refundPolicyId;
  String get assignmentEnable => _assignmentEnable;
  String get appointmentEnable => _appointmentEnable;
  String get certificateEnable => _certificateEnable;
  dynamic get courseTags => _courseTags;
  dynamic get levelTags => _levelTags;
  String get previewImage => _previewImage;
  String get imagepath => _imagepath;
  String get rejectTxt => _rejectTxt;
  String get dripEnable => _dripEnable;
  String get previewType => _previewType;
  String get updatedAt => _updatedAt;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['subcategory_id'] = _subcategoryId;
    map['category_id'] = _categoryId;
    map['childcategory_id'] = _childcategoryId;
    map['language_id'] = _languageId;
    map['user_id'] = _userId;
    if (_title != null) {
      map['title'] = _title.toJson();
    }
    if (_shortDetail != null) {
      map['short_detail'] = _shortDetail.toJson();
    }
    if (_requirement != null) {
      map['requirement'] = _requirement.toJson();
    }
    if (_detail != null) {
      map['detail'] = _detail.toJson();
    }
    map['price'] = _price;
    map['discount_price'] = _discountPrice;
    map['day'] = _day;
    map['video'] = _video;
    map['video_path'] = _videoPath;
    map['video_url'] = _videoUrl;
    map['url'] = _url;
    map['featured'] = _featured;
    map['status'] = _status;
    map['slug'] = _slug;
    map['duration'] = _duration;
    map['duration_type'] = _durationType;
    map['instructor_revenue'] = _instructorRevenue;
    map['involvement_request'] = _involvementRequest;
    map['refund_policy_id'] = _refundPolicyId;
    map['assignment_enable'] = _assignmentEnable;
    map['appointment_enable'] = _appointmentEnable;
    map['certificate_enable'] = _certificateEnable;
    map['course_tags'] = _courseTags;
    map['level_tags'] = _levelTags;
    map['preview_image'] = _previewImage;
    map['imagepath'] = _imagepath;
    map['reject_txt'] = _rejectTxt;
    map['drip_enable'] = _dripEnable;
    map['preview_type'] = _previewType;
    map['updated_at'] = _updatedAt;
    return map;
  }

}

/// en : "Now earn your INTERNATIONALLY ACCREDITED DIPLOMA IN YOGA TRAINING accredited by CPD Certification Service, which is an independent body that ensures qualifications are in line with the most current professional standards. This means this course comply with universally accepted principles of Continual Professional Development (CPD) and have been structured to meet the criteria of personal development plans. CPD certification means that the content and structure of the courses have been independently assessed and approved for multi-disciplinary and industry-wide continuing personal and professional development purposes."

class Detail {
  Detail({
      String en,}){
    _en = en;
}

  Detail.fromJson(dynamic json) {
    _en = json['en'];
  }
  String _en;

  String get en => _en;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['en'] = _en;
    return map;
  }

}

/// en : "A Yoga MatWillingness to apply Yogic knowledge into regular practice"

class Requirement {
  Requirement({
      String en,}){
    _en = en;
}

  Requirement.fromJson(dynamic json) {
    _en = json['en'];
  }
  String _en;

  String get en => _en;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['en'] = _en;
    return map;
  }

}

/// en : "Start a New Career in Yoga with this Yoga Course for Beginners/Intermediates"

class Short_detail {
  Short_detail({
      String en,}){
    _en = en;
}

  Short_detail.fromJson(dynamic json) {
    _en = json['en'];
  }
  String _en;

  String get en => _en;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['en'] = _en;
    return map;
  }

}

/// en : "Internationally Accredited Diploma in Yoga Training"

class Title {
  Title({
      String en,}){
    _en = en;
}

  Title.fromJson(dynamic json) {
    _en = json['en'];
  }
  String _en;

  String get en => _en;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['en'] = _en;
    return map;
  }

}