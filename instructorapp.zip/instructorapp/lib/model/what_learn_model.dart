/// data : [{"id":1,"course_id":"1","detail":{"en":"Have the skills to start making money on the side, as a casual freelancer, or full time as a work-from-home freelancer"},"status":"1","created_at":"2020-01-22T10:35:40.000000Z","updated_at":"2020-01-22T10:35:40.000000Z"},{"id":2,"course_id":"1","detail":{"en":"Easily create a beautiful HTML & CSS website with Bootstrap (that doesn't look like generic Bootstrap websites!)"},"status":"1","created_at":"2020-01-22T10:35:51.000000Z","updated_at":"2020-01-22T10:35:51.000000Z"},{"id":3,"course_id":"1","detail":{"en":"Fully understand how to use Custom Post Types and Advanced Custom Fields in WordPress"},"status":"1","created_at":"2020-01-22T10:36:07.000000Z","updated_at":"2020-01-22T10:36:07.000000Z"},{"id":9,"course_id":"3","detail":{"en":"Design icons, business cards, illustrations, and characters"},"status":"1","created_at":"2020-01-22T10:46:17.000000Z","updated_at":"2020-01-22T10:46:17.000000Z"},{"id":10,"course_id":"3","detail":{"en":"Master selections, layers, and working with the layers panel"},"status":"1","created_at":"2020-01-22T10:46:26.000000Z","updated_at":"2020-01-22T10:46:26.000000Z"},{"id":11,"course_id":"3","detail":{"en":"Use creative effects to design stunning text styles"},"status":"1","created_at":"2020-01-22T10:46:52.000000Z","updated_at":"2020-01-22T10:46:52.000000Z"},{"id":12,"course_id":"4","detail":{"en":"Have an excellent understanding of the principles of Patanjali's Ashtanga Eight Limb Yoga"},"status":"1","created_at":"2020-01-22T11:25:26.000000Z","updated_at":"2020-01-22T11:25:26.000000Z"},{"id":13,"course_id":"4","detail":{"en":"Improve alignment and posture to reduce the risk of injury"},"status":"1","created_at":"2020-01-22T11:25:36.000000Z","updated_at":"2020-01-22T11:25:36.000000Z"},{"id":14,"course_id":"4","detail":{"en":"Master all 59 Asana which are excellent for beginners and intermediates"},"status":"1","created_at":"2020-01-22T11:25:50.000000Z","updated_at":"2020-01-22T11:25:50.000000Z"},{"id":15,"course_id":"5","detail":{"en":"They will learn pencil techniques in order to create shirring/gathers, and shading, and the use of color pencils."},"status":"1","created_at":"2020-01-22T12:01:22.000000Z","updated_at":"2020-01-22T12:01:22.000000Z"},{"id":16,"course_id":"5","detail":{"en":"They will learn movement of the body, balance, plumb line."},"status":"1","created_at":"2020-01-22T12:01:38.000000Z","updated_at":"2020-01-22T12:01:38.000000Z"},{"id":17,"course_id":"5","detail":{"en":"They will learn about a fashion diary/journal, as a source of inspiration in order to be a great designer."},"status":"1","created_at":"2020-01-22T12:01:51.000000Z","updated_at":"2020-01-22T12:01:51.000000Z"},{"id":18,"course_id":"6","detail":{"en":"Instructions on how to hold your camera correctly, which will help you to get sharp photographs."},"status":"1","created_at":"2020-01-22T12:19:12.000000Z","updated_at":"2020-01-22T12:19:12.000000Z"},{"id":19,"course_id":"6","detail":{"en":"Sound advice on how to choose the right camera lens for each situation."},"status":"1","created_at":"2020-01-22T12:19:24.000000Z","updated_at":"2020-01-22T12:19:24.000000Z"},{"id":20,"course_id":"6","detail":{"en":"The necessary confidence to change the most important camera settings correctly at the right time, which in turn will allow you to get perfect photos every time"},"status":"1","created_at":"2020-01-22T12:19:31.000000Z","updated_at":"2020-01-22T12:19:31.000000Z"},{"id":21,"course_id":"6","detail":{"en":"The ability to compose photos that are well balanced and very pleasing to the eye."},"status":"1","created_at":"2020-01-22T12:19:38.000000Z","updated_at":"2020-01-22T12:19:38.000000Z"},{"id":22,"course_id":"8","detail":{"en":"Learn to Make your images look Amazing!!"},"status":"1","created_at":"2020-01-22T12:57:01.000000Z","updated_at":"2020-01-22T12:57:01.000000Z"},{"id":23,"course_id":"8","detail":{"en":"Make you comfortably with Lightroom software"},"status":"1","created_at":"2020-01-22T12:57:38.000000Z","updated_at":"2020-01-22T12:57:38.000000Z"},{"id":24,"course_id":"8","detail":{"en":"Edit exposure"},"status":"1","created_at":"2020-01-22T12:57:52.000000Z","updated_at":"2020-01-22T12:57:52.000000Z"},{"id":25,"course_id":"8","detail":{"en":"Create professional presets"},"status":"1","created_at":"2020-01-22T12:58:02.000000Z","updated_at":"2020-01-22T12:58:02.000000Z"},{"id":26,"course_id":"8","detail":{"en":"Export images"},"status":"1","created_at":"2020-01-22T12:58:10.000000Z","updated_at":"2020-01-22T12:58:10.000000Z"},{"id":27,"course_id":"8","detail":{"en":"Retouch skin"},"status":"1","created_at":"2020-01-22T12:58:19.000000Z","updated_at":"2020-01-22T12:58:19.000000Z"},{"id":28,"course_id":"7","detail":{"en":"Learn how to use SketchUp to create 3D models."},"status":"1","created_at":"2020-01-22T13:06:49.000000Z","updated_at":"2020-01-22T13:06:49.000000Z"},{"id":29,"course_id":"7","detail":{"en":"Beginners to Intermediate Users"},"status":"1","created_at":"2020-01-22T13:07:04.000000Z","updated_at":"2020-01-22T13:07:04.000000Z"},{"id":30,"course_id":"7","detail":{"en":"Understand how to use negative space as a design element."},"status":"1","created_at":"2020-01-22T13:09:05.000000Z","updated_at":"2020-01-22T13:09:05.000000Z"},{"id":31,"course_id":"1","detail":{"en":"Cut away a person from their background"},"status":"1","created_at":"2020-01-22T20:17:39.000000Z","updated_at":"2020-01-22T20:17:39.000000Z"},{"id":32,"course_id":"11","detail":{"en":"Be in a position to apply for jobs requiring good C++ knowledge"},"status":"1","created_at":"2020-01-23T17:00:09.000000Z","updated_at":"2020-01-23T17:00:09.000000Z"},{"id":33,"course_id":"11","detail":{"en":"Learn How to Develop an Application"},"status":"1","created_at":"2020-01-23T17:00:28.000000Z","updated_at":"2020-01-23T17:00:28.000000Z"},{"id":34,"course_id":"11","detail":{"en":"And of Course Create your First Program in C++ with the Easiest way Possible"},"status":"1","created_at":"2020-01-23T17:00:41.000000Z","updated_at":"2020-01-23T17:00:41.000000Z"},{"id":35,"course_id":"11","detail":{"en":"Find out if you are interested in C++ Language"},"status":"1","created_at":"2020-01-23T17:00:49.000000Z","updated_at":"2020-01-23T17:00:49.000000Z"},{"id":36,"course_id":"10","detail":{"en":"Get friendly and fast support in the course Q&A"},"status":"1","created_at":"2020-01-23T17:11:32.000000Z","updated_at":"2020-01-23T17:11:32.000000Z"},{"id":37,"course_id":"10","detail":{"en":"What's new in ES6: arrow functions, classes, default and rest parameters, etc."},"status":"1","created_at":"2020-01-23T17:11:42.000000Z","updated_at":"2020-01-23T17:11:43.000000Z"},{"id":38,"course_id":"10","detail":{"en":"Organize and structure your code using JavaScript patterns like modules"},"status":"1","created_at":"2020-01-23T17:11:51.000000Z","updated_at":"2020-01-23T17:11:51.000000Z"},{"id":39,"course_id":"10","detail":{"en":"Get friendly and fast support in the course Q&A"},"status":"1","created_at":"2020-01-23T17:11:59.000000Z","updated_at":"2020-01-23T17:11:59.000000Z"},{"id":40,"course_id":"12","detail":{"en":"Be comfortable putting SQL and PostgreSQL on their resume"},"status":"1","created_at":"2020-01-23T17:14:49.000000Z","updated_at":"2020-01-23T17:14:49.000000Z"},{"id":41,"course_id":"12","detail":{"en":"Use SQL to perform data analysis"},"status":"1","created_at":"2020-01-23T17:15:00.000000Z","updated_at":"2020-01-23T17:15:00.000000Z"},{"id":42,"course_id":"12","detail":{"en":"Be confident while working with constraints and relating data tables"},"status":"1","created_at":"2020-01-23T17:15:30.000000Z","updated_at":"2020-01-23T17:15:30.000000Z"},{"id":43,"course_id":"12","detail":{"en":"Tons of exercises that will solidify your knowledge"},"status":"1","created_at":"2020-01-23T17:15:42.000000Z","updated_at":"2020-01-23T17:15:42.000000Z"},{"id":44,"course_id":"13","detail":{"en":"Have the Ability to Solve any SQL Problem"},"status":"1","created_at":"2020-01-23T17:45:34.000000Z","updated_at":"2020-01-23T17:45:34.000000Z"},{"id":45,"course_id":"13","detail":{"en":"Allow your clients to update their websites by themselves by creating user accounts"},"status":"1","created_at":"2020-01-23T17:45:41.000000Z","updated_at":"2020-01-23T17:45:41.000000Z"},{"id":46,"course_id":"13","detail":{"en":"Data has become the hottest topic in technology"},"status":"1","created_at":"2020-01-23T17:46:02.000000Z","updated_at":"2020-01-23T17:46:02.000000Z"},{"id":47,"course_id":"15","detail":{"en":"Spend less time fighting with the DAW and more time focusing on the music."},"status":"1","created_at":"2020-01-23T17:52:33.000000Z","updated_at":"2020-01-23T17:52:33.000000Z"},{"id":48,"course_id":"15","detail":{"en":"Discover the quickest and easiest ways to write music in Logic Pro."},"status":"1","created_at":"2020-01-23T17:52:52.000000Z","updated_at":"2020-01-23T17:52:52.000000Z"},{"id":49,"course_id":"15","detail":{"en":"Professional by following my step-by-step mixing system using stock plugins."},"status":"1","created_at":"2020-01-23T17:53:09.000000Z","updated_at":"2020-01-23T17:53:09.000000Z"},{"id":50,"course_id":"16","detail":{"en":"Draw the human face"},"status":"1","created_at":"2020-01-23T18:07:28.000000Z","updated_at":"2020-01-23T18:07:28.000000Z"},{"id":51,"course_id":"16","detail":{"en":"Draw perspective drawings"},"status":"1","created_at":"2020-01-23T18:07:35.000000Z","updated_at":"2020-01-23T18:07:35.000000Z"},{"id":52,"course_id":"16","detail":{"en":"Drawing Fundamentals"},"status":"1","created_at":"2020-01-23T18:07:50.000000Z","updated_at":"2020-01-23T18:07:51.000000Z"},{"id":53,"course_id":"16","detail":{"en":"Character design"},"status":"1","created_at":"2020-01-23T18:07:58.000000Z","updated_at":"2020-01-23T18:07:58.000000Z"},{"id":54,"course_id":"16","detail":{"en":"How to create concept art"},"status":"1","created_at":"2020-01-23T18:08:11.000000Z","updated_at":"2020-01-23T18:08:11.000000Z"},{"id":55,"course_id":"17","detail":{"en":"By the end of the class you’ll paint a portrait in full color."},"status":"1","created_at":"2020-01-23T18:15:25.000000Z","updated_at":"2020-01-23T18:15:25.000000Z"},{"id":56,"course_id":"17","detail":{"en":"The best way to light and photograph, portrait (or any other subject) for a painting."},"status":"1","created_at":"2020-01-23T18:15:33.000000Z","updated_at":"2020-01-23T18:15:33.000000Z"},{"id":57,"course_id":"17","detail":{"en":"You’ll Learn the difference between chroma, color and values and how to control them."},"status":"1","created_at":"2020-01-23T18:15:43.000000Z","updated_at":"2020-01-23T18:15:43.000000Z"},{"id":58,"course_id":"17","detail":{"en":"An easy system to drawing anything you want!"},"status":"1","created_at":"2020-01-23T18:15:51.000000Z","updated_at":"2020-01-23T18:15:51.000000Z"},{"id":59,"course_id":"18","detail":{"en":"Curl your hair"},"status":"1","created_at":"2020-01-23T18:17:21.000000Z","updated_at":"2020-01-23T18:17:21.000000Z"},{"id":60,"course_id":"18","detail":{"en":"Straighten your hai"},"status":"1","created_at":"2020-01-23T18:17:36.000000Z","updated_at":"2020-01-23T18:17:36.000000Z"},{"id":61,"course_id":"18","detail":{"en":"Cut your own hair"},"status":"1","created_at":"2020-01-23T18:17:56.000000Z","updated_at":"2020-01-23T18:17:56.000000Z"},{"id":62,"course_id":"18","detail":{"en":"Dye your own hair naturally at hom"},"status":"1","created_at":"2020-01-23T18:18:14.000000Z","updated_at":"2020-01-23T18:18:14.000000Z"},{"id":63,"course_id":"19","detail":{"en":"You'll be able to draw onto your clients nails some sophisticated"},"status":"1","created_at":"2020-01-23T18:29:21.000000Z","updated_at":"2020-01-23T18:29:21.000000Z"},{"id":64,"course_id":"19","detail":{"en":"You'll have a different perspective about designing nails"},"status":"1","created_at":"2020-01-23T18:29:32.000000Z","updated_at":"2020-01-23T18:29:32.000000Z"},{"id":65,"course_id":"19","detail":{"en":"Practice to be able to reach"},"status":"1","created_at":"2020-01-23T18:29:52.000000Z","updated_at":"2020-01-23T18:29:52.000000Z"},{"id":66,"course_id":"20","detail":{"en":"Locating the perfect dates to travel for the cheapest price."},"status":"1","created_at":"2020-01-23T18:34:28.000000Z","updated_at":"2020-01-23T18:34:29.000000Z"},{"id":67,"course_id":"20","detail":{"en":"Learn the tricks of travel and finding discount places to stay."},"status":"1","created_at":"2020-01-23T18:34:37.000000Z","updated_at":"2020-01-23T18:34:37.000000Z"},{"id":68,"course_id":"20","detail":{"en":"How to travel light"},"status":"1","created_at":"2020-01-23T18:34:53.000000Z","updated_at":"2020-01-23T18:34:53.000000Z"},{"id":69,"course_id":"20","detail":{"en":"How to finance your trips"},"status":"1","created_at":"2020-01-23T18:35:07.000000Z","updated_at":"2020-01-23T18:35:08.000000Z"},{"id":70,"course_id":"20","detail":{"en":"How to locate & book cheap flights"},"status":"1","created_at":"2020-01-23T18:35:16.000000Z","updated_at":"2020-01-23T18:35:16.000000Z"},{"id":71,"course_id":"20","detail":{"en":"How to communicate if you don't speak the native language in a country."},"status":"1","created_at":"2020-01-23T18:35:27.000000Z","updated_at":"2020-01-23T18:35:27.000000Z"},{"id":77,"course_id":"4","detail":{"en":"12:23 PM"},"status":"1","created_at":"2021-08-27T04:18:17.000000Z","updated_at":"2021-08-27T06:53:15.000000Z"}]

class WhatLearnModel {
  WhatLearnModel({
      List<Data> data,}){
    _data = data;
}

  WhatLearnModel.fromJson(dynamic json) {
    if (json['data'] != null) {
      _data = [];
      json['data'].forEach((v) {
        _data.add(Data.fromJson(v));
      });
    }
  }
  List<Data> _data;

  List<Data> get data => _data;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_data != null) {
      map['data'] = _data.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 1
/// course_id : "1"
/// detail : {"en":"Have the skills to start making money on the side, as a casual freelancer, or full time as a work-from-home freelancer"}
/// status : "1"
/// created_at : "2020-01-22T10:35:40.000000Z"
/// updated_at : "2020-01-22T10:35:40.000000Z"

class Data {
  Data({
      int id, 
      String courseId, 
      Detail detail, 
      String status, 
      String createdAt, 
      String updatedAt,}){
    _id = id;
    _courseId = courseId;
    _detail = detail;
    _status = status;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
}

  Data.fromJson(dynamic json) {
    _id = json['id'];
    _courseId = json['course_id'];
    _detail = json['detail'] != null ? Detail.fromJson(json['detail']) : null;
    _status = json['status'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
  }
  int _id;
  String _courseId;
  Detail _detail;
  String _status;
  String _createdAt;
  String _updatedAt;

  int get id => _id;
  String get courseId => _courseId;
  Detail get detail => _detail;
  String get status => _status;
  String get createdAt => _createdAt;
  String get updatedAt => _updatedAt;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['course_id'] = _courseId;
    if (_detail != null) {
      map['detail'] = _detail.toJson();
    }
    map['status'] = _status;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    return map;
  }

}

/// en : "Have the skills to start making money on the side, as a casual freelancer, or full time as a work-from-home freelancer"

class Detail {
  Detail({
      String en,}){
    _en = en;
}

  Detail.fromJson(dynamic json) {
    _en = json['en'];
  }
  String _en;

  String get en => _en;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['en'] = _en;
    return map;
  }

}