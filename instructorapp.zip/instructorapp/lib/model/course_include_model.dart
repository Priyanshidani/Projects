/// data : [{"id":1,"course_id":"1","detail":{"en":"Anytime, Anywhere"},"icon":"fa-american-sign-language-interpreting","status":"1","created_at":"2020-01-22T10:20:50.000000Z","updated_at":"2020-01-22T19:56:25.000000Z"},{"id":2,"course_id":"1","detail":{"en":"Downloadable resources"},"icon":"fa-adjust","status":"1","created_at":"2020-01-22T10:31:30.000000Z","updated_at":"2020-01-22T10:33:55.000000Z"},{"id":3,"course_id":"1","detail":{"en":"Full lifetime access"},"icon":"fa-bandcamp","status":"1","created_at":"2020-01-22T10:34:08.000000Z","updated_at":"2020-01-22T10:34:08.000000Z"},{"id":4,"course_id":"1","detail":{"en":"Access on mobile and TV"},"icon":"fa-check-square","status":"1","created_at":"2020-01-22T10:34:34.000000Z","updated_at":"2020-01-22T10:34:34.000000Z"},{"id":9,"course_id":"3","detail":{"en":"on-demand video"},"icon":"fa-braille","status":"1","created_at":"2020-01-22T10:43:14.000000Z","updated_at":"2020-01-22T10:43:14.000000Z"},{"id":10,"course_id":"3","detail":{"en":"downloadable resources"},"icon":"fa-bandcamp","status":"1","created_at":"2020-01-22T10:43:33.000000Z","updated_at":"2020-01-22T10:43:33.000000Z"},{"id":11,"course_id":"3","detail":{"en":"Full lifetime access"},"icon":"fa-calendar-check-o","status":"1","created_at":"2020-01-22T10:43:52.000000Z","updated_at":"2020-01-22T10:43:52.000000Z"},{"id":12,"course_id":"3","detail":{"en":"Access on mobile and TV"},"icon":"fa-fast-forward","status":"1","created_at":"2020-01-22T10:44:19.000000Z","updated_at":"2020-01-22T10:44:19.000000Z"},{"id":13,"course_id":"4","detail":{"en":"4 hours on-demand video"},"icon":"fa-file-video-o","status":"1","created_at":"2020-01-22T11:23:19.000000Z","updated_at":"2020-01-22T11:23:19.000000Z"},{"id":14,"course_id":"4","detail":{"en":"Anytime Anywhere"},"icon":"fa-newspaper-o","status":"1","created_at":"2020-01-22T11:23:37.000000Z","updated_at":"2020-01-24T08:17:26.000000Z"},{"id":15,"course_id":"4","detail":{"en":"downloadable resources"},"icon":"fa-arrow-circle-down","status":"1","created_at":"2020-01-22T11:23:53.000000Z","updated_at":"2020-01-24T08:18:40.000000Z"},{"id":17,"course_id":"4","detail":{"en":"Access on mobile and TV"},"icon":"fa-gamepad","status":"1","created_at":"2020-01-22T11:24:31.000000Z","updated_at":"2021-08-24T03:49:54.000000Z"},{"id":19,"course_id":"5","detail":{"en":"Full lifetime access"},"icon":"fa-bullseye","status":"1","created_at":"2020-01-22T12:00:16.000000Z","updated_at":"2020-01-22T12:00:16.000000Z"},{"id":20,"course_id":"5","detail":{"en":"Access on mobile and TV"},"icon":"fa-bandcamp","status":"1","created_at":"2020-01-22T12:00:35.000000Z","updated_at":"2020-01-22T12:00:35.000000Z"},{"id":21,"course_id":"5","detail":{"en":"On-demand video"},"icon":"fa-clipboard","status":"1","created_at":"2020-01-22T12:00:48.000000Z","updated_at":"2020-01-22T12:01:05.000000Z"},{"id":22,"course_id":"6","detail":{"en":"2 hours on-demand video"},"icon":"fa-video-camera","status":"1","created_at":"2020-01-22T12:17:42.000000Z","updated_at":"2020-01-22T12:17:42.000000Z"},{"id":23,"course_id":"6","detail":{"en":"6 articles"},"icon":"fa-paper-plane-o","status":"1","created_at":"2020-01-22T12:18:01.000000Z","updated_at":"2020-01-22T12:18:01.000000Z"},{"id":24,"course_id":"6","detail":{"en":"1 downloadable resource"},"icon":"fa-download","status":"1","created_at":"2020-01-22T12:18:14.000000Z","updated_at":"2020-01-22T12:18:14.000000Z"},{"id":25,"course_id":"6","detail":{"en":"Access on mobile and TV"},"icon":"fa-mobile-phone","status":"1","created_at":"2020-01-22T12:18:31.000000Z","updated_at":"2020-01-22T12:18:31.000000Z"},{"id":26,"course_id":"6","detail":{"en":"Certificate of Completion"},"icon":"fa-certificate","status":"1","created_at":"2020-01-22T12:18:51.000000Z","updated_at":"2020-01-22T12:18:51.000000Z"},{"id":27,"course_id":"8","detail":{"en":"On Demand Video"},"icon":"fa-file-video-o","status":"1","created_at":"2020-01-22T12:55:16.000000Z","updated_at":"2020-01-22T12:55:16.000000Z"},{"id":28,"course_id":"8","detail":{"en":"Articles"},"icon":"fa-file-code-o","status":"1","created_at":"2020-01-22T12:56:15.000000Z","updated_at":"2020-01-22T12:56:15.000000Z"},{"id":29,"course_id":"8","detail":{"en":"Certificate"},"icon":"fa-certificate","status":"1","created_at":"2020-01-22T12:56:35.000000Z","updated_at":"2020-01-22T12:56:35.000000Z"},{"id":30,"course_id":"7","detail":{"en":"Lifetime access"},"icon":"fa-genderless","status":"1","created_at":"2020-01-22T13:04:59.000000Z","updated_at":"2020-01-22T13:04:59.000000Z"},{"id":31,"course_id":"7","detail":{"en":"Access anytime anywhere"},"icon":"fa-gittip","status":"1","created_at":"2020-01-22T13:05:36.000000Z","updated_at":"2020-01-22T13:05:36.000000Z"},{"id":32,"course_id":"7","detail":{"en":"On-demand video"},"icon":"fa-yelp","status":"1","created_at":"2020-01-22T13:06:14.000000Z","updated_at":"2020-01-22T13:06:14.000000Z"},{"id":33,"course_id":"7","detail":{"en":"Access on mobile"},"icon":"fa-cc-mastercard","status":"1","created_at":"2020-01-22T19:59:40.000000Z","updated_at":"2020-01-22T19:59:59.000000Z"},{"id":34,"course_id":"5","detail":{"en":"downloadable resource"},"icon":"fa-bell-o","status":"1","created_at":"2020-01-22T20:01:45.000000Z","updated_at":"2020-01-22T20:02:20.000000Z"},{"id":35,"course_id":"11","detail":{"en":"on-demand video"},"icon":"fa-beer","status":"1","created_at":"2020-01-23T16:58:16.000000Z","updated_at":"2020-01-23T16:58:16.000000Z"},{"id":36,"course_id":"11","detail":{"en":"downloadable resource"},"icon":"fa-creative-commons","status":"1","created_at":"2020-01-23T16:58:37.000000Z","updated_at":"2020-01-23T16:58:38.000000Z"},{"id":37,"course_id":"11","detail":{"en":"Access on mobile and TV"},"icon":"fa-compress","status":"1","created_at":"2020-01-23T16:59:18.000000Z","updated_at":"2020-01-23T16:59:18.000000Z"},{"id":38,"course_id":"11","detail":{"en":"Anytime, Anywhere"},"icon":"fa-cubes","status":"1","created_at":"2020-01-23T16:59:30.000000Z","updated_at":"2020-01-23T16:59:30.000000Z"},{"id":39,"course_id":"10","detail":{"en":"Anytime, Anywhere"},"icon":"fa-book","status":"1","created_at":"2020-01-23T17:09:43.000000Z","updated_at":"2020-01-23T17:09:43.000000Z"},{"id":40,"course_id":"10","detail":{"en":"Downloadable resources"},"icon":"fa-cubes","status":"1","created_at":"2020-01-23T17:10:08.000000Z","updated_at":"2020-01-23T17:10:08.000000Z"},{"id":41,"course_id":"10","detail":{"en":"Full lifetime access"},"icon":"fa-check-circle-o","status":"1","created_at":"2020-01-23T17:10:20.000000Z","updated_at":"2020-01-23T17:10:20.000000Z"},{"id":42,"course_id":"10","detail":{"en":"Access on mobile and TV"},"icon":"fa-dribbble","status":"1","created_at":"2020-01-23T17:10:40.000000Z","updated_at":"2020-01-23T17:10:40.000000Z"},{"id":43,"course_id":"12","detail":{"en":"Anytime, Anywhere"},"icon":"fa-bookmark","status":"1","created_at":"2020-01-23T17:18:15.000000Z","updated_at":"2020-01-23T17:18:15.000000Z"},{"id":44,"course_id":"12","detail":{"en":"Full lifetime access"},"icon":"fa-clipboard","status":"1","created_at":"2020-01-23T17:18:29.000000Z","updated_at":"2020-01-23T17:18:29.000000Z"},{"id":45,"course_id":"12","detail":{"en":"Access on mobile and TV"},"icon":"fa-commenting-o","status":"1","created_at":"2020-01-23T17:18:43.000000Z","updated_at":"2020-01-23T17:18:43.000000Z"},{"id":46,"course_id":"13","detail":{"en":"Anytime, Anywhere"},"icon":"fa-bookmark-o","status":"1","created_at":"2020-01-23T17:43:57.000000Z","updated_at":"2020-01-23T17:43:57.000000Z"},{"id":47,"course_id":"13","detail":{"en":"Downloadable resources"},"icon":"fa-eercast","status":"1","created_at":"2020-01-23T17:44:11.000000Z","updated_at":"2020-01-23T17:44:11.000000Z"},{"id":48,"course_id":"13","detail":{"en":"Full lifetime access"},"icon":"fa-gittip","status":"1","created_at":"2020-01-23T17:44:31.000000Z","updated_at":"2020-01-23T17:44:31.000000Z"},{"id":49,"course_id":"13","detail":{"en":"Access on mobile and TV"},"icon":"fa-dropbox","status":"1","created_at":"2020-01-23T17:44:50.000000Z","updated_at":"2020-01-23T17:44:50.000000Z"},{"id":50,"course_id":"15","detail":{"en":"Anytime, Anywhere"},"icon":"fa-clipboard","status":"1","created_at":"2020-01-23T17:51:17.000000Z","updated_at":"2020-01-23T17:51:17.000000Z"},{"id":51,"course_id":"15","detail":{"en":"Full lifetime access"},"icon":"fa-adjust","status":"1","created_at":"2020-01-23T17:51:53.000000Z","updated_at":"2020-01-23T17:51:54.000000Z"},{"id":52,"course_id":"15","detail":{"en":"Access on mobile and TV"},"icon":"fa-align-center","status":"1","created_at":"2020-01-23T17:52:09.000000Z","updated_at":"2020-01-23T17:52:09.000000Z"},{"id":53,"course_id":"16","detail":{"en":"Anytime, Anywhere"},"icon":"fa-bullhorn","status":"1","created_at":"2020-01-23T18:06:43.000000Z","updated_at":"2020-01-23T18:06:43.000000Z"},{"id":54,"course_id":"16","detail":{"en":"Full lifetime access"},"icon":"fa-anchor","status":"1","created_at":"2020-01-23T18:06:58.000000Z","updated_at":"2020-01-23T18:06:58.000000Z"},{"id":55,"course_id":"16","detail":{"en":"Access on mobile and TV"},"icon":"fa-book","status":"1","created_at":"2020-01-23T18:07:09.000000Z","updated_at":"2020-01-23T18:07:09.000000Z"},{"id":56,"course_id":"17","detail":{"en":"Anytime, Anywhere"},"icon":"fa-chevron-left","status":"1","created_at":"2020-01-23T18:11:50.000000Z","updated_at":"2020-01-23T18:11:50.000000Z"},{"id":57,"course_id":"17","detail":{"en":"Downloadable resources"},"icon":"fa-check-square","status":"1","created_at":"2020-01-23T18:12:08.000000Z","updated_at":"2020-01-23T18:12:08.000000Z"},{"id":58,"course_id":"17","detail":{"en":"Full lifetime access"},"icon":"fa-bullhorn","status":"1","created_at":"2020-01-23T18:12:23.000000Z","updated_at":"2020-01-23T18:12:23.000000Z"},{"id":59,"course_id":"18","detail":{"en":"On-demand video"},"icon":"fa-braille","status":"1","created_at":"2020-01-23T18:18:49.000000Z","updated_at":"2020-01-23T18:18:49.000000Z"},{"id":60,"course_id":"18","detail":{"en":"Full lifetime access"},"icon":"fa-buysellads","status":"1","created_at":"2020-01-23T18:19:04.000000Z","updated_at":"2020-01-23T18:19:04.000000Z"},{"id":61,"course_id":"18","detail":{"en":"Access on mobile and TV"},"icon":"fa-crosshairs","status":"1","created_at":"2020-01-23T18:19:19.000000Z","updated_at":"2020-01-23T18:19:19.000000Z"},{"id":62,"course_id":"18","detail":{"en":"Full lifetime access"},"icon":"fa-genderless","status":"1","created_at":"2020-01-23T18:19:35.000000Z","updated_at":"2020-01-23T18:19:35.000000Z"},{"id":63,"course_id":"19","detail":{"en":"Anytime, Anywhere"},"icon":"fa-bank","status":"1","created_at":"2020-01-23T18:27:55.000000Z","updated_at":"2020-01-23T18:27:55.000000Z"},{"id":64,"course_id":"19","detail":{"en":"Downloadable resources"},"icon":"fa-building-o","status":"1","created_at":"2020-01-23T18:28:09.000000Z","updated_at":"2020-01-23T18:28:09.000000Z"},{"id":65,"course_id":"19","detail":{"en":"Full lifetime access"},"icon":"fa-bolt","status":"1","created_at":"2020-01-23T18:28:23.000000Z","updated_at":"2020-01-23T18:28:24.000000Z"},{"id":66,"course_id":"19","detail":{"en":"Access on mobile and TV"},"icon":"fa-adjust","status":"1","created_at":"2020-01-23T18:28:37.000000Z","updated_at":"2020-01-23T18:28:38.000000Z"},{"id":67,"course_id":"20","detail":{"en":"on-demand video"},"icon":"fa-bandcamp","status":"1","created_at":"2020-01-23T18:33:28.000000Z","updated_at":"2020-01-23T18:33:28.000000Z"},{"id":68,"course_id":"20","detail":{"en":"Full lifetime access"},"icon":"fa-bullseye","status":"1","created_at":"2020-01-23T18:33:40.000000Z","updated_at":"2020-01-23T18:33:40.000000Z"},{"id":69,"course_id":"20","detail":{"en":"Anytime, Anywhere"},"icon":"fa-align-left","status":"1","created_at":"2020-01-23T18:34:04.000000Z","updated_at":"2020-01-23T18:34:13.000000Z"},{"id":80,"course_id":"4","detail":{"en":"testing"},"icon":"fa-angellist","status":"1","created_at":"2021-08-26T11:35:38.000000Z","updated_at":"2021-08-26T11:35:56.000000Z"}]

class CourseIncludeModel {
  CourseIncludeModel({
      List<Data> data,}){
    _data = data;
}

  CourseIncludeModel.fromJson(dynamic json) {
    if (json['data'] != null) {
      _data = [];
      json['data'].forEach((v) {
        _data.add(Data.fromJson(v));
      });
    }
  }
  List<Data> _data;

  List<Data> get data => _data;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_data != null) {
      map['data'] = _data.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 1
/// course_id : "1"
/// detail : {"en":"Anytime, Anywhere"}
/// icon : "fa-american-sign-language-interpreting"
/// status : "1"
/// created_at : "2020-01-22T10:20:50.000000Z"
/// updated_at : "2020-01-22T19:56:25.000000Z"

class Data {
  Data({
      int id, 
      String courseId, 
      Detail detail, 
      String icon, 
      String status, 
      String createdAt, 
      String updatedAt,}){
    _id = id;
    _courseId = courseId;
    _detail = detail;
    _icon = icon;
    _status = status;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
}

  Data.fromJson(dynamic json) {
    _id = json['id'];
    _courseId = json['course_id'];
    _detail = json['detail'] != null ? Detail.fromJson(json['detail']) : null;
    _icon = json['icon'];
    _status = json['status'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
  }
  int _id;
  String _courseId;
  Detail _detail;
  String _icon;
  String _status;
  String _createdAt;
  String _updatedAt;

  int get id => _id;
  String get courseId => _courseId;
  Detail get detail => _detail;
  String get icon => _icon;
  String get status => _status;
  String get createdAt => _createdAt;
  String get updatedAt => _updatedAt;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['course_id'] = _courseId;
    if (_detail != null) {
      map['detail'] = _detail.toJson();
    }
    map['icon'] = _icon;
    map['status'] = _status;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    return map;
  }

}

/// en : "Anytime, Anywhere"

class Detail {
  Detail({
      String en,}){
    _en = en;
}

  Detail.fromJson(dynamic json) {
    _en = json['en'];
  }
  String _en;

  String get en => _en;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['en'] = _en;
    return map;
  }

}