/// language : [{"id":1,"name":{"en":"English"},"status":"1","created_at":"2020-01-22T10:11:54.000000Z","updated_at":"2020-01-22T10:11:54.000000Z"},{"id":2,"name":{"en":"Hindi"},"status":"0","created_at":"2020-01-22T11:13:52.000000Z","updated_at":"2021-08-24T06:03:16.000000Z"},{"id":3,"name":{"en":"French"},"status":"1","created_at":"2020-01-22T11:14:02.000000Z","updated_at":"2020-01-22T11:14:02.000000Z"},{"id":4,"name":{"en":"Spanish"},"status":"1","created_at":"2020-01-22T11:14:15.000000Z","updated_at":"2020-01-22T11:14:15.000000Z"}]

class CourseLanguageModel {
  CourseLanguageModel({
      List<Language> language,}){
    _language = language;
}

  CourseLanguageModel.fromJson(dynamic json) {
    if (json['language'] != null) {
      _language = [];
      json['language'].forEach((v) {
        _language.add(Language.fromJson(v));
      });
    }
  }
  List<Language> _language;

  List<Language> get language => _language;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_language != null) {
      map['language'] = _language.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 1
/// name : {"en":"English"}
/// status : "1"
/// created_at : "2020-01-22T10:11:54.000000Z"
/// updated_at : "2020-01-22T10:11:54.000000Z"

class Language {
  Language({
      int id, 
      Name name, 
      String status, 
      String createdAt, 
      String updatedAt,}){
    _id = id;
    _name = name;
    _status = status;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
}

  Language.fromJson(dynamic json) {
    _id = json['id'];
    _name = json['name'] != null ? Name.fromJson(json['name']) : null;
    _status = json['status'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
  }
  int _id;
  Name _name;
  String _status;
  String _createdAt;
  String _updatedAt;

  int get id => _id;
  Name get name => _name;
  String get status => _status;
  String get createdAt => _createdAt;
  String get updatedAt => _updatedAt;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    if (_name != null) {
      map['name'] = _name.toJson();
    }
    map['status'] = _status;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    return map;
  }

}

/// en : "English"

class Name {
  Name({
      String en,}){
    _en = en;
}

  Name.fromJson(dynamic json) {
    _en = json['en'];
  }
  String _en;

  String get en => _en;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['en'] = _en;
    return map;
  }

}