/// course_count : 8
/// featured_course_count : 2
/// enrolled_user_count : 2
/// questions_count : 2
/// answer_count : 1
/// blog_count : 2
/// zoomm_meeting_count : 0
/// bigblue_meeting_count : 1
/// userenroll_chart : [0,0,0,0,0,0,1,1,0,0,0,0]
/// payout_chart : [0,0,0,0,0,0,0,0,0,0,0,0]

class DashboardModel {
  DashboardModel({
      int courseCount, 
      int featuredCourseCount, 
      int enrolledUserCount, 
      int questionsCount, 
      int answerCount, 
      int blogCount, 
      int zoommMeetingCount, 
      int bigblueMeetingCount, 
      List<int> userenrollChart, 
      List<int> payoutChart,}){
    _courseCount = courseCount;
    _featuredCourseCount = featuredCourseCount;
    _enrolledUserCount = enrolledUserCount;
    _questionsCount = questionsCount;
    _answerCount = answerCount;
    _blogCount = blogCount;
    _zoommMeetingCount = zoommMeetingCount;
    _bigblueMeetingCount = bigblueMeetingCount;
    _userenrollChart = userenrollChart;
    _payoutChart = payoutChart;
}

  DashboardModel.fromJson(dynamic json) {
    _courseCount = json['course_count'];
    _featuredCourseCount = json['featured_course_count'];
    _enrolledUserCount = json['enrolled_user_count'];
    _questionsCount = json['questions_count'];
    _answerCount = json['answer_count'];
    _blogCount = json['blog_count'];
    _zoommMeetingCount = json['zoomm_meeting_count'];
    _bigblueMeetingCount = json['bigblue_meeting_count'];
    _userenrollChart = json['userenroll_chart'] != null ? json['userenroll_chart'].cast<int>() : [];
    _payoutChart = json['payout_chart'] != null ? json['payout_chart'].cast<int>() : [];
  }
  int _courseCount;
  int _featuredCourseCount;
  int _enrolledUserCount;
  int _questionsCount;
  int _answerCount;
  int _blogCount;
  int _zoommMeetingCount;
  int _bigblueMeetingCount;
  List<int> _userenrollChart;
  List<int> _payoutChart;

  int get courseCount => _courseCount;
  int get featuredCourseCount => _featuredCourseCount;
  int get enrolledUserCount => _enrolledUserCount;
  int get questionsCount => _questionsCount;
  int get answerCount => _answerCount;
  int get blogCount => _blogCount;
  int get zoommMeetingCount => _zoommMeetingCount;
  int get bigblueMeetingCount => _bigblueMeetingCount;
  List<int> get userenrollChart => _userenrollChart;
  List<int> get payoutChart => _payoutChart;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['course_count'] = _courseCount;
    map['featured_course_count'] = _featuredCourseCount;
    map['enrolled_user_count'] = _enrolledUserCount;
    map['questions_count'] = _questionsCount;
    map['answer_count'] = _answerCount;
    map['blog_count'] = _blogCount;
    map['zoomm_meeting_count'] = _zoommMeetingCount;
    map['bigblue_meeting_count'] = _bigblueMeetingCount;
    map['userenroll_chart'] = _userenrollChart;
    map['payout_chart'] = _payoutChart;
    return map;
  }

}