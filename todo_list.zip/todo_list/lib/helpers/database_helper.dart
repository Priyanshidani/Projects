// import 'package:path_provider/path_provider.dart';
// import 'package:sqflite/sqflite.dart';
//
// class DatabaseHelper{
//   static final DatabaseHelper instance = DatabaseHelper._instance;
//   static Database _db;
//
//   DatabaseHelper._instance;
//
//   String taskTables = 'taskTables';
//   String colId = 'id';
//   String colTitle = 'title';
//   String colDate = 'date';
//   String colPriority = 'priority';
//   String colStatus ='status';
//
//   Future<Database> get db async{
//     if(_db == null){
//       _db = await _initDb();
//     }
//     return _db;
//   }
//   Future<Database> _initDb() async{
//     Directory dir =  await getApplicationDocumentsDirectory();
//     String path = dir.path + 'Todo_list.db';
//     final todoListDb = await openDatabase(path, version: 1,onCreate: _createDb);
//     return todoListDb;
//   }
//   void _createDb(Database db, int version) async{
//     await db.execute(
//         'CREATE TABLE $taskTables($colId INTEGER PRIMARY KEY AUTOINCREMENT, $colTitle TEXT, $colDate TEXT,$colPriority TEXT,$colStatus INTEGER)',
//     );
//   }
//   Future<List<Map<String, Dynamic>>> getTaskMapList() async{
//     Database db = await this.db;
//     final List<Map<String, Dynamic>> result = await db.query(tasksTable);
//     return result;
//   }
//   Future<list<Task>> getTaskList() async{
//     final List<Map<String, Dynamic>> taskMapList = await getTaskMapList();
//     final List<Task> taskList =[];
//     taskMapList.forEach((taskMap)){
//       taskList.add(Task.forMap(taskMap));
//     });
//     return taskList;
//   }
//   Future<int> insertTask(Task task) async{
//     Datbase db = await this.db;
//     final int result = await db.insert(
//       taskTable,
//       task.toMap(),
//     );
//     return result;
//   }
//   Future<int> updateTask(Task task) async{
//     Datbase db = await this.db;
//     final int result = await db.update(
//       taskTable,
//       task.toMap(),
//       where: '$colId=?';
//       whereArgs: [task.id],
//     );
//     return result;
//   }
//   Future<int> deleteTask(int id) async{
//     Datbase db = await this.db;
//     final int result = await db.delete(
//       taskTable,
//       where: '$colId=?';
//       whereArgs: [id],
//     );
//     return result;
//   }
//
// }