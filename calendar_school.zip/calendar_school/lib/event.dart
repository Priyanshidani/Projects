class Event {
  final String title;
  Event({required this.title});

  String toString() => this.title;
}