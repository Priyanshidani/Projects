package com.example.calendar_school

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
